# 骨碌（Gulu）本地运行包

**应用本体（只读）与用户态（可写）分开存放** —— `workspace/` 是应用，`user/` 是该用户的东西。
（《目录记忆与知识底座完整设计 v5》里的那棵目录树，描述的就是 **`workspace/` 内部**的结构。）

## 目录
- `workspace/`：**应用本体（只读）** —— `AGENTS.md`（入口）/ `manifest.dev.json` / `onboarding.md` /
  `.codex/skills/`（7 个 Skill，**隐藏目录**）/ `scripts/`（公共脚本 + `scripts/schedules/`）/
  `knowledge/` / `memory/`（策略 + `templates/` 母版）/ `tools/README.md` / `agents/.keep`
- `user/`：**用户态（可写）** —— `state.md`（JSON，状态真相源）/ `user.md` / `memory/`（记忆实例）
- `AGENTS.md`（本层）：**启动引导**，只说明"应用在 `workspace/`、用户态在 `user/`"，不是应用资产
- `README.md` / `CHANGELOG.md` / `TESTING.md`：本包说明（非应用资产）
- `start.sh`：本地启动脚本（导出 `WORKSPACE_DIR` / `USER_DIR`）

## 怎么跑（三选一）
1. **打开 `workspace/` 作为项目目录**：`workspace/AGENTS.md` 会被自动加载 → 骨碌。
2. **打开本层（包根）也可以**：本层的 `AGENTS.md` 会把你引到 `workspace/AGENTS.md`，同样进骨碌。
3. 命令行：`./start.sh`（内部导出 `WORKSPACE_DIR=<本目录>/workspace`、`USER_DIR=<本目录>/user`、`AIPM_STATE=use`）。

> 关键：`WORKSPACE_DIR` 必须指向 `workspace/`。若它是空的、且打开的目录里没有 `AGENTS.md`，运行时没有应用指令 → 会退回平台通用身份。
> `.codex/` 是点开头的隐藏目录：Finder 按 `⌘ + ⇧ + .` 显示，终端用 `ls -a`，编辑器里默认可见。

## 关键时序
- onboarding：`intro/collect_user_info` → `intro/persona_draw` → `intro/init_state`（写 `user/state.md` + 从 `workspace/memory/templates/` 实例化到 `user/memory/`）
- 互动：`response/orchestrate_turn`（自读 state → detect_mode/advance_stage → 落盘）
- 会员：`billing/apply_membership`（开通/到期 → `state.frozen`）
- 重抽：`billing/apply_redraft`（支付 → 重抽 → `state.persona_bound` / `draw_count`）

## 定时任务（重点）
- `workspace/scripts/schedules/{check_trigger,curate_memory,generate_life_events}.py`
- 创建：`workspace/.codex/skills/proactive-message/scripts/setup_schedule.py` **输出 3 条任务请求**
  （`name`/`trigger`/`action`/`delivery_mode`/`idempotency_key`，**可原样提交**），由**运行态 Agent 经
  Global schedule 能力**创建；创建后 `confirm_schedules` 回写 state
- **能力状态**：平台定时能力**已接入**（2026-10-13）；**本版为验证档**（唤醒 11min、proactive `notify`），
  通过后恢复设计值（88min / `silent`）
- 本地手验：`USER_DIR="$PWD/user" python3 -B workspace/scripts/schedules/check_trigger.py`
- 创建参数与验证清单：见 `TESTING.md` §3

## 平台能力
飞书发送 / schedules 等 adapter 由平台注入；本地无 adapter 时 `adapter_ok=false` / `sent=false` 属预期。
