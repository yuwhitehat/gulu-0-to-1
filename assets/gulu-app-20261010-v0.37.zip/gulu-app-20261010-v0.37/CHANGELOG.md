# 变更记录（骨碌 App 组装）

## 2026-10-15 v0.37（定时任务触发后由 **Bot 自动投递**；修"重复消息"）
- **现象**：定时任务触发后群里出现**两条一模一样的消息**。
- **根因**：Bot 的 **ResultDelivery** 会自动把 Agent 的最终回复投递到飞书会话；而 v0.35/v0.36 的文档让 Agent **又显式调了一次发消息工具**，于是投递两次。
- **本版**：`AGENTS.md` 新增 Owner 指定章节「**定时任务触发后的消息发送（重要）**」（原文：定时任务触发后 Bot 自动投递最终回复；**不要调用 `feishu.message_send_current_channel`**，只输出即可），并据此统一：
  - 主动消息口径改为「门禁 → 组装 `reply_text` → **作为最终回答输出**（Bot 投递）」；删除"由 Agent 用平台能力发送"的表述。
  - **`delivery_mode` 明确为投递开关**：**proactive 必须 `notify`**（`silent` 则主动消息不会出现在群里）；`curate` / `life-event` 保持 `silent` 且**不产生用户可见输出**。
  - **删除 `proactive-message/scripts/record_send.py`**：投递由 Bot 负责、应用拿不到送达回执，无内容可记；门禁/计数仍由 `record_interaction` 落盘（`last_proactive_at` / `unanswered_count`）。
  - 同步：`proactive-message/SKILL.md`（接口表、send 小节、读写表、失败表、验证 case）、`tools/README.md`（新增「发送（定时任务由 Bot 自动投递）」节）、`check_trigger.py` 的 `note`、`AGENTS.md` 主动 Turn 链与工具边界。
- **自查**：应用侧 `record_send` / `message_send_current_channel`（除「不要调用…」这条规则本身）**0 处**；外部地址/端口号/命令行请求示例仍 **0 处**。
- 数值不变：唤醒 660s、门禁 J=20min·P=10min。

## 2026-10-15 v0.36（应用侧"零命中"：不再出现任何外部地址 / 命令行请求字样）
- **背景**：Owner 用自查口径（匹配外部地址、端口、命令行请求、代理变量名等）在 v0.35 里仍搜到 4 个文件命中——命中的都是**禁令本身引用了那些字样**（如"不要使用 … 或 `$BASE_URL/…`"）。虽无实际旧调用，但按验收口径要求应用侧 **0 命中**。
- **本版**：把这些字样**从应用里彻底移除**，只保留正向规则：
  - `AGENTS.md`：「创建方式（重要）」小节改为"**必须用 `schedule.create` 动态工具**；创建/列举/更新一律走动态工具，**不得采用其它任何方式**（命令行请求、网页请求、自行拼接地址、自建调度都不允许）"；工具列表说明改为"**无需任何外部地址或凭证**"；新增**验收口径**行（应用侧不得出现任何外部地址、端口号或命令行请求示例）；工具边界/红线 2 行同步。
  - `tools/README.md`：定时任务说明与「能力」引言同步为正向表述。
  - `proactive-message/SKILL.md` 接口表、`setup_schedule.py` docstring 与返回 `note`：同步。
- **自查（Owner 口径）**：对 `workspace/` 执行同样的 grep → **0 命中**（本次已实测）。
- 逻辑不变：仍是 `kind=prompt` 创建 3 条任务；发送仍由 Agent 用平台能力完成；数值仍为验证档。

## 2026-10-15 v0.35（主动消息"发送"与普通对话对齐：都走平台能力，脚本不再自己发）
- **Owner 判断（已采纳）**：平台已触发定时任务后，组装与普通对话一致，**发送也应一致**；两者唯一差别是"定时触发依赖平台"。
- `proactive-message/scripts/send.py`：**去掉发送**（删除 `_feishu_send` / urllib / adapter 调用），只做"选内容 → 调 response 组装 → 安全过滤"，返回 `{reply_text, safety_status, should_send, delivery}`。
- `scripts/schedules/check_trigger.py`：只做**门禁 + 组装**，返回 `{triggered, gate, should_send, reply_text, safety_status, delivery, note}`；**不发送**。
- 新增 `proactive-message/scripts/record_send.py`：**发送结果唯一回写入口**（`record_send({user_dir, sent, message_id?, error?})` → `state.last_send_status / last_send_at / last_send_message_id / last_send_error`）。
- 文档同步：`AGENTS.md`（主动 Turn 链、工具边界、失败真实性共 4 处）、`proactive-message/SKILL.md`（接口表 + `send` 小节 + 读写表 + 失败表 + 验证 case）、`response/SKILL.md`、`billing/SKILL.md`（"adapter 超时"→"支付结果未知"）、`tools/README.md`（新增「发送」节）、`TESTING.md`。
- 效果：应用侧再没有任何发送用的 HTTP/端点；主动消息发送由 **Agent 用平台注入的「发消息到当前群」能力**完成——与普通 Turn 同一条能力。
- 数值不变：仍为验证档（唤醒 660s / 门禁 J=20min·P=10min / proactive `notify`）。

## 2026-10-15 v0.34（定时任务改用 **`schedule.create` 动态工具**；清理 skill 里旧的 curl 表述）
- **Owner 给出的权威创建方式**（已写入 `AGENTS.md`「创建方式（重要）」）：定时任务**必须用 `schedule.create` 动态工具创建**，**不要 curl / HTTP / `$BASE_URL/sandbox/v1/schedules`**；工具由 **Bot 运行时自动注入**，无需任何端点或 adapter。
  - 可用工具：`schedule.create`（`kind` = `prompt` | `script`）、`schedule.list_own`、`schedule.update`。
- **v0.33 失败原因（Owner 定位）**：`AGENTS.md` 虽已写"不直连/不出现端点/不自行 curl"，但**skill 正文仍描述旧的 curl 方式**，AI 跟着 skill 走了。本版把旧表述全部清掉：
  - `proactive-message/SKILL.md`：接口表 `setup_schedule` 行、`setup_schedule` 小节（性质/逻辑/能力状态）、失败表「schedule 适配器超时」→ 全部改成 `schedule.create` 动态工具。
  - `intro/SKILL.md`：引导第 7 步、副作用行、「setup_schedule 适配器超时」行。
  - `AGENTS.md`：工具边界 / 红线 / 发布边界 / 「定时任务」节共 6 处 → 统一为「用 `schedule.create` 动态工具创建（`kind=prompt`，将来可 `kind=script`）」。
  - `tools/README.md`：能力表与「定时任务」节 → 动态工具；`setup_schedule.py` / `ensure_schedules.py` 的 docstring 与 `note` 文本同步（**逻辑未改**）。
- **保留**：`kind=prompt` 为默认（当前可用）；将来平台开 script 能力可切 `kind=script` + `script_path`（脚本已在 `scripts/schedules/`）。
- **数值不变**：仍为验证档（唤醒 660s / 门禁 J=20min·P=10min / proactive `notify`）。

## 2026-10-13 v0.33（应用文档去掉端点，对齐参考应用「独一无二的TA」；数值仍为验证档）
- **背景**：核对参考应用 dev 包（`xiaopaw-dev-独一无二的TA-20261013-033558.zip`）——它的 `workspace/`（54 文件）里 `sandbox/v1` / `/schedules` / `curl` / `http://127` 出现 **0 次**，只引用「Global schedule 能力」；`finalize_onboarding.py` 只**输出任务请求**（`{task_type, schedule, silent, prompt}`），`proactive-reach/SKILL.md` 明确「不创建 Script（调度/时间/发送已有平台能力，不在应用内复制）」。
- **本版**：应用侧文档**不再出现任何端点 / URL / curl**：`AGENTS.md`（工具边界 + 红线 + 「定时任务」节）、`tools/README.md`（Adapters 表 → 能力表 + 去端点）、`proactive-message/SKILL.md` 接口表（`send` 行）。统一表述为「经**平台注入的飞书能力**」「经**运行态 Global schedule 能力（schedule Skill）**创建，应用只输出任务请求，不自行 curl」。
- **保持应用侧架构**：仍保留 `scripts/schedules/*.py` 确定性入口（可机械断言；将来平台开 script 类型可直接切 `action.type=script`）。若要与参考应用完全一致（去掉脚本、门禁写进 SKILL、发送由平台能力做），另行评估。
- **数值不变**：仍为验证档 —— 唤醒 660s（11min）、门禁 J=20min / P=10min、proactive `delivery_mode=notify`。（设计值 88min / J=2h / P=100min / `silent` 待验证通过后恢复）
- 应用代码（.py）与 v0.32 **逐字节一致**，仅文档（.md）变化。

## 2026-10-13 v0.32（Owner 决定：结构回到 `user/` + `workspace/` 分离；文档目录树 = `workspace/` 内部）
- **结构**：恢复 v0.30 及更早的包形 —— 顶层 `workspace/`（**应用本体，只读**，目录树与《目录记忆与知识底座完整设计 v5》一致）+ `user/`（**用户态，可写**）+ 说明文件。**v0.31 的 flat 形态作废**（理由：workspace 只读 / user 每用户可写，需明确分离）。
- **新增包根 `AGENTS.md`（启动引导，非应用资产）**：只说明"应用在 `workspace/`（读其 `AGENTS.md` 作为指令、以骨碌身份运行）、用户态在 `user/`；`WORKSPACE_DIR`/`USER_DIR` 指向哪"。让"直接打开包根目录"也能稳定进骨碌，不必依赖 Agent 自己翻目录。
- **新增 `start.sh`**：导出 `WORKSPACE_DIR=<包根>/workspace` / `USER_DIR=<包根>/user` / `AIPM_STATE=use` 后启动。
- `scripts/schedules/_sched_common.py`：UserDir 兜底保留「应用根内 `user/` 优先 → 同级 `user/`」（对 wrapped 包形无行为变化，仅为兼容两种布局）。
- `README.md` / `TESTING.md`：按 `user/` + `workspace/` 结构重写；补"`.codex` 是隐藏目录（Finder `⌘⇧.`）""`WORKSPACE_DIR` 为空且目录无 `AGENTS.md` → 身份错位"。
- 应用代码与 v0.31 一致（未改业务逻辑）。

## 2026-10-13 v0.31（目录结构对齐设计文档：解压层 = 应用本体；修 UserDir 兜底）
- **背景（实跑诊断）**：v0.30 那次运行时 `WORKSPACE_DIR` 为空、且打开的目录里没有 `AGENTS.md`（应用的 AGENTS.md 一直在 `workspace/` 子层）→ 运行时拿不到应用指令 → 退回平台通用身份（回"我是你的 AIPM 助手"）。v0.27/v0.29 之所以是骨碌，是当轮 Agent **自己去翻目录**读到了 `workspace/AGENTS.md`（v0.27 日志可见：回答前先 `ls` + `cat`），属运气，不是结构差异。
- **核对结论**：v0.29 与 v0.30 包内文件清单**完全一致（80/80）**；应用树 = 设计文档《目录记忆与知识底座完整设计 v5》的 `gulu-app/` 目录树。真正的差异是"打开的是包壳层，不是应用根"。
- **打包形态改 flat**：解压后**顶层即应用本体**（`AGENTS.md` / `manifest.dev.json` / `onboarding.md` / `.codex/skills` / `scripts` / `knowledge` / `memory` / `tools` / `agents`）；同层放 `user/`（用户态）、`README` / `CHANGELOG` / `TESTING`、`start.sh`。旧形态可 `pack_gulu_app.py <ver> wrapped` 生成。
- `scripts/schedules/_sched_common.py`：`resolve_user_dir` 兜底改为「应用根内 `user/` 优先 → 同级 `user/`」，一个包形改动不破两种布局。
- 新增 `start.sh`：显式导出 `WORKSPACE_DIR`(应用根) / `USER_DIR`(应用根/user) / `AIPM_STATE=use` 后启动。
- `README.md` / `TESTING.md`：命令路径去掉 `workspace/` 前缀；补"不要把包壳目录当项目目录；`WORKSPACE_DIR` 为空 + 目录无 `AGENTS.md` → 身份错位"的说明。
- 应用内容与 v0.30 一致（仅 `_sched_common` 兜底），回归照跑。

## 2026-10-13 v0.30（平台定时能力**已接入** → 创建契约可执行化；本版为验证档）
- 背景：Owner 确认底层平台（codex_workspace_bot）**定时任务能力已开启**；此前"引导结束未创建任务"的原因是**平台能力未接入**，非脚本缺陷（证据：v0.29 实跑 state 里 `schedule_last_attempt_at` 有值、`schedule_tasks` 为空、`schedule_pending=true`）
- `setup_schedule`：任务请求改为**可直接提交**的平台契约字段（`name` / `trigger` / `action` / `delivery_mode` / `idempotency_key`），并保留兼容别名（`task_type` / `schedule` / `silent` / `prompt`）
- `AGENTS.md`「定时任务」节：新增**创建契约表**（三条任务的完整参数）＋"原样提交"要求；补"只有 **task_id 回执**才算成功，HTTP 2xx 不算，创建后需能列出这 3 条"
- 清理 S23/S29 旧表述（`proactive-message` / `intro` / `life-event-generator` / `memory-curator` 的 SKILL.md、AGENTS 路由表）→ 统一为"经 Global schedule 能力创建；能力不可用才 `schedule_pending=true`"
- `tools/README.md`、`proactive-message` 接口表、`TESTING.md` 同步**创建参数**与**验证清单**（创建/回写/真触发/门禁/主动消息/失败如实记录）
- **本版仍为验证档**：唤醒 11min（设计值 88min）、proactive `delivery_mode=notify`（设计值 `silent`）；供本轮"确认任务能创建并触发"，通过后恢复设计值出正式版

## 2026-10-13 v0.29（更正：定时能力的准确表述）
- 更正上版不当表述"定时任务不属于 Adapter" → **准确**：应用侧不直连；功能由**平台 Global schedule 能力**提供，**底层为本地 Adapter 合同**（平台未接入则无法创建/触发）
- 依据：参考应用"独一无二的TA"原话（`AGENTS.md` / `proactive-reach/SKILL.md` / `finalize_onboarding.py`）

## 2026-10-13 v0.27（定时任务：明确"走产品流程=引导确认"，非用户口令）
- 澄清：定时任务的触发时机是**引导中确认"是否允许主动联系"** → 据回答在**引导结束自动创建**；**不存在"让用户说口令注册"**
- `AGENTS.md` 新增「触发时机（走产品流程，不靠用户说口令）」；运维诊断脚本**仅供 Owner 排障，不对用户暴露内部术语**
- `intro/SKILL.md`：引导第 7 步改为"输出任务请求 → Agent 经 Global schedule 创建 → confirm 回写（默认开启）"，并清掉 S29/S23 旧表述
- 注意：v0.25/v0.26 的间隔与 silent=false 仍是**临时验证档**

## 2026-10-13 v0.26（⚠️ 临时验证：proactive 任务改非 silent）
- `gulu-proactive` 任务请求 `silent: true → false`：平台每次唤醒会向群里发**结果卡**，便于直观观察"跑没跑 / 门禁结论"
- 仍为**临时**；验证后应改回 `silent: true`

## 2026-10-13 v0.25（⚠️ 临时验证档：缩短间隔）
- **仅为快速验证**：唤醒 **88min → 11min（660s）**；门禁 **J=2h → 20min**、**P=100min → 10min**（降频翻倍 → J=40min / P=20min）
- 同步：`setup_schedule`、`should_disturb`、`scheduler/check_trigger`、`scheduler/README`、`AGENTS.md`、`proactive-message` 接口表、`tools/README`
- **设计文档未改**（仍为设计值 88min / J=2h / P=100min）——验证后应改回

## 2026-10-13 v0.24（schedule_pending 语义修正）
- `setup_schedule`：**不再无条件返回 `schedule_pending=True`**（只输出任务请求）
- `ensure_schedules`：**仅当 state 无该键时**才置 `true`；**已确认(false)不回退**
- `confirm_schedules`：按创建结果置 `false/true`（唯一能"确认已创建"的入口）
- 语义澄清：`schedule_pending=true` = **尚未确认已创建**，不是"永远待注册"

## 2026-10-13 v0.21（记忆模板：Workspace 侧母版 → UserDir 实例化）
- 新增 `memory/templates/`（母版）：`state.example.json` / `user.example.md` / `timeline|shared_events|user-events|life_events.example.jsonl` / `profile|summary|common_topics|topics-index.example.md`
- `intro/init_state`：改为**从模板实例化到 UserDir**（`X.example.EXT → X.EXT`），并为 `user.md` 做占位符替换；模板缺失时回退创建空文件
- `memory/README.md`：补充「Workspace 侧模板 → UserDir 侧实例」说明
- 对齐参考应用（独一无二的TA）的"Workspace 放模板、UserDir 放实例"结构

## 2026-10-13 v0.20（主动任务唤醒间隔：98min → 88min）
- Owner 要求：proactive 定时间隔 **5880s(98min) → 5280s(88min)**
- 同步：`setup_schedule`、`agents_schedules_default`、`tools_README`、`skill_interfaces`、`check_trigger` 注释、源工程 `scheduler/README.md` 与 `AGENTS.md`、发布壳 `proactive-message/SKILL.md`
- 注意：这里的 88min 是**任务唤醒节奏**（多久检查一次）；真正"发不发"仍由门禁间隔（J=2h / P=100min）决定

## 2026-10-13 v0.19（定时任务对齐 XiaoPaw 约定：Global schedule + 固定 Prompt）
- 参考「独一无二的TA」的实现，改为：应用**只输出任务请求**，由**运行态 Agent 经 Global schedule 能力**创建**固定 Prompt** 任务；**应用不再直连** `/sandbox/v1/schedules`
- `setup_schedule` 重写：输出任务请求（proactive=interval/fixed-delay 5880s；curate/life-event=cron）；**proactive 不得写成五段 Cron**
- 新增 `confirm_schedules`：创建成功后回写 `state.schedule_tasks` + `schedule_pending=false`
- `ensure_schedules` 同步改为"出请求 + 保持 pending"
- `proactive_allowed=false` → **不产出 proactive 任务**
- 文档同步：AGENTS/tools/接口表（去除"直连 adapter"表述）

## 2026-10-10 v0.18（定时任务默认开启：幂等兜底注册）
- Owner 规则：**三个定时任务默认开启**；只有"主动消息"受用户许可约束
- 新增 `proactive-message/ensure_schedules`：**幂等兜底注册**（任何时刻可调；据结果更新 `state.schedule_pending`）
- `AGENTS.md` 新增"定时任务默认开启"小节：引导时自动注册 + 任何时候 `schedule_pending=true` 就幂等补齐；口令「注册/检查定时任务」
- 仍保留 v0.17 的 `notify` 诊断态（先看任务跑没跑），定位后改回 silent
- 回归：**AC 21/21**

## 2026-10-10 v0.17（诊断态：主动任务改 notify）
- 为定位"v0.10 使用态收不到主动消息"，把 `gulu-proactive` 任务临时改为 **`delivery_mode="notify"`**（idempotency_key → `gulu:proactive:notify-v1` 以强制重建）
- 目的：平台每次唤醒会把 `check_trigger` **脚本结果卡**发到群里，可直接看到"跑没跑 / 门禁结论 / 是否 no_state"
- ⚠️ 诊断用，定位后应改回 `silent` + `gulu:proactive:v1`

## 2026-10-10 v0.16（AF-11 修复 + 引导新增"主动消息许可"）
- **修 AF-11**：`init_state` 补写 `last_interaction_at`（引导即一次互动）→ 修复"未开口就每轮都主动发"的间隔基准缺失
- **新功能（Owner 要求）**：引导中询问"是否允许 AI 主动发消息"
  - 新增 `intro/set_proactive_consent.set_consent({user_dir, answer})`：**明确拒绝→false；同意/未明确回答→默认 true**
  - `state.md` 新增字段 `proactive_allowed`（`init_state` 默认 true）
  - `should_disturb` 最先判 `proactive_allowed is False` → 不发送；`check_trigger` 透传
  - 文档同步：`intro/SKILL.md` 许可步骤与话术、`AGENTS.md` 红线、`proactive-message` 接口表、`memory/README` 字段
- 回归：**AC 21/21**；验证：`不用`→不发、未明确→默认发、引导后 50min 不发

## 2026-10-10 v0.15（阶段边界校验 + 阈值读文件）
- `llm_generate`：生成后校验加入**阶段边界**（读 `stage-boundaries.json` 的 forbidden 类别，如 stranger 的"追问式"）→ 生成若越界则重试
- `dialogue/advance_stage`：阈值改为**从 `knowledge/personas/{mbti}/stage-boundaries.json` 读取**（此前硬编码 10/30），`orchestrate_turn` 透传 persona_mbti
- 回归：**AC 21/21**
- 更新 Bad Case 记录（AF-09/AF-10）

## 2026-10-10 v0.14（降频恢复修复）
- 修复：`record_interaction` 的 user_initiated 分支未把 `unanswered_count` 归零 → 用户已回复仍永久降频（BC-003）
- 新增：`demo/gulu-app-bad-cases.md` —— Bad Case 专用记录（Owner 报告 + 内检发现）

## 2026-10-10 v0.13（未成年人保护落地）
- 背景：SKILL 文档写了未成年保护（禁付费重抽/禁会员/不进 intimate/降频），但**判定函数未接收 `is_minor`**，未落地
- 实现：
  - `billing/redraft_engine`：`is_minor` → 禁付费重抽（`permitted=false, minor_blocked=true`）
  - `billing/member_manager`：`is_minor` → 禁会员（`actions=["block_minor"]`）
  - `dialogue/advance_stage`：`is_minor` → 不推进到 `intimate`（停在 familiar）
  - `proactive-message/should_disturb`：`is_minor` → 最低间隔 120min（降频）
  - 透传链：`should_disturb`←check_trigger（state）、`advance_stage`←orchestrate_turn（state）、`redraft`/`member_manager`←apply_redraft/apply_membership（state.is_minor）
- 验证：以上四项对 is_minor=true 生效、对成年无影响；**AC-01~21 仍 21/21**

## 2026-10-10 v0.12（重抽规则文案纠错）
- Owner 测试发现：骨碌口播"最多重抽 3 次"错误（会让人以为能抽 4 张卡）
- **权威规则**：`draw_count` = 已抽到卡数；首次免费(=1)；付费重抽允许到 `draw_count<3` → **最多 2 次付费重抽**；到 **3 张卡**上限→三路径留存
- 纠正文案：`intro/SKILL.md`（骨碌念的那句）、`billing/SKILL.md` 定价阶梯、`AGENTS.md` 红线、`onboarding.md`
- 代码判定本就正确（`draw_count >= 3 → permitted=false`），仅文案错

## 2026-10-10 v0.11（CAP-05 人格一致性 + 定时任务排障 + Journey 回归）
- 背景：AC 回归发现 **AC-20 偶发**（ENFP 回复偶尔无标记词）——与 AC-21 同类随机失效
- `scripts/llm_generate.py`：
  - 正向要求加固：生成规则 1 改为「**必须至少出现 1 个语气标记词**」
  - 新增**生成后人格校验 + 有限重试**（最多 3 次）：必须含本卡标记词、不得含他人格标记词，不合规则再生成
- 验证：ENTJ 越界 0/6、ENFP 缺 marker 0/4；**完整 AC-01~21 回归 21/21（64/64 断言）**
- `setup_schedule.py` 新增 `list_schedules()` 与 `--list`：可直接列出当前群已注册的定时任务（便于确认是否注册成功）
- **Journey 1~4 回归：12/12 断言全过**（连续性打通）
- **`record_interaction` 状态读取容错**：原用 `json.load`，若 state.md 为旧版 Markdown 会异常退化为 `{}` **清空全部状态**；现改为「先 JSON、失败再 Markdown」解析（验证：Markdown 状态保留且计数正确递增）

## 2026-10-10 v0.10（主动消息间隔调整：J=2h / P=100min）
- 按 Owner 要求，`should_disturb` 门禁间隔：**J 型 6h→2h**、**P 型 4h→100min**（连续 3 次未回复降频翻倍 → J=4h / P=200min）
- 同步源工程 `scheduler/check_trigger.py`、`scheduler/README.md`；并纠正 SKILL.md 旧文案（曾写"J 1h / P 40min"，与代码不符）
- 验证：P 型 90min 不发 / 101min 发；J 型 110min 不发 / 121min 发

## 2026-10-10 v0.9（自测指南 + AC 全量回归）
- 包内新增 `TESTING.md`（自测指南：离线自检 / 手验定时脚本 / 注册任务 / Journey / 观察点 / 已知限制）
- **代码与 v0.8 一致**；仅新增文档
- 权威回归：对组装版重跑 **AC-01~21 → 21/21 用例、64/64 断言全过**

## 2026-10-10 v0.8（proactive 前置安全 gate，AC-03 修复）
- `orchestrate_turn` 增加「生成前」安全 gate：proactive 热搜 content 含敏感词时**直接拦截**（`safety_status=blocked` + 安全替代文案），不进入生成
- 依据 App 红线「敏感词 5 类必过滤；safety_status=blocked 不发原消息」
- 验证：**AC-03 复跑 PASS（3/3）**；此前为链路层 FAIL

## 2026-10-10 v0.7（CAP-05 人格隔离加固 + AC 回归）
- `scripts/llm_generate.py`：system prompt 增加「禁止其他人格语气词」——从**全部人格卡动态汇总**别的人格 markers 作为禁止项（非硬编码），并加生成规则 7
- 背景：对组装版跑 AC-01~21，**AC-21（ENTJ 差异化）偶发**出现 ENFP 语气词"嘛"
- 验证：加固后 ENTJ ×5 抽 0 次越界；ENFP 仍正常带 markers

## v0.6（memory / tools 组件实质化）
- `memory/README.md` / `tools/README.md` 按组装实况写实

## 2026-10-10 v0.6（memory / tools 组件实质化）
- `memory/README.md`：补齐 state.md 真实写入者（init_state/collect_user_info/record_interaction/apply_membership/apply_redraft）、冻结/会员落盘语义、完整 state 字段
- `tools/README.md`：按组装实况更新（send 真实发送、setup_schedule 注册 3 任务、LLM 与覆盖变量、state.md 为 JSON）

## 2026-10-10 v0.5（冻结链闭合 + 重抽落盘）
### 修复
- `orchestrate_turn` 的 `frozen` 与 `permanently_blocked` 缺省改为**从 state 读取**（此前冻结落盘后不被使用 → 记忆冻结链断裂）
- 新增 `billing/apply_redraft.py`：支付→重抽→写 `state.persona_bound` / `draw_count`（模式重置）；达 3 次上限返回三路径留存
### 验证
- 到期→`state.frozen=true`→`load_context.degraded=true`；orchestrate 自取 frozen 生效
- 重抽 `draw_count` 1→2→3、persona 更新；达上限 → 不许可 + 三路径齐全

## v0.4（SKILL.md 接口对齐）
- 7 个 SKILL.md 顶部注入「权威接口表（以代码为准）」，修正旧文案与真实签名不一致

## v0.3（状态自洽）
- orchestrate_turn 自读 state（人格/阶段/模式/连续计数）；stage 与模式状态落盘
- 新增 `billing/apply_membership.py`（会员开通/到期 → state.frozen）

## v0.2（onboarding 状态初始化）
- 新增 `scripts/state_store.py`、`intro/scripts/{init_state,collect_user_info}.py`
- onboarding 现会写 state.md（此前不写 → 主动消息用默认人格）

## v0.1（首次组装 + 定时任务修复）
- gulu-demo → XiaoPaw 应用形态（7 Skill + scripts + knowledge + schedules）
- 定时任务修复 S-1~S-4：状态路径 / 格式容忍 / 真实发送 / 任务注册

## 已知待办
- SKILL.md 正文旧表述仍存在（顶部已加权威接口表覆盖）
- state.md 采用 JSON（读时容忍 Markdown）；如需统一 Markdown 可切换
