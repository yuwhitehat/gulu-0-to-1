"""记忆冻结判定（免费用户超出试用期）+ 解冻。

Memory Curator Skill 独占逻辑。
输入：{ user_member_status, trial_expired, member_just_activated? }
输出：{ frozen, reason, action }
"""
import json


def check(input_data: dict) -> dict:
    member_status = input_data.get("user_member_status", "trial")
    trial_expired = input_data.get("trial_expired", False)
    member_just_activated = input_data.get("member_just_activated", False)

    # 会员开通 → 解冻
    if member_just_activated or member_status == "active":
        return {"frozen": False, "reason": "member_active: 会员有效，记忆解冻",
                "action": "unfreeze"}

    # 免费试用期满未付费 → 冻结
    if trial_expired or member_status == "expired":
        return {"frozen": True,
                "reason": "trial_expired: 免费试用期后未付费，记忆冻结不删除",
                "action": "freeze"}

    # 免费试用期内 → 不冻结
    return {"frozen": False, "reason": "trial_active: 试用期内，记忆全功能",
            "action": "none"}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = check(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
