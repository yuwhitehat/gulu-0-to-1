"""定时整理 + 超期清理。

Memory Curator Skill 独占逻辑。
每天凌晨 00:30 由 scheduler 触发。当天无对话则跳过。
整理事件流水→结构化画像/摘要/话题索引；超期清理。
输入：{ current_date, persona_mbti, has_interaction, user_dir }
输出：{ skipped, profile_updated, summary_updated, common_topics_updated, topics_index_updated, expired_chat_cleaned, expired_life_events_deleted }
"""
import json
import os
import sys
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from safety_filter import filter_text
from interaction_signal import classify as classify_signal


def _read_jsonl(path: str) -> list:
    if not os.path.exists(path):
        return []
    entries = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return entries


def curate(input_data: dict) -> dict:
    current_date = input_data.get("current_date", "")
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    has_interaction = input_data.get("has_interaction", False)
    user_dir = input_data.get("user_dir", "")

    # 0. 当天无对话则跳过
    if not has_interaction:
        return {"skipped": True, "profile_updated": False, "summary_updated": False,
                "common_topics_updated": False, "topics_index_updated": False,
                "expired_chat_cleaned": 0, "expired_life_events_deleted": 0}

    if not user_dir:
        return {"skipped": False, "profile_updated": False, "summary_updated": False,
                "common_topics_updated": False, "topics_index_updated": False,
                "expired_chat_cleaned": 0, "expired_life_events_deleted": 0}

    os.makedirs(user_dir, exist_ok=True)
    timeline_path = os.path.join(user_dir, "timeline.jsonl")
    life_events_path = os.path.join(user_dir, "life_events.jsonl")
    profile_path = os.path.join(user_dir, "profile.md")
    summary_path = os.path.join(user_dir, "summary.md")
    common_topics_path = os.path.join(user_dir, "common_topics.md")
    topics_index_path = os.path.join(user_dir, "topics-index.md")

    timeline = _read_jsonl(timeline_path)

    # 1. 提取偏好信号 → 更新 profile.md
    profile = {}
    if os.path.exists(profile_path):
        try:
            profile = json.load(open(profile_path, encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            profile = {}

    preferences = profile.get("preferences", {})
    for entry in timeline:
        if entry.get("trigger_mode") == "user_initiated":
            msg = entry.get("user_message", "")
            # v0.7：改用共享判定（修 D-04）。原写法 "嗯" in msg or "对" in msg
            # 会把"不对""不同意"计为同意。
            sig = classify_signal(msg)["signal"]
            if sig == "complaint":
                preferences["complaint"] = True
            elif sig == "agree":
                preferences["agree_count"] = preferences.get("agree_count", 0) + 1
            elif sig == "disagree":
                preferences["disagree_count"] = preferences.get("disagree_count", 0) + 1

    profile["preferences"] = preferences
    profile["persona_mbti"] = persona_mbti
    with open(profile_path, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)
    profile_updated = True

    # 2. 提取关键事件 → 追加 summary.md
    summary = {}
    if os.path.exists(summary_path):
        try:
            summary = json.load(open(summary_path, encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            summary = {}

    key_events = summary.get("key_events", [])
    for entry in timeline:
        msg = entry.get("user_message", "")
        if any(kw in msg for kw in ["搬家", "生日", "换工作", "辞职"]):
            key_events.append({"date": current_date, "event": msg[:30]})

    summary["key_events"] = key_events
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    summary_updated = True

    # 3. 共同话题 → 更新 common_topics.md + topics-index.md
    common_topics = {"topics": []}
    if os.path.exists(common_topics_path):
        try:
            common_topics = json.load(open(common_topics_path, encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            pass

    topics_index = {"index": []}
    if os.path.exists(topics_index_path):
        try:
            topics_index = json.load(open(topics_index_path, encoding="utf-8"))
        except (json.JSONDecodeError, ValueError):
            pass

    for entry in timeline:
        msg = entry.get("user_message", "") or entry.get("ai_message", "")
        if msg and msg not in [t.get("text", "") for t in common_topics["topics"]]:
            filtered = filter_text(msg)
            if filtered["safety_status"] == "pass":
                common_topics["topics"].append({"text": msg[:20], "date": current_date})
                topics_index["index"].append({"text": msg[:10], "date": current_date})

    with open(common_topics_path, "w", encoding="utf-8") as f:
        json.dump(common_topics, f, ensure_ascii=False, indent=2)
    common_topics_updated = True

    with open(topics_index_path, "w", encoding="utf-8") as f:
        json.dump(topics_index, f, ensure_ascii=False, indent=2)
    topics_index_updated = True

    # 4. 超期清理：life_events 超 7 天物理删除
    expired_life_events_deleted = 0
    if os.path.exists(life_events_path):
        cutoff = datetime.now(timezone(timedelta(hours=8))) - timedelta(days=7)
        remaining = []
        for line in open(life_events_path, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
                evt_date = datetime.fromisoformat(evt.get("date", ""))
                if evt_date.tzinfo is None:
                    evt_date = evt_date.replace(tzinfo=timezone(timedelta(hours=8)))
                if evt_date >= cutoff:
                    remaining.append(line)
                else:
                    expired_life_events_deleted += 1
            except (ValueError, KeyError):
                remaining.append(line)
        with open(life_events_path, "w", encoding="utf-8") as f:
            for line in remaining:
                f.write(line + "\n")

    # 5. 日常闲聊超 7 天降权（标记 archived，超 14 天归档）
    expired_chat_cleaned = 0
    if os.path.exists(timeline_path):
        cutoff_7 = datetime.now(timezone(timedelta(hours=8))) - timedelta(days=7)
        cutoff_14 = datetime.now(timezone(timedelta(hours=8))) - timedelta(days=14)
        remaining_timeline = []
        for line in open(timeline_path, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                ts = entry.get("timestamp", "")
                if ts:
                    ts_dt = datetime.fromisoformat(ts)
                    if ts_dt.tzinfo is None:
                        ts_dt = ts_dt.replace(tzinfo=timezone(timedelta(hours=8)))
                    if ts_dt < cutoff_14:
                        entry["status"] = "archived"
                        expired_chat_cleaned += 1
                    elif ts_dt < cutoff_7:
                        entry["status"] = "low_weight"
                        expired_chat_cleaned += 1
                remaining_timeline.append(json.dumps(entry, ensure_ascii=False))
            except (ValueError, KeyError):
                remaining_timeline.append(line)
        with open(timeline_path, "w", encoding="utf-8") as f:
            for line in remaining_timeline:
                f.write(line + "\n")

    return {
        "skipped": False,
        "profile_updated": profile_updated,
        "summary_updated": summary_updated,
        "common_topics_updated": common_topics_updated,
        "topics_index_updated": topics_index_updated,
        "expired_chat_cleaned": expired_chat_cleaned,
        "expired_life_events_deleted": expired_life_events_deleted,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = curate(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
