"""记忆纠正（用户指出记错时更新条目）。

Memory Curator Skill 独占逻辑。
输入：{ wrong_entry_id, corrected_content, persona_mbti }
输出：{ corrected, correction_hint }
"""
import json
import os


def correct(input_data: dict) -> dict:
    wrong_entry_id = input_data.get("wrong_entry_id", "")
    corrected_content = input_data.get("corrected_content", "")
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    user_dir = input_data.get("user_dir", "")

    if not wrong_entry_id or not user_dir:
        return {"corrected": False, "correction_hint": None}

    timeline_path = os.path.join(user_dir, "timeline.jsonl")
    if not os.path.exists(timeline_path):
        return {"corrected": False, "correction_hint": None}

    entries = []
    found = False
    with open(timeline_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                if entry.get("id") == wrong_entry_id or str(len(entries)) == wrong_entry_id:
                    entry["corrected"] = True
                    entry["corrected_content"] = corrected_content
                    entry["corrected_at"] = "now"
                    found = True
                entries.append(entry)
            except json.JSONDecodeError:
                entries.append(json.loads(line) if line else {})

    if not found:
        return {"corrected": False, "correction_hint": None}

    with open(timeline_path, "w", encoding="utf-8") as f:
        for entry in entries:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    # 性格化纠正提示
    hint_map = {
        "ENTJ": f"……好，我记错了，是{corrected_content[:10]}。那区别确实大了——总之我记下了。",
        "ENFP": f"啊我记错了嘛！是{corrected_content[:10]}——这次我肯定记住了！",
        "ENTP": f"好吧，我承认记错了。是{corrected_content[:10]}，不是之前那个。",
        "ENFJ": f"抱歉，我记错了。是{corrected_content[:10]}，我更新好了。",
    }
    hint = hint_map.get(persona_mbti, hint_map["ENFP"])

    return {"corrected": True, "correction_hint": hint}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = correct(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
