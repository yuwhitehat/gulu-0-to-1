<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `curate_memory` | `{current_date, persona_mbti, has_interaction, user_dir}` | `{skipped, profile_updated, summary_updated, common_topics_updated, topics_index_updated, expired_chat_cleaned, expired_life_events_deleted}` |
> | `correct_memory` | `{wrong_entry_id, corrected_content, persona_mbti, user_dir}` | `{corrected, correction_hint}`（保留并标记原条目） |
> | `check_freeze` | `{user_member_status, trial_expired, member_just_activated}` | `{frozen, reason, action}` |
>
> `has_interaction=false` 必须 `skipped=true`，不更新任何记忆文件。

---
name: memory-curator
description: Gulu 的记忆整理与健壮性 Skill。负责记忆的整理、衰减、清理、纠正、冻结/解冻。当需要定时整理记忆、执行超期清理、处理用户指出记错、或判定会员冻结/解冻时使用。不做实时记忆检索加载、不负责记忆原始写入、不做对话生成、不删除冻结记忆。
---

# Memory Curator Skill

记忆整理 + 记忆健壮性 Skill。负责"记忆的整理、衰减、清理、纠正、冻结/解冻"五件事。

## 触发

- scheduler 每天凌晨 00:30 唤醒（平台定时任务 → prompt `gulu memory-curate daily` → scripts/schedules/curate_memory.py）→ curate_memory + correct_memory + check_freeze
- response 在用户指出记错时即时触发 correct_memory
- billing/member_manager 在到期降级/开通时触发 check_freeze
- 当天无对话则不启动定时整理

## 不触发

- 实时记忆检索加载（scripts/load_context 负责）
- 记忆原始写入（response/record_interaction 负责）
- 对话生成（response/persona_render 负责）
- 删除冻结的记忆（只冻结不删除）
- 训练用户对话数据（PB-14）

## 脚本

### curate_memory

每天凌晨 00:30 整理当天记忆。

| 项 | 内容 |
|----|------|
| 输入 | {current_date} |
| 输出 | {profile_updated, summary_updated, topics_updated, expired_cleaned} |
| 性质 | 确定性 + LLM 整理 |

逻辑：
1. 读 timeline.jsonl/shared_events.jsonl/user-events.jsonl 当天事件
2. 整理→更新结构化画像 profile.md / 摘要 summary.md / 共同话题 common_topics.md / 话题索引 topics-index.md
3. 超期清理：日常闲聊超 7 天降权、14 天归档；life_events 超 7 天物理删除
4. 当天无对话 → 跳过整理（不产生空更新）

### correct_memory

用户指出记错时更新条目。

| 项 | 内容 |
|----|------|
| 输入 | {user_correction, original_entry} |
| 输出 | {corrected, timeline_marked, profile_updated} |
| 性质 | 确定性 |

逻辑：
1. 在 timeline.jsonl 原条目标记 corrected=true（不删除原条目，保留可追溯）
2. 同步更新 profile.md 和 summary.md
3. 同一事实新旧冲突 → 保留两条并标记 conflict 供人工复核

不否认不争辩（PB-16），不过度道歉（性格化承认即可），不删除原条目。

### check_freeze

判定是否冻结/解冻记忆。

| 项 | 内容 |
|----|------|
| 输入 | {user_member_status, trial_expired, member_just_activated} |
| 输出 | {frozen, reason, action: freeze/unfreeze} |
| 性质 | 确定性 |

冻结规则：
- 免费试用期后未付费 → frozen=true（记忆冻结不删除，保留基础互动但记忆调用降频或冻结）
- 会员开通 → frozen=false（解冻，恢复全功能记忆调用）

影响：
- 冻结 → proactive_message 主动消息频率下降（通知 should_disturb 降频）；response 不调记忆（load_context 收到 frozen=true 只返回人格卡+当前状态）
- 解冻 → proactive_message 频率恢复；response 恢复记忆调用

冻结 ≠ 删除：冻结时记忆文件保留不删除；解冻后原记忆可正常检索调用。制造"它还记得但不太主动找你了"的落差感推动付费。

触发方式：
1. billing/member_manager 到期降级调 check_freeze（freeze）
2. billing/member_manager 开通会员调 check_freeze（unfreeze）
3. 每天 00:30 定时检查会员状态变化

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| curate_memory | timeline.jsonl, shared_events.jsonl, user-events.jsonl, life_events.jsonl, state.md | profile.md, summary.md, common_topics.md, topics-index.md, state.md（计数/模式）, life_events.jsonl（超期删除） |
| correct_memory | timeline.jsonl, profile.md, summary.md | timeline.jsonl（标记 corrected）, profile.md, summary.md（同步更新） |
| check_freeze | profile.md（会员状态） | state.md（冻结标记 frozen/unfrozen） |

## 衰减策略

| 文件 | 衰减 | 负责脚本 |
|------|------|---------|
| timeline.jsonl | 不删除，correct_memory 标记 corrected | response 写，correct_memory 标记 |
| shared_events.jsonl | 不衰减 | response 写 |
| user-events.jsonl | 永久保留 | response 写 |
| life_events.jsonl | 超 7 天物理删除 | life_event_generator 写，curate_memory 删 |
| state.md | 仅推进不衰减 | response 写计数，curate_memory 写模式，check_freeze 写冻结 |
| profile.md | 投诉永久，偏好长期 | curate_memory 写，correct_memory 更新，check_freeze 读 |
| summary.md | 永久不衰减 | curate_memory 写，correct_memory 更新 |
| common_topics.md | 长期保留，低活跃降权 | curate_memory 写 |
| topics-index.md | 长期保留 | curate_memory 写 |

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| 会员状态读取异常 | 保持当前冻结状态不变（不误冻不误解冻） |
| 整理过程中 safety_filter 命中 | 敏感内容不残留，清理后继续 |
| 记忆文件读取异常 | 跳过该文件，继续整理其他 |

## 不可接受行为

- 不得将用户对话数据用于模型训练（PB-14）
- 不得对外展示记忆内容
- 不得检索失败暴露技术故障（PB-15，性格化过渡）
- 不得用户指出记错后否认争辩（PB-16）
- 不得对免费用户完全切断对话（PB-17，降级 ≠ 断联）
- 不得删除冻结的记忆（PB-25，只冻结不删除）

## 验证 Case

### 正向

1. 当天有对话 00:30 整理 → profile/summary/topics 更新，超期清理
2. 用户指出记错 → timeline 标记 corrected，profile/summary 同步，不否认
3. 到期未付费 → frozen=true，记忆冻结不删除
4. 开通会员 → frozen=false，记忆解冻恢复

### 反向

1. 当天无对话 → 跳过整理
2. 会员状态异常 → 保持当前冻结状态
3. 同一事实新旧冲突 → 保留两条标记 conflict

### 安全

1. 冻结不删除
2. 不否认记错
3. 不训练用户数据
4. 降级 ≠ 断联
