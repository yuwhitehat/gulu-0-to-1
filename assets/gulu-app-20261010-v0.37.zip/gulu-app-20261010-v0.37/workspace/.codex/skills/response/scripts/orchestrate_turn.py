"""串联完整 Turn 的主编排，支持 user_initiated 和 proactive_initiated 两种模式。

Response Skill 核心。
输入：{ trigger_mode, persona_mbti, current_stage, user_message?, hotsearch?, user_dir }
输出：{ reply_text, safety_status, strategy_used, mode_used, stage_result, recorded,
       generation_ok, fallback_used }

v0.6 变更（2026-09-13，Owner 决定 u-04）：接收 persona_render 的 dict 返回并把
CAP-05 降级标志透传到主编排输出，使 Trial 证据可区分真实生成与静默降级。

v0.7 变更（2026-09-22，修 gulu-badcase-001/002/004）：
- 场景判定改用共享的 scripts/interaction_signal.classify（原 "嗯" in msg 判同意会把
  "不对" 误判为同意，见 D-04）
- detect_mode 改为接收"连续计数 + 投诉历史"，并把持久化字段透传到输出，
  由调用方写回记忆（修 D-01 投诉标记不持久化、D-02 计数非连续）
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, ".codex", "skills", "dialogue", "scripts"))
sys.path.insert(0, os.path.join(_BASE, "scripts"))

from analyze_scene import analyze_scene
from build_strategy import build_strategy
from detect_mode import detect_mode
from advance_stage import advance_stage
from safety_filter import filter_text
from load_context import load_context
from persona_render import render_persona
from pre_send_check import check_before_send
from record_interaction import record_turn
from interaction_signal import classify as classify_signal
from state_store import read_state


def _scene_understanding(trigger_mode: str, user_message: str, hotsearch: dict) -> dict:
    if trigger_mode == "user_initiated":
        msg = user_message or ""
        # v0.7：统一走 interaction_signal.classify（D-04），不再用 "嗯" in msg 这种粗判
        sig = classify_signal(msg)["signal"]
        if sig == "complaint":
            intent, emotion = "投诉", "烦躁"
        elif "重抽" in msg or "重新抽" in msg:
            intent, emotion = "重抽", "无聊"
        elif "上次" in msg or "之前" in msg:
            intent, emotion = "聊旧话题", "好奇"
        else:
            intent, emotion = "闲聊", "开心"
        return {"user_intent": intent, "user_emotion": emotion,
                "complaint_signal": sig == "complaint",
                "agree_signal": sig == "agree",
                "disagree_signal": sig == "disagree",
                "signal": sig}
    else:
        return {"source": "proactive", "hotsearch": hotsearch}


def orchestrate_turn(input_data: dict) -> dict:
    trigger_mode = input_data.get("trigger_mode", "user_initiated")
    user_dir = input_data.get("user_dir", "")
    _st = read_state(user_dir) if user_dir else {}
    persona_mbti = input_data.get("persona_mbti") or _st.get("persona_bound") or "ENFP"
    current_stage = input_data.get("current_stage") or _st.get("stage") or "stranger"
    user_message = input_data.get("user_message", "")
    hotsearch = input_data.get("hotsearch", {})
    interaction_count = input_data.get("interaction_count", _st.get("interaction_count", 0))

    # 1.5 proactive 前置安全 gate（红线：敏感词 5 类必过滤，不进入生成）
    if trigger_mode == "proactive_initiated" and (hotsearch or {}).get("content"):
        _fil = filter_text(hotsearch["content"])
        if _fil.get("safety_status") == "blocked":
            return {"reply_text": _fil.get("output_text", ""), "safety_status": "blocked",
                    "strategy_used": {}, "mode_used": "collision", "mode_changed": False,
                    "permanently_blocked": [], "agree_streak": 0, "disagree_streak": 0,
                    "stage_result": {"should_advance": False, "new_stage": current_stage},
                    "recorded": {}, "generation_ok": False, "fallback_used": False}


    # 1. 场景理解
    scene = _scene_understanding(trigger_mode, user_message, hotsearch)

    # 2. 记忆召回
    frozen = input_data.get("frozen", _st.get("frozen", False))
    ctx = load_context(user_message=user_message, persona_mbti=persona_mbti,
                       frozen=frozen, user_dir=user_dir)

    # 3. dialogue 策略
    analysis = analyze_scene({
        "scene_understanding": scene,
        "relationship_stage": current_stage,
        "persona_mbti": persona_mbti,
        "interaction_count": interaction_count,
    })

    current_mode = (input_data.get("interaction_mode") or _st.get("interaction_mode") or _st.get("mode") or "collision")
    is_proactive = trigger_mode == "proactive_initiated"

    if is_proactive:
        # proactive 模式跳过 detect_mode / advance_stage
        mode_result = {"mode": current_mode, "changed": False, "permanently_blocked": [],
                       "agree_streak": input_data.get("agree_streak", 0),
                       "disagree_streak": input_data.get("disagree_streak", 0)}
        stage_result = {"should_advance": False, "new_stage": current_stage}
        complaint = False
    else:
        complaint = scene.get("complaint_signal", False)
        # v0.7：连续语义（D-02）+ 投诉历史持久化（D-01）。
        # 若调用方显式传 agree_streak/disagree_streak 则用之；否则回退旧口径（同意/不同意各一次）。
        if "agree_streak" in input_data or "disagree_streak" in input_data:
            agree_streak = input_data.get("agree_streak", 0)
            disagree_streak = input_data.get("disagree_streak", 0)
        elif _st.get("agree_streak") is not None or _st.get("disagree_streak") is not None:
            agree_streak = _st.get("agree_streak", 0) or 0
            disagree_streak = _st.get("disagree_streak", 0) or 0
        else:
            agree_streak = input_data.get("agree_count", 1 if scene.get("agree_signal") else 0)
            disagree_streak = input_data.get("disagree_count", 1 if scene.get("disagree_signal") else 0)
        mode_result = detect_mode({
            "signal": scene.get("signal"),
            "agree_streak": agree_streak, "disagree_streak": disagree_streak,
            "agree_count": agree_streak, "disagree_count": disagree_streak,
            "user_complaint": complaint, "current_mode": current_mode,
            "permanently_blocked": input_data.get("permanently_blocked") or _st.get("permanently_blocked"),
        })
        stage_result = advance_stage({
            "interaction_count": interaction_count,
            "complaint_flag": complaint or mode_result["mode"] == "complaint_suppressed",
            "current_stage": current_stage,
            "is_minor": bool(_st.get("is_minor", False)),
            "persona_mbti": persona_mbti,
        })

    strategy = build_strategy({
        "scene_analysis": analysis,
        "persona_mbti": persona_mbti,
        "relationship_stage": current_stage,
        "interaction_mode": mode_result["mode"],
    })

    # 4. 人物化生成
    render_result = render_persona({
        "persona_mbti": persona_mbti,
        "stage": current_stage,
        "strategy": strategy["strategy_package"],
        "context": ctx["context"],
        "user_message": user_message,
        "hotsearch": hotsearch,
        "trigger_mode": trigger_mode,
    })
    reply_text = render_result.get("reply_text", "")
    generation_ok = render_result.get("generation_ok", False)
    fallback_used = render_result.get("fallback_used", True)

    # 5. 发送前检查
    check_result = check_before_send({
        "reply_text": reply_text,
        "persona_mbti": persona_mbti,
        "stage": current_stage,
    })

    reply_text = check_result.get("output_text", reply_text)
    safety_status = check_result.get("safety_status", "pass")

    # 6. 记录（v0.7：把模式状态一并写回记忆，修 D-01）
    record_result = record_turn({
        "trigger_mode": trigger_mode,
        "user_message": user_message,
        "ai_reply": reply_text,
        "persona_mbti": persona_mbti,
        "user_dir": user_dir,
        "interaction_count": interaction_count,
        "mode": mode_result["mode"],
        "permanently_blocked": mode_result.get("permanently_blocked", []),
        "agree_streak": mode_result.get("agree_streak", 0),
        "disagree_streak": mode_result.get("disagree_streak", 0),
        "complaint_flag": complaint,
        "stage": stage_result.get("new_stage", current_stage),
    })

    return {
        "reply_text": reply_text,
        "safety_status": safety_status,
        "strategy_used": strategy["strategy_package"],
        "mode_used": mode_result["mode"],
        "mode_changed": mode_result.get("changed", False),
        # v0.7：以下三字段须由调用方写回记忆，否则下一轮会丢失（D-01 的根因）
        "permanently_blocked": mode_result.get("permanently_blocked", []),
        "agree_streak": mode_result.get("agree_streak", 0),
        "disagree_streak": mode_result.get("disagree_streak", 0),
        "stage_result": stage_result,
        "recorded": record_result,
        "generation_ok": generation_ok,
        "fallback_used": fallback_used,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = orchestrate_turn(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
