"""发送前检查（安全+边界）。

Response Skill 独占逻辑。
输入：{ reply_text, persona_mbti, stage }
输出：{ safety_status, output_text, blocked_keywords }
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from safety_filter import filter_text


def check_before_send(input_data: dict) -> dict:
    reply_text = input_data.get("reply_text", "")
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    stage = input_data.get("stage", "stranger")

    result = filter_text(reply_text)

    # 阶段边界检查（stranger 不应有撒娇/强烈情绪）
    stage_forbidden = {
        "stranger": ["撒娇", "强烈情绪表达"],
        "familiar": ["撒娇", "强烈情绪表达"],
        "intimate": [],
    }
    forbidden_list = stage_forbidden.get(stage, [])
    for kw in forbidden_list:
        if kw in reply_text:
            result["safety_status"] = "stage_violation"
            result["output_text"] = "（这条不太合适，换个方式说吧）"

    return result


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = check_before_send(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
