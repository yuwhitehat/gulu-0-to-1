"""人物化生成（人格口吻）— CAP-05 性格一致性生成。

Response Skill 独占逻辑。从 v1 规则驱动升级为 LLM 驱动。
调 scripts/llm_generate.py 构造完整人格 prompt 生成性格一致回复。
输入：{ persona_mbti, stage, strategy, context, user_message, hotsearch, trigger_mode }
输出：{ reply_text, generation_ok, fallback_used }

CAP-05 失败处理由 llm_generate 负责（重试 1 次，仍失败性格化承认故障）。

v0.6 变更（2026-09-13，Owner 决定 u-04）：返回值由 str 改为 dict，透传 generation_ok
与 fallback_used，使主编排链路可区分"真实生成"与"静默降级"。原件归档于
demo/archive/pre-v0.6-20260913/。
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from llm_generate import generate


def render_persona(input_data: dict) -> dict:
    """返回 {reply_text, generation_ok, fallback_used}。"""
    result = generate(input_data)
    return {
        "reply_text": result.get("reply_text", ""),
        "generation_ok": bool(result.get("generation_ok", False)),
        "fallback_used": bool(result.get("fallback_used", True)),
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    print(json.dumps(render_persona(data), ensure_ascii=False, indent=2))
