"""记录互动到 jsonl。

Response Skill 独占逻辑。支持两种 trigger_mode。
输入：{ trigger_mode, user_message?, ai_reply, persona_mbti, user_dir, interaction_count,
        permanently_blocked?, agree_streak?, disagree_streak?, mode? }
输出：{ timeline_appended, shared_events_appended, state_updated }

v0.7 变更（2026-09-22，修 gulu-badcase-001）：把模式状态（mode / permanently_blocked /
agree_streak / disagree_streak）持久化进 state.md。修正前这些字段只存在于单次调用的返回值里，
下一轮无从读取，导致投诉标记失效。
"""
import json
import os
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))


def _read_state_tolerant(path):
    """读取 state.md：先按 JSON，失败再按 Markdown key:value（避免旧格式被清空）。"""
    if not os.path.exists(path):
        return {}
    txt = open(path, encoding="utf-8").read()
    try:
        return json.loads(txt)
    except (json.JSONDecodeError, ValueError):
        pass
    out = {}
    for line in txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        k, _, v = line.partition(":")
        k = k.strip(); v = v.strip()
        if v.lower() in ("true", "false"):
            out[k] = (v.lower() == "true")
        elif v == "":
            out[k] = None
        else:
            try:
                out[k] = int(v)
            except ValueError:
                try:
                    out[k] = float(v)
                except ValueError:
                    out[k] = v
    return out

def record_turn(input_data: dict) -> dict:
    trigger_mode = input_data.get("trigger_mode", "user_initiated")
    user_message = input_data.get("user_message", "")
    ai_reply = input_data.get("ai_reply", "")
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    user_dir = input_data.get("user_dir", "")
    interaction_count = input_data.get("interaction_count", 0)

    now = (datetime.now(timezone(timedelta(hours=8)))).isoformat()
    timeline_appended = False
    shared_events_appended = False
    state_updated = False

    if not user_dir:
        return {"timeline_appended": False, "shared_events_appended": False,
                "state_updated": False}

    os.makedirs(user_dir, exist_ok=True)

    # timeline.jsonl: user_initiated 记用户消息+AI回复；proactive 只记AI消息
    timeline_path = os.path.join(user_dir, "timeline.jsonl")
    entry = {
        "timestamp": now,
        "persona_mbti": persona_mbti,
        "trigger_mode": trigger_mode,
    }
    if trigger_mode == "user_initiated":
        entry["user_message"] = user_message
        entry["ai_reply"] = ai_reply
        entry["interaction_count"] = interaction_count + 1
    else:
        entry["ai_message"] = ai_reply
        entry["type"] = "proactive"

    with open(timeline_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    timeline_appended = True

    # shared_events.jsonl: 记本次互动事件
    shared_path = os.path.join(user_dir, "shared_events.jsonl")
    shared_entry = {"timestamp": now, "event": "interaction", "trigger_mode": trigger_mode}
    with open(shared_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(shared_entry, ensure_ascii=False) + "\n")
    shared_events_appended = True

    # state.md: user_initiated → interaction_count+1; proactive → unanswered_count+1, last_proactive_at
    state_path = os.path.join(user_dir, "state.md")
    state = {}
    if os.path.exists(state_path):
        state = _read_state_tolerant(state_path)

    if trigger_mode == "user_initiated":
        state["interaction_count"] = state.get("interaction_count", 0) + 1
        state["last_interaction_at"] = now
        state["unanswered_count"] = 0   # 用户已回复 → 未回复计数归零（否则降频永久卡死）
    else:
        state["last_proactive_at"] = now
        state["unanswered_count"] = state.get("unanswered_count", 0) + 1

    # v0.7：持久化模式状态（D-01 修复的核心）。
    # permanently_blocked 只增不减；complaint_flag 一旦为真不允许被覆盖。
    if "mode" in input_data and input_data["mode"]:
        state["interaction_mode"] = input_data["mode"]
    if input_data.get("permanently_blocked"):
        prev = set(state.get("permanently_blocked") or [])
        state["permanently_blocked"] = sorted(prev | set(input_data["permanently_blocked"]))
    if "agree_streak" in input_data:
        state["agree_streak"] = input_data["agree_streak"]
    if "disagree_streak" in input_data:
        state["disagree_streak"] = input_data["disagree_streak"]
    if input_data.get("complaint_flag"):
        state["complaint_flag"] = True   # 粘性，只置真不清零
    if input_data.get("stage"):
        state["stage"] = input_data["stage"]

    with open(state_path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    state_updated = True

    return {
        "timeline_appended": timeline_appended,
        "shared_events_appended": shared_events_appended,
        "state_updated": state_updated,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = record_turn(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
