"""记忆召回。

Response Skill 独占逻辑。调 scripts/load_context 加载对话上下文。
输入：{ user_message, persona_mbti, frozen, user_dir }
输出：{ context, degraded }
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from load_context import load_context


def recall(input_data: dict) -> dict:
    return load_context(
        user_message=input_data.get("user_message", ""),
        persona_mbti=input_data.get("persona_mbti", "ENFP"),
        frozen=input_data.get("frozen", False),
        user_dir=input_data.get("user_dir", ""),
    )


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = recall(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
