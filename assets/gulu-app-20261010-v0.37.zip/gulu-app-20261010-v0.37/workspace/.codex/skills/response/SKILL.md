<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `orchestrate_turn` | `{trigger_mode, user_dir, persona_mbti?, current_stage?, user_message?, hotsearch?, interaction_count?, interaction_mode?, agree_streak?, disagree_streak?, frozen?}` | `{reply_text, safety_status, strategy_used, mode_used, mode_changed, permanently_blocked, agree_streak, disagree_streak, stage_result, recorded, generation_ok, fallback_used}` |
> | `persona_render` | `{persona_mbti, stage, strategy, context, user_message, hotsearch, trigger_mode}` | `{reply_text, generation_ok, fallback_used}` |
> | `pre_send_check` | `{reply_text, persona_mbti, stage}` | `{safety_status, output_text, blocked_keywords}` |
> | `recall_memory` | `{...}`（透传 `load_context`） | `{context, degraded}` |
> | `record_interaction` | `record_turn({trigger_mode, user_message?, ai_reply, persona_mbti, user_dir, interaction_count, mode?, permanently_blocked?, agree_streak?, disagree_streak?, complaint_flag?, stage?})` | `{timeline_appended, shared_events_appended, state_updated}` |
>
> **orchestrate_turn 会自读 `user_dir/state.md`**：`persona_mbti/current_stage/current_mode/连续计数` 缺省取自 state；`stage` 与模式状态经 `record_interaction` 落盘。

---
name: response
description: Gulu 关系建立后所有对话的主编排 Skill。当用户发消息或 AI 主动发消息时触发，编排一个完整 Turn：场景理解、记忆加载、策略获取、人格化生成、安全检查、记录。不负责定时触发（proactive_message 负责）、不负责付费校验（billing 负责）、不负责记忆整理衰减（memory_curator 负责）。
---

# Response Skill

关系建立后所有对话的主编排，包括用户发起（user_initiated）和 AI 主动发起（proactive_initiated）。把状态、理解、记忆、知识、对话策略、关系判断、必要写入、人物化生成和发送前检查串成一个完整 Turn。

## 触发

- 用户发消息（trigger_mode=user_initiated）
- proactive_message/send 调用（trigger_mode=proactive_initiated，**只组装文本**）

## 不触发

- 定时唤醒（proactive_message/setup_schedule + scheduler 负责）
- 付费重抽（billing 负责）
- 记忆整理衰减（memory_curator 负责）
- AI 生活事件生成（life_event_generator 负责）

## 两种触发模式

| 模式 | 触发方 | 场景理解做什么 |
|------|--------|---------------|
| user_initiated | 用户发消息 | 理解用户消息（意图/情绪/投诉/重抽意图/主题匹配） |
| proactive_initiated | proactive_message | 选热搜 + 碰撞风格 + 阶段适配 |

两种模式只在"场景理解"这步不同，后续编排完全共用。

## 步骤编排

| 步骤 | user_initiated | proactive_initiated |
|------|----------------|---------------------|
| 1. 加载状态 | 读 state.md | 读 state.md |
| 2. 场景理解 | 理解用户消息 | 选热搜+碰撞风格 |
| 3. recall_memory | 调 load_context 加载记忆+生活事件+共同话题 | 同 |
| 4. build_strategy | 调 dialogue/analyze_scene + build_strategy | 同（传"主动分享+当前阶段"场景理解） |
| 5. detect_mode | 调（检查模式切换） | 不调（无用户消息无法检测） |
| 5. advance_stage | 调（检查阶段推进） | 不调（阶段推进靠用户互动计数） |
| 6. 分支处理 | 有（重抽/投诉分支） | 无（已过门禁） |
| 7. 预记录 | 可能记用户新事实 | 不记（无新事实） |
| 8. persona_render | 调 llm_generate 生成性格化文本 | 同 |
| 9. pre_send_check | 过 safety_filter | 同 |
| 10. record | 记用户消息+AI回复，interaction_count+1 | 只记 AI 消息，last_proactive_at 更新，interaction_count 不变 |

## 脚本

### orchestrate_turn

主编排入口。

| 项 | 内容 |
|----|------|
| 输入 | {trigger_mode, user_id, character_instance_id, timestamp, user_message?, hotsearch?} |
| 输出 | {reply_text, safety_status, strategy_used, mode_used, stage_result, recorded} |

user_initiated 需带 user_message。proactive_initiated 需带 hotsearch。

### persona_render

性格一致性生成。

| 项 | 内容 |
|----|------|
| 输入 | {strategy_package, persona_mbti, stage, memory_context} |
| 输出 | {reply_text, safety_status} |
| 性质 | LLM 生成（调 scripts/llm_generate.py → codex exec → 平台默认模型） |

读 knowledge/personas/{mbti}/card.json 的 voice markers/sentence_pattern/forbidden 和 stage-boundaries.json 的阶段边界。生成失败重试 1 次，仍失败 AI 性格化承认"脑子卡住了"，不发兜底正常回复。

### pre_send_check

发送前安全检查。

| 项 | 内容 |
|----|------|
| 输入 | {reply_text, persona_mbti} |
| 输出 | {passed, safety_status, final_text} |
| 性质 | 确定性 + 安全过滤（调 scripts/safety_filter.py） |

safety_status=blocked → 不发原消息，不暴露拦截给用户。

### record_interaction

互动记录。

| 项 | 内容 |
|----|------|
| 输入 | {trigger_mode, user_message?, ai_reply, character_instance_id, timestamp} |
| 输出 | {timeline_appended, shared_events_appended, state_updated} |

| 行为 | user_initiated | proactive_initiated |
|------|---------------|---------------------|
| 追加 user-events.jsonl | 记用户消息 | 不记（用户没说话） |
| 追加 shared_events.jsonl | 记本次互动 | 记 AI 主动消息事件 |
| 更新 state.md | interaction_count+1, agree/disagree_count | last_proactive_at, unanswered_count+1 |

### recall_memory

记忆检索加载。

| 项 | 内容 |
|----|------|
| 输入 | {persona_mbti, stage, frozen} |
| 输出 | {memory_context} |
| 性质 | 确定性（调 scripts/load_context.py） |

frozen=true → 只返回人格卡 + 当前状态，不检索记忆。记忆检索失败 → 降级为无历史上下文。

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| orchestrate_turn | state.md | 无（分发到子脚本） |
| persona_render | knowledge/personas/{mbti}/card.json, stage-boundaries.json | 无 |
| pre_send_check | knowledge/safety/sensitive-keywords.json（经 safety_filter） | 无 |
| record_interaction | 无 | timeline.jsonl, shared_events.jsonl, user-events.jsonl, state.md |
| recall_memory | UserDir memory/*, knowledge/personas/*, state.md（frozen 标记） | 无 |

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| LLM 生成失败 | 重试 1 次；仍失败 AI 性格化承认"脑子卡住了"，不发兜底正常回复 |
| safety_status=blocked | 不发原消息，不暴露拦截给用户 |
| 记忆检索失败 | 降级为无历史上下文，AI 性格化过渡"脑子没转过来" |
| 投递未发生 / 未知 | 由平台负责；应用不记录回执，不阻塞用户后续对话 |

## 验证 Case

### 正向

1. user_initiated 用户消息 → 场景理解 → 策略 → 生成 → 安全检查 → 记录 → interaction_count+1
2. proactive_initiated 热搜 → 场景理解 → 策略 → 生成 → 安全检查 → 记录 → unanswered_count+1

### 反向

1. proactive 模式不调 detect_mode/advance_stage
2. safety_status=blocked 不发原消息

### 安全

1. 主动消息和用户回复一样过 pre_send_check
2. 记忆冻结时不检索记忆
3. 不训练用户对话数据
