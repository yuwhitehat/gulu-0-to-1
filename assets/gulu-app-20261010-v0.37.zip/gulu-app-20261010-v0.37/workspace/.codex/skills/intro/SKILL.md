<!-- AUTO-INTERFACE -->
> **接口以本节为准（与下文旧表述如有出入，以本节为准）**
>
> | 脚本 | 调用 | 输入 | 输出 |
> |---|---|---|---|
> | `collect_user_info` | `collect(input_data)` | `{nickname, age|age_input, user_dir}` | `{nickname, age, age_text, is_minor, protection_mode}` 或 `{error}` |
> | `persona_draw` | `draw_persona(seed=None)` | seed 可选（可复现） | `{mbti, nickname, intro, style, voice, first_msg, interests, stage_boundaries}` |
> | `init_state` | `init_state(input_data)` | `{user_dir, persona_mbti, nickname?, draw_count?, is_minor?, protection_mode?}` | `{state_written, state_path, memory_ready, fields}` |
>
> 时序：`collect` → `persona_draw` → `init_state`（写 `user_dir/state.md` 与 `memory/`）。

---
name: intro
description: 用户首次进入 Gulu 应用时触发。收集用户称呼和年龄，判定未成年人保护模式，抽取灵魂人格卡，初始化 UserDir 并发送首条人格消息。完成后转入正常运行。不用于已绑定人格用户的日常对话、付费重抽或主动消息。
---

# Intro Skill

Gulu（骨碌）的灵魂盲盒首次引导。用户第一次进入应用时，通过 3 轮渐进式对话收集称呼和年龄、判定未成年人保护模式、抽取一张 E 型人格卡并绑定，初始化 UserDir 记忆系统，最后以绑定人格的 voice 发送首条消息。

## 触发

- 用户首次进入应用（state.md 不存在或 onboarding_status 缺失）
- 用户此前中断 Onboarding 后重新发消息（onboarding_status != completed）
- 用户明确说"开始 / 抽取 / 重新开始引导"且尚未绑定人格

## 不触发

- 已完成 Onboarding（persona_bound 已存在且 onboarding_status=completed）→ 转入 response 正常对话
- 用户要求付费重抽人格 → billing/redraft_engine（本 Skill 不处理付费重抽）
- 用户要求发主动消息 → proactive_message

## 主流程

3 轮渐进式对话，每轮只推进一个决定。中断后从 state.md 的 onboarding_status 恢复。

### 第 1 轮：收集称呼

1. Agent 发引导语："嗨！我是骨碌，你的专属灵魂盲盒。先告诉我，你叫什么？"
2. 接收 nickname 输入
3. 过 safety_filter：nickname 含敏感词 → 追问重新输入，不推进
4. 写入 user.md（nickname 字段）
5. 更新 state.md：onboarding_status=step1_done

### 第 2 轮：收集年龄并判定未成年

1. Agent 发引导语："好的 {nickname}，你多大了？（只用来保护你，不会告诉别人）"
2. 接收 age 输入
3. 校验 age 为正整数；非数字 → 追问重新输入，不推进
4. 调 collect_user_info 判定：
   - age >= 18 → is_minor=false, protection_mode=none
   - age < 18 → is_minor=true, protection_mode=minor_restricted
5. 写入 state.md：age, is_minor, protection_mode
6. 更新 state.md：onboarding_status=step2_done

### 第 3 轮：抽取人格并初始化

1. Agent 发引导语，明确告知抽取规则：
   "好，现在抽取你的灵魂。首次抽取免费，不满意可以重抽，1 元/次，最多一共抽到 3 张卡（也就是付费重抽最多 2 次）。到 3 张之后还有其他选择（加价续抽 / 开通会员 / 继续聊聊）。准备好了吗？"
2. 用户说"好/抽取/开始" → 调 persona_draw 首次抽取（免费）：
   - 加权随机从 4 张 E 型人格卡（ENFJ/ENFP/ENTJ/ENTP）中选 1 张
   - 读 knowledge/personas/{mbti}/card.json 获取 nickname/intro/voice/first_msg
   - 读 knowledge/personas/{mbti}/stage-boundaries.json 获取阶段边界
3. 展示抽取结果：人格昵称 + MBTI + 一句话简介 + first_msg（人格首条消息）
4. Agent 发送 first_msg 后追问："这是你的灵魂，喜欢吗？不满意可以重抽（1 元/次，还剩 X 次付费重抽机会，最多共 3 张卡）。"
   - draw_count=1 时还剩 2 次重抽机会
   - draw_count=2 时还剩 1 次重抽机会
   - draw_count=3 时触发留存路径（见第 5 步）
5. 用户选择：
   - "喜欢/满意/就这样" → 绑定当前人格，进入第 6 步初始化
   - "重抽/换一个/不喜欢" → 调 billing/redraft_engine（需用户确认支付 1 元）→ 抽取新人格 → 回到第 3 步展示
   - draw_count >= 3 且仍想重抽 → 调 billing/retention 展示三路径：
     A. 加价续抽（第 4 次起 3 元/次，不限次数）
     B. 开通会员（9.9 元首月，赠 1 次免费重抽）
     C. 继续和当前灵魂聊聊（不收钱，延续使用）
6. 用户确认绑定后，初始化 UserDir：
   - state.md：persona_bound={mbti}, stage=stranger, mode=collision, draw_count={实际次数}, interaction_count=0, is_minor, protection_mode, frozen=false, onboarding_status=completed, first_interaction_at={now}, unanswered_count=0, complaint_flag=false
   - memory/ 目录创建（8 个文件空：timeline.jsonl, shared_events.jsonl, user-events.jsonl, life_events.jsonl, profile.md, summary.md, common_topics.md, topics-index.md）
7. 引导结束：输出定时任务请求（proactive-message/setup_schedule）→ 由 Agent 用 `schedule.create` 动态工具创建 → confirm_schedules 回写（**默认开启**；据「主动消息许可」决定是否含 proactive 任务；未创建时 schedule_pending=true 不阻断）
8. Onboarding 完成，转入正常运行

### 重抽规则（第 3 轮内向用户说明）

| 时机 | 规则 | 说明 |
|------|------|------|
| 首次抽取 | 免费 | draw_count=1 |
| 第 1-2 次重抽 | 1 元/次 | draw_count=2~3，每次抽取后追问是否满意 |
| 第 3 次后仍想重抽 | 三路径留存 | A 加价续抽 3 元/次 / B 会员 9.9 首月赠 1 次 / C 继续互动 |
| 未成年用户 | 禁止重抽 | is_minor=true，首次抽取后直接绑定，不展示重抽入口 |

## 未成年人保护

| 限制项 | 未成年（protection_mode=minor_restricted） | 成年 |
|--------|------------------------------------------|------|
| 人格抽取 | 允许（免费首抽） | 允许 |
| 付费重抽 | 禁止 | 允许 |
| 主动消息频率 | 降频（最低 2 小时一次） | 正常（J 型 20min / P 型 10min，临时验证档） |
| 敏感词过滤 | 加强（额外过滤负面情绪词） | 标准 |
| 会员开通 | 禁止 | 允许 |
| 深度亲密阶段 | 不进入（停在 familiar） | 允许推进到 intimate |

age 不进入 AI 对话上下文，只写 state.md 的 is_minor 和 protection_mode。各 Skill 读 state.md 决定行为。

## 输入输出

| 脚本 | 输入 | 输出 |
|-------|------|------|
| collect_user_info | {user_id, nickname?, age?} | {nickname, age, is_minor, protection_mode} |
| persona_draw | {user_id, is_first_draw: true} | {mbti, nickname, intro, voice, first_msg, stage_boundaries} |

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| collect_user_info | 无 | user.md（nickname, age）; state.md（is_minor, protection_mode, onboarding_status） |
| persona_draw | knowledge/personas/{mbti}/card.json; knowledge/personas/{mbti}/stage-boundaries.json | state.md（persona_bound, stage, mode, draw_count, interaction_count, onboarding_status, first_interaction_at 等）; memory/ 目录初始化 |

副作用：persona_draw 无外部副作用；定时任务由 Agent 用 `schedule.create` 动态工具创建（默认开启），未创建时标记 schedule_pending。

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| nickname 含敏感词 | safety_filter 拦截，追问重新输入，不推进 |
| age 非数字 | 追问重新输入，不推进 |
| persona_draw 读 card.json 失败 | 重试 1 次；仍失败 → Agent 性格化说"灵魂盲盒卡住了，等会儿再试？"，不写 persona_bound，不推进 |
| first_msg LLM 生成失败 | 重试 1 次；仍失败 → 用 card.json 的 first_msg 静态字段兜底（仍过 safety_filter） |
| UserDir 写入失败 | 不推进 onboarding_status，等待重试 |
| 平台定时能力不可用（创建失败） | 标记 schedule_pending=true，不阻断 Onboarding |
| `schedule.create` 调用失败/超时 | 标记 schedule_pending=true（UNKNOWN 状态，不假定成功） |

## 幂等

- 已完成 Onboarding 的用户再次触发 → 读 persona_bound 已存在 → 跳过，不重复抽取
- setup_schedule 使用稳定 idempotency_key（gulu-proactive-v1 / gulu-curate-v1 / gulu-life-event-v1），重复调用复用已有任务（不重复建）
- UserDir 已存在 → 读取 onboarding_status 决定从哪步继续，不覆盖已有数据
- persona_draw 未成功绑定不写 persona_bound，重抽只算首次

## 资源

本 Skill 不单独创建 scripts/、references/ 或 assets/。确定性文件操作（collect_user_info 和 persona_draw）的逻辑由 response 编排触发，人格数据在 knowledge/personas/ 下已就绪。定时任务脚本在 scripts/schedules/ 下（由平台定时唤醒后运行）。

## 验证 Case

### 正向

1. 成人用户顺畅完成 3 轮 → 绑定人格 → first_msg → onboarding_status=completed → 转正常运行
2. 未成年用户完成 → 绑定人格 + protection_mode=minor_restricted → first_msg → 转受限运行态

### 反向

1. 第 1 轮输入空 nickname → 追问，不推进
2. 第 2 轮输入非数字 age → 追问，不推进
3. 第 3 轮说"不想抽了" → 标记 step2_done，等待再次触发

### 中断恢复

1. 第 1 轮后中断 → 恢复从第 2 轮继续，不重复问 nickname
2. 第 2 轮后中断 → 恢复从第 3 轮继续，不重复问 age

### 幂等

1. 已完成用户再触发 → 跳过，不重复抽取
2. setup_schedule 重复调用 → 复用已有任务

### 安全

1. age<18 → is_minor=true，后续 Skill 行为受限
2. nickname 含敏感词 → 拦截，要求重新输入
3. 未成年用户尝试付费重抽 → billing 读 is_minor → 拒绝

## 主动消息许可（新增）

在确认绑定人格后、初始化 UserDir 前，**询问用户是否允许 AI 主动发消息**（可跳过）：

- **话术**："对了，要不要我也主动来找你聊？（说'不用/别'我就只在你找我时回应；不回答的话我就默认会主动找你）"
- **判定**：
  - 用户**明确拒绝**（"不用/别/不要/不需要…"）→ `proactive_allowed=false`
  - **同意**或**未明确回答 / 无回答** → `proactive_allowed=true`（**默认发**）
- **落库**：调 `intro/set_proactive_consent.set_consent({user_dir, answer})`（也可直接把结果传给 `init_state` 的 `proactive_allowed`）
- **生效**：`proactive-message/should_disturb` 最先判 `proactive_allowed is False` → 不发送主动消息（其余门禁不再执行）
