"""人格抽取：从 4 张 E 型卡加权随机抽取一张。

属于 Intro Skill 独占逻辑（首次进入才触发）。
输入：seed（整数，用于可复现）
输出：{ mbti, nickname, intro, style, voice, first_msg, interests, stage_boundaries }
"""
import json
import os
import random

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
_PERSONAS_DIR = os.path.join(_BASE, "knowledge", "personas")
_PERSONAS = ["enfj", "enfp", "entj", "entp"]


def _load_persona(mbti: str) -> dict:
    pdir = os.path.join(_PERSONAS_DIR, mbti.lower())
    card = json.load(open(os.path.join(pdir, "card.json"), encoding="utf-8"))
    interests = json.load(open(os.path.join(pdir, "interests.json"), encoding="utf-8"))
    boundaries = json.load(open(os.path.join(pdir, "stage-boundaries.json"), encoding="utf-8"))
    return {
        "mbti": card["mbti"],
        "nickname": card["nickname"],
        "intro": card["intro"],
        "style": card["style"],
        "voice": card["voice"],
        "first_msg": card.get("first_msg"),
        "interests": interests.get("interests", []),
        "stage_boundaries": {
            "stages": boundaries.get("stages", {}),
            "thresholds": boundaries.get("thresholds", {}),
        },
    }


def draw_persona(seed: int = None) -> dict:
    """从 4 张 E 型卡加权随机抽取一张。"""
    rng = random.Random(seed) if seed is not None else random
    mbti = rng.choice(_PERSONAS)
    return _load_persona(mbti)


if __name__ == "__main__":
    import sys
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else None
    result = draw_persona(seed)
    print(json.dumps(result, ensure_ascii=False, indent=2))
