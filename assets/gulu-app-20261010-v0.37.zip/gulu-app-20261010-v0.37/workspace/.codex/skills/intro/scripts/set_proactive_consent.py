"""引导：询问并记录"是否允许 AI 主动发消息"。

Intro Skill 独占逻辑（也用于后续改主意）。
输入：{ user_dir, answer }
输出：{ proactive_allowed, answer, reason }
规则：**明确"不用/别"→ 不允许；未明确回答/无回答 → 默认允许**。
"""
from __future__ import annotations
import os, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state

# 明确的拒绝措辞（命中即视为"不允许"；注意先判拒绝，避免"不要"里的"要"被误判）
DENY = ["不要", "不用", "不需要", "不想", "别主动", "别找我", "别来", "不需要主动",
        "拒绝", "不用了", "别了", "不可以", "不行", "别烦", "安静点",
        "no", "No", "NO", "Nope", "nope"]


def set_consent(input_data: dict) -> dict:
    answer = str(input_data.get("answer") or input_data.get("reply") or "").strip()
    user_dir = input_data.get("user_dir", "")
    allowed = True
    if answer and any(d in answer for d in DENY):
        allowed = False
    if user_dir:
        st = read_state(user_dir)
        st["proactive_allowed"] = allowed
        write_state(user_dir, st)
    return {"proactive_allowed": allowed, "answer": answer,
            "reason": "user_opt_out" if not allowed else "allow_or_unclear_default"}


if __name__ == "__main__":
    import json
    print(json.dumps(set_consent(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
