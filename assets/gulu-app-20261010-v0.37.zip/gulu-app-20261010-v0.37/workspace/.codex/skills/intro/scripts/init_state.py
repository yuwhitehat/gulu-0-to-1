"""初次引导：绑定人格后初始化 state.md 与 memory/ 目录。

Intro Skill 独占逻辑。persona_draw 抽到人格、用户确认绑定后调用。
输入：{ user_dir, persona_mbti, nickname?, draw_count?, is_minor?, protection_mode? }
输出：{ state_written, state_path, memory_ready, fields }
"""
from __future__ import annotations
import os, shutil, sys
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state

CST = timezone(timedelta(hours=8))
MEMORY_FILES = ["timeline.jsonl", "shared_events.jsonl", "user-events.jsonl", "life_events.jsonl",
                "profile.md", "summary.md", "common_topics.md", "topics-index.md"]

def init_state(input_data: dict) -> dict:
    user_dir = input_data.get("user_dir", "")
    mbti = (input_data.get("persona_mbti") or input_data.get("mbti") or "").upper()
    if not user_dir or not mbti:
        return {"state_written": False, "reason": "missing_user_dir_or_mbti"}
    now = datetime.now(CST).isoformat()
    state = read_state(user_dir)
    is_minor = bool(input_data.get("is_minor", False))
    defaults = {
        "onboarding_status": "completed", "persona_bound": mbti, "stage": "stranger",
        "mode": "collision", "draw_count": int(input_data.get("draw_count") or 1),
        "interaction_count": 0, "agree_count": 0, "disagree_count": 0,
        "agree_streak": 0, "disagree_streak": 0, "unanswered_count": 0,
        "complaint_flag": False, "frozen": False, "permanently_blocked": [],
        "is_minor": is_minor,
        "protection_mode": input_data.get("protection_mode") or ("minor_restricted" if is_minor else "none"),
        "schedule_pending": True,
        "proactive_allowed": bool(input_data.get("proactive_allowed", True)),
        "schedule_tasks": [],
        "schedule_last_attempt_at": None,
        "schedule_confirmed_at": None,
    }
    for k, v in defaults.items():
        state.setdefault(k, v)
    state["persona_bound"] = mbti
    state["onboarding_status"] = "completed"
    if input_data.get("nickname"):
        state["nickname"] = input_data["nickname"]
    if not state.get("first_interaction_at"):
        state["first_interaction_at"] = now
    if not state.get("last_interaction_at"):
        state["last_interaction_at"] = now   # 引导本身即一次互动；避免主动消息间隔基准缺失
    mem_dir = os.path.join(user_dir, "memory")
    os.makedirs(mem_dir, exist_ok=True)
    tpl_dir = os.path.join(_BASE, "memory", "templates")
    for fn in MEMORY_FILES:
        fp = os.path.join(mem_dir, fn)
        if os.path.exists(fp):
            continue
        stem, ext = os.path.splitext(fn)
        tpl = os.path.join(tpl_dir, stem + ".example" + ext)
        if os.path.exists(tpl):
            shutil.copy2(tpl, fp)          # 从 Workspace 侧模板实例化到 UserDir
        else:
            open(fp, "w", encoding="utf-8").close()
    # user.md：若缺失，从模板实例化并替换占位符
    user_tpl = os.path.join(tpl_dir, "user.example.md")
    user_fp = os.path.join(user_dir, "user.md")
    if not os.path.exists(user_fp) and os.path.exists(user_tpl):
        _txt = open(user_tpl, encoding="utf-8").read()
        _txt = (_txt.replace("{{nickname}}", str(input_data.get("nickname") or ""))
                    .replace("{{age}}", str(input_data.get("age") or ""))
                    .replace("{{is_minor}}", str(is_minor).lower())
                    .replace("{{protection_mode}}", str(defaults["protection_mode"])))
        open(user_fp, "w", encoding="utf-8").write(_txt)

    write_state(user_dir, state)
    return {"state_written": True, "state_path": os.path.join(user_dir, "state.md"),
            "memory_ready": True, "fields": sorted(state.keys())}

if __name__ == "__main__":
    import json
    print(json.dumps(init_state(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
