"""初次引导：收集昵称与年龄，判定未成年，写入 user.md / state.md。"""
from __future__ import annotations
import os, re, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from safety_filter import filter_text
from state_store import read_state, write_state

CN_NUM = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9, "十": 10}
ADULT_PHRASES = ["成年", "上班", "工作", "打工", "毕业", "退休", "中年", "大叔", "阿姨",
                 "三十", "四十", "五十", "六十", "二十"] + [str(i) for i in range(18, 61)]
MINOR_PHRASES = ["未成年", "初中", "小学", "才16", "才15", "才14", "才13", "才12"]

def _parse_chinese_age(text):
    m = re.search(r"([二三四五六])?十([一二三四五六七八九])?", text)
    if m:
        tens_str, ones_str = m.group(1), m.group(2)
        if tens_str:
            return CN_NUM.get(tens_str, 0) * 10 + (CN_NUM.get(ones_str, 0) if ones_str else 0)
        return 10 + (CN_NUM.get(ones_str, 0) if ones_str else 0)
    return None

def _parse_age(text):
    text = str(text).strip()
    m = re.search(r"(\d+)", text)
    if m:
        age = int(m.group(1))
        if 1 <= age <= 150:
            return age, age >= 18
    cn = _parse_chinese_age(text)
    if cn is not None:
        return cn, cn >= 18
    if any(p in text for p in MINOR_PHRASES):
        return None, False
    if any(p in text for p in ADULT_PHRASES):
        return None, True
    return None, False

def collect(input_data: dict) -> dict:
    nickname = (input_data.get("nickname") or "").strip()
    age_input = str(input_data.get("age") if input_data.get("age") is not None else input_data.get("age_input", "")).strip()
    user_dir = input_data.get("user_dir", "")
    if not user_dir:
        return {"error": "missing_user_dir"}
    if not nickname:
        return {"error": "nickname_empty"}
    if filter_text(nickname)["safety_status"] == "blocked":
        return {"error": "nickname_sensitive"}
    age_int, adult = _parse_age(age_input)
    if age_int is None and not adult:
        return {"error": "age_not_determinable", "age_input": age_input}
    is_minor = (age_int is not None and age_int < 18)
    protection = "minor_restricted" if is_minor else "none"
    os.makedirs(user_dir, exist_ok=True)
    with open(os.path.join(user_dir, "user.md"), "w", encoding="utf-8") as f:
        f.write("# 用户信息\n\nnickname: %s\nage: %s\nis_minor: %s\n" % (nickname, age_int if age_int is not None else "", str(is_minor).lower()))
    st = read_state(user_dir)
    st["nickname"] = nickname
    st["is_minor"] = is_minor
    st["protection_mode"] = protection
    st.setdefault("onboarding_status", "in_progress")
    write_state(user_dir, st)
    return {"nickname": nickname, "age": age_int, "age_text": age_input,
            "is_minor": is_minor, "protection_mode": protection}

if __name__ == "__main__":
    import json
    print(json.dumps(collect(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
