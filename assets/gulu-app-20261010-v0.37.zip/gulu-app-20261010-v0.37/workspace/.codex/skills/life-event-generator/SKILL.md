<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `generate_life_events` | `{persona_mbti, current_date?, user_dir?, output_path?}` | `{events_generated, events, appended_to}`（写 `life_events.jsonl`） |
>
> 定时入口：`scripts/schedules/generate_life_events.py`（每天 02:00）。

---
name: life-event-generator
description: Gulu 的 AI 生活编造 Skill。每天凌晨编造 2-3 条 AI 昨天的生活事件，写入 life_events.jsonl 供主动消息和对话引用，让 AI 有生活感。不直接发送消息、不做对话策略、不负责用户记忆存储、不编造用户没说过的事。
---

# Life Event Generator Skill

让 AI 有"自己的生活"。每天凌晨 02:00 编造 2-3 条 AI 昨天的生活事件，追加写入 life_events.jsonl，供 response/recall_memory 引用，让 AI 不只是蹭热搜而是有生活感。

## 触发

- scheduler 每天 02:00 唤醒（平台定时任务 → prompt `gulu life-event daily` → scripts/schedules/generate_life_events.py）
- 本轮 function_demo 也可手动触发验证（直接调 generate_life_events 入口）

## 不触发

- 直接发送消息（事件写入 jsonl 供 response recall_memory 引用）
- 对话策略（dialogue 负责）
- 用户记忆存储（memory_curator 负责，生活事件是 AI 自身素材）
- 编造用户没说过的事（生活事件是 AI 的生活，不是用户的）

## 脚本

### generate_life_events

根据绑定人格的兴趣标签 + voice 规格，编造 2-3 条 AI 昨天的生活事件。

| 项 | 内容 |
|----|------|
| 输入 | {persona_mbti, current_date} |
| 输出 | {events_generated, events: [{id, date, persona_mbti, category, raw_text, voice_text, safety_status}], appended_to} |
| 性质 | LLM 生成 |

编造逻辑：
1. 读 knowledge/personas/{mbti}/interests.json 取兴趣标签
2. 从兴趣标签中随机选 1-2 个作为事件主题
3. 为每个主题生成生活事件骨架（做了什么 + 小感受，基于兴趣 desc 扩展）
4. 可补 1 条日常通用或情绪碎片事件（少量，丰富生活感）
5. 应用 voice markers 口吻化（加语气词/句式/不完美感）
6. 过 safety_filter 确保无敏感词
7. 最终产出 2-3 条事件

事件 category：
- interest（兴趣相关，占多数）
- daily（日常通用，如天气/吃饭等，少量补充）
- mood（情绪碎片，如"今天有点莫名的低落"增加人设厚度）

voice 口吻化：
- ENFP → 感叹句 + 跳话题 + "啊啊啊/诶/嘛" + 语序跳跃
- ENFJ → 关心式叙述 + "我来管你"感
- ENTJ → 简洁判断 + 复盘式
- ENTP → 提问/抬杠/思辨式

连续性：事件 date 标记为"昨天"；jsonl 追加不覆盖；recall_memory 取近期事件时按 date 排序取最近 N 条。

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| generate_life_events | state.md（persona_mbti）, knowledge/personas/{mbti}/interests.json, knowledge/personas/{mbti}/card.json（voice 规格）, knowledge/safety/sensitive-keywords.json（经 safety_filter） | life_events.jsonl（追加） |

衰减与删除：本脚本只负责生成追加，不负责删除。超 7 天事件的删除和引用权重管理归 memory_curator。

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| 兴趣读取失败 | 降级用日常通用素材编造（不阻断），至少 1 条入账 |
| safety_filter 命中 | 该条 safety_status=blocked，替换为安全替代或丢弃该条，其余正常 |
| 编造异常 | 跳过该条，保证至少 1 条入账 |
| LLM 生成失败 | 降级用模板骨架 + voice 口吻化生成（不调 LLM） |

## 不可接受行为

- 不得编造用户没做过/没说过的事（生活事件是 AI 的生活）
- 不得编造热搜来源（CAP-04 约束）
- 不得突破关系阶段语气边界（初识期事件不过分亲密）
- 不得像客服/百科/打卡教练/权威裁决者（PB-28）
- 不得编造涉及敏感话题的生活事件

## 验证 Case

### 正向

1. ENFP 正常生成 → 2-3 条事件，category 以 interest 为主可含 daily/mood，voice_text 含 markers
2. ENTJ 同主题 → voice_text 口吻差异明显（简洁复盘 vs ENFP 感叹跳话题）
3. 连续两天生成 → date 分别标记前一天，jsonl 追加不覆盖

### 反向

1. interests.json 缺失 → 降级用通用日常素材，至少 1 条入账
2. 事件含敏感词 → 该条 safety_status=blocked，替换或丢弃，其余正常

### 数量

1. 生成数量 → 2-3 条，不多不少
