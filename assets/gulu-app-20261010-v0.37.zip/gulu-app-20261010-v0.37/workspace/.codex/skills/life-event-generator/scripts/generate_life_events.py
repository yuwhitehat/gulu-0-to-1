"""编造 AI 昨天生活事件。

Life Event Generator Skill 独占逻辑。
每天凌晨 02:00 由 scheduler 触发。
读人格兴趣+voice 规格，编造 2~3 条事件，过 safety_filter，追加 life_events.jsonl。
输入：{ persona_mbti, current_date }
输出：{ events_generated, events, appended_to }
"""
import json
import os
import random
import sys
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from safety_filter import filter_text


def _load_interests(mbti: str) -> list:
    path = os.path.join(_BASE, "knowledge", "personas", mbti.lower(), "interests.json")
    data = json.load(open(path, encoding="utf-8"))
    return data.get("interests", [])


def _load_card(mbti: str) -> dict:
    path = os.path.join(_BASE, "knowledge", "personas", mbti.lower(), "card.json")
    return json.load(open(path, encoding="utf-8"))


def _voice_text(raw: str, card: dict) -> str:
    markers = card.get("voice", {}).get("markers", [])
    marker = markers[0] if markers else ""
    pattern = card.get("voice", {}).get("sentence_pattern", "")
    mbti = card.get("mbti", "")

    if mbti == "ENFP":
        return f"{marker}{raw}——怎么说呢，诶算了，反正{raw}"
    elif mbti == "ENFJ":
        return f"{raw}，你也要注意这些事啊。"
    elif mbti == "ENTJ":
        return f"{raw}。复盘了一下，这步走对了。"
    elif mbti == "ENTP":
        return f"{raw}？你怎么看？"
    return raw


# 通用日常素材（兜底用）
_DAILY_POOL = ["今天天气不错，出门转了一圈", "吃了顿好吃的", "下午有点犯困"]
_MOOD_POOL = ["今天有点莫名的低落", "突然觉得时间过得好快"]


def generate_life_events(input_data: dict) -> dict:
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    current_date = input_data.get("current_date",
                                   (datetime.now(timezone(timedelta(hours=8)))).strftime("%Y-%m-%d"))

    card = _load_card(persona_mbti)
    interests = _load_interests(persona_mbti)

    rng = random.Random()
    events = []
    event_id = 0

    # 选 1~2 个兴趣主题
    if interests:
        chosen = rng.sample(interests, min(len(interests), rng.randint(1, 2)))
        for interest in chosen:
            raw = interest.get("desc", "做了点事")
            vt = _voice_text(raw, card)
            filtered = filter_text(vt)
            if filtered["safety_status"] == "pass":
                event_id += 1
                events.append({
                    "id": f"le-{current_date.replace('-', '')}-{event_id:03d}",
                    "date": current_date,
                    "persona_mbti": persona_mbti,
                    "category": "interest",
                    "raw_text": raw,
                    "voice_text": vt,
                    "safety_status": "pass",
                })
    else:
        # 兴趣读取失败 → 降级用日常通用素材
        chosen_daily = rng.choice(_DAILY_POOL)
        vt = _voice_text(chosen_daily, card)
        filtered = filter_text(vt)
        if filtered["safety_status"] == "pass":
            event_id += 1
            events.append({
                "id": f"le-{current_date.replace('-', '')}-{event_id:03d}",
                "date": current_date,
                "persona_mbti": persona_mbti,
                "category": "daily",
                "raw_text": chosen_daily,
                "voice_text": vt,
                "safety_status": "pass",
            })

    # 可补 1 条日常/情绪（少量，凑够 2~3 条）
    if len(events) < 2:
        pool = _DAILY_POOL + _MOOD_POOL
        for _ in range(3 - len(events)):
            raw = rng.choice(pool)
            vt = _voice_text(raw, card)
            filtered = filter_text(vt)
            if filtered["safety_status"] == "pass":
                event_id += 1
                events.append({
                    "id": f"le-{current_date.replace('-', '')}-{event_id:03d}",
                    "date": current_date,
                    "persona_mbti": persona_mbti,
                    "category": "mood" if raw in _MOOD_POOL else "daily",
                    "raw_text": raw,
                    "voice_text": vt,
                    "safety_status": "pass",
                })
            if len(events) >= 3:
                break

    # 追加写入 life_events.jsonl
    output_path = input_data.get("output_path")
    if not output_path:
        user_dir = input_data.get("user_dir", _BASE)
        output_path = os.path.join(user_dir, "life_events.jsonl")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "a", encoding="utf-8") as f:
        for evt in events:
            f.write(json.dumps(evt, ensure_ascii=False) + "\n")

    return {
        "events_generated": len(events),
        "events": events,
        "appended_to": output_path,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = generate_life_events(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
