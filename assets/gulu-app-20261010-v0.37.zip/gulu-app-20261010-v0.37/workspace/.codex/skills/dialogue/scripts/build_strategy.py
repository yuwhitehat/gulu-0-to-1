"""返回紧凑的对话方法策略包。

Dialogue Skill 独占逻辑。根据 analyze_scene 结果组装完整策略包。
输入：{ scene_analysis, persona_mbti, relationship_stage, interaction_mode }
输出：{ strategy_package }
"""
import json


def build_strategy(input_data: dict) -> dict:
    analysis = input_data.get("scene_analysis", {})
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    stage = input_data.get("relationship_stage", "stranger")
    mode = input_data.get("interaction_mode", "collision")

    # 碰撞风格随模式变化
    mode_style_map = {
        "collision": "碰撞活泼",
        "same_frequency": "同频温和，多表达认同",
        "rival": "欢喜冤家，适度碰撞但不过分",
        "complaint_suppressed": "克制收敛，温和",
    }
    tone_style = mode_style_map.get(mode, mode_style_map["collision"])

    # 阶段语气约束
    stage_constraint_map = {
        "stranger": "不加追问；不撒娇；不强烈情绪",
        "familiar": "可反问；不撒娇；不强烈情绪",
        "intimate": "可撒娇；可强烈情绪；不用客服/百科语气",
    }
    stage_constraint = stage_constraint_map.get(stage, stage_constraint_map["stranger"])

    strategy_package = {
        "strategy_direction": analysis.get("strategy_direction", ""),
        "topic_preference": analysis.get("topic_preference", ""),
        "intimacy_boundary": analysis.get("intimacy_boundary", ""),
        "pace": analysis.get("pace", ""),
        "tone_style": tone_style,
        "stage_constraint": stage_constraint,
        "persona_mbti": persona_mbti,
        "current_mode": mode,
    }

    return {"strategy_package": strategy_package}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = build_strategy(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
