"""互动模式切换检测（同频/冤家/投诉抑制）。

Dialogue Skill 独占逻辑。

v0.7 变更（2026-09-22，修 gulu-badcase-001 / gulu-badcase-002）：
- D-01：投诉标记改为**持久化**。入参新增 `complaint_history`（当前已永久标记的行为列表）
  与 `current_mode`；一旦投诉过，`complaint_suppressed` 为粘性模式，不再被计数覆盖，
  `permanently_blocked` 只增不减。修正前：投诉后下一轮即被计数重置，被投诉的行为可能复发。
- D-02：同意/不同意计数改为**连续（consecutive）**语义。入参新增
  `last_signal`（上一轮的用户信号）与 `agree_streak` / `disagree_streak`；
  连续命中同一方向才累加，方向切换即归零。修正前：用历史累计值，先达 3 者永久锁死。

输入：{ signal?, agree_count?, disagree_count?, user_complaint?, current_mode,
        agree_streak?, disagree_streak?, last_signal?, permanently_blocked? }
输出：{ mode, changed, permanently_blocked, agree_streak, disagree_streak }

兼容：仍接受旧字段 `agree_count` / `disagree_count`（视为连续计数，见下），
使既有调用点与 GT 输入不必同时改口径。
"""
import json

STREAK_THRESHOLD = 3


def detect_mode(input_data: dict) -> dict:
    signal = input_data.get("signal")
    user_complaint = input_data.get("user_complaint", False)
    current_mode = input_data.get("current_mode", "collision")

    # 已永久标记的行为（粘性，只增不减）
    blocked = list(input_data.get("permanently_blocked") or [])

    # 连续计数：优先用 streak 字段；回退到 agree_count/disagree_count（既有调用点口径）
    agree_streak = input_data.get("agree_streak")
    if agree_streak is None:
        agree_streak = input_data.get("agree_count", 0)
    disagree_streak = input_data.get("disagree_streak")
    if disagree_streak is None:
        disagree_streak = input_data.get("disagree_count", 0)

    # ---- D-01：投诉是粘性的，优先级最高，且不可被计数覆盖 ----
    if user_complaint or current_mode == "complaint_suppressed":
        if not blocked:
            blocked = ["被投诉的行为类型"]
        elif "被投诉的行为类型" not in blocked and user_complaint:
            blocked = blocked + ["被投诉的行为类型"]
        return {
            "mode": "complaint_suppressed",
            "changed": current_mode != "complaint_suppressed",
            "permanently_blocked": blocked,
            "agree_streak": 0,
            "disagree_streak": 0,
        }

    # ---- D-02：连续语义 —— 方向切换即归零 ----
    if signal == "agree":
        agree_streak, disagree_streak = agree_streak + 1, 0
    elif signal == "disagree":
        agree_streak, disagree_streak = 0, disagree_streak + 1
    elif signal in ("complaint", "neutral"):
        agree_streak, disagree_streak = 0, 0
    # signal 为空时（既有调用点）沿用传入的 streak 值，不额外改动

    # 计数达阈值：同时达标时以更强者优先；相等则保持当前模式不动
    if agree_streak >= STREAK_THRESHOLD and agree_streak > disagree_streak:
        mode, changed = "same_frequency", current_mode != "same_frequency"
        agree_streak = disagree_streak = 0  # 达标后重置，避免锁死
    elif disagree_streak >= STREAK_THRESHOLD and disagree_streak > agree_streak:
        mode, changed = "rival", current_mode != "rival"
        agree_streak = disagree_streak = 0
    else:
        mode, changed = current_mode, False

    return {
        "mode": mode,
        "changed": changed,
        "permanently_blocked": blocked,
        "agree_streak": agree_streak,
        "disagree_streak": disagree_streak,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    print(json.dumps(detect_mode(data), ensure_ascii=False, indent=2))
