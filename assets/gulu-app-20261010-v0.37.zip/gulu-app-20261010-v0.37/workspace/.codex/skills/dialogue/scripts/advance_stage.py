"""关系阶段推进（10轮→熟悉，30轮→亲密）。

Dialogue Skill 独占逻辑。
输入：{ interaction_count, complaint_flag, current_stage }
输出：{ should_advance: bool, new_stage }
"""
import json
import os

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))))


def advance_stage(input_data: dict) -> dict:
    count = input_data.get("interaction_count", 0)
    complaint = input_data.get("complaint_flag", False)
    current = input_data.get("current_stage", "stranger")

    is_minor = input_data.get("is_minor", False)
    thresholds = {"familiar": 10, "intimate": 30}
    persona_mbti = input_data.get("persona_mbti", "")
    if persona_mbti:
        try:
            _p = os.path.join(_BASE, "knowledge", "personas", persona_mbti.lower(), "stage-boundaries.json")
            thresholds.update(json.load(open(_p, encoding="utf-8")).get("thresholds", {}) or {})
        except Exception:
            pass

    # 亲密期需要无投诉
    if count >= thresholds["intimate"] and not complaint:
        new_stage = "intimate"
    elif count >= thresholds["familiar"]:
        new_stage = "familiar"
    else:
        new_stage = "stranger"

    # 未成年保护：不进入 intimate（停在 familiar）
    if is_minor and new_stage == "intimate":
        new_stage = "familiar"

    # 阶段只能推进，不降级（投诉影响推进速度但不降级）
    order = ["stranger", "familiar", "intimate"]
    current_idx = order.index(current) if current in order else 0
    new_idx = order.index(new_stage)

    if new_idx > current_idx:
        return {"should_advance": True, "new_stage": new_stage}
    else:
        return {"should_advance": False, "new_stage": current}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = advance_stage(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
