"""场景理解→策略方向。

Dialogue Skill 独占逻辑。接收上游已完成的场景理解，返回策略方向。
输入：{ scene_understanding, relationship_stage, persona_mbti, interaction_count }
输出：{ strategy_direction, topic_preference, intimacy_boundary, pace }
"""
import json
import os


def analyze_scene(input_data: dict) -> dict:
    scene = input_data.get("scene_understanding", {})
    stage = input_data.get("relationship_stage", "stranger")
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    interaction_count = input_data.get("interaction_count", 0)

    # 1. 根据 relationship_stage 判定策略方向
    direction_map = {
        "stranger": "破冰试探（温和、分享、不追问）",
        "familiar": "升温共鸣（共同话题、适度反问）",
        "intimate": "深度连接（可撒娇/强烈情绪/深层分享）",
    }
    strategy_direction = direction_map.get(stage, direction_map["stranger"])

    # 2. 根据 user_intent 调整 topic_preference
    user_intent = scene.get("user_intent", "闲聊")
    intent_topic_map = {
        "闲聊": "从共同话题或人格兴趣选",
        "求助": "先共情再给建议（NT 型给方案，NF 型先安抚）",
        "投诉": "触发投诉抑制（调 detect_mode）",
        "聊旧话题": "调 load_context 加载主题记忆",
    }
    topic_preference = intent_topic_map.get(user_intent, intent_topic_map["闲聊"])

    # 3. 根据 persona_mbti 设定 intimacy_boundary
    is_nf = persona_mbti in ("ENFJ", "ENFP")
    if is_nf:
        intimacy_boundary = "NF 型：温和推进，关注感受"
    else:
        intimacy_boundary = "NT 型：碰撞推进，关注观点"

    # 4. 根据 interaction_count 设定 pace
    if interaction_count < 5:
        pace = "慢节奏，温和试探"
    elif interaction_count < 15:
        pace = "中节奏，适度升温"
    else:
        pace = "自然节奏，深度互动"

    return {
        "strategy_direction": strategy_direction,
        "topic_preference": topic_preference,
        "intimacy_boundary": intimacy_boundary,
        "pace": pace,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = analyze_scene(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
