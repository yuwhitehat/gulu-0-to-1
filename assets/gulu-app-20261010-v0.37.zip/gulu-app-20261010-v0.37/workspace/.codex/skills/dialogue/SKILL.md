<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `analyze_scene` | `{scene_understanding, relationship_stage, persona_mbti, interaction_count}` | `{intimacy_boundary, pace, strategy_direction, topic_preference}` |
> | `build_strategy` | `{scene_understanding|analysis, relationship_stage, persona_mbti, ...}` | `{strategy_package}` |
> | `detect_mode` | `{signal, agree_streak?, disagree_streak?, agree_count?, disagree_count?, user_complaint, current_mode, permanently_blocked?}` | `{mode, changed, permanently_blocked, agree_streak, disagree_streak}` |
> | `advance_stage` | `{interaction_count, complaint_flag, current_stage}` | `{should_advance, new_stage}` |
>
> 阈值：agree/disagree 连续 3 次切换模式；阶段 familiar≥10、intimate≥30 且无投诉。投诉为粘性（`permanently_blocked`）。

---
name: dialogue
description: 为 Gula 对话提供关系破冰策略和互动模式切换。当需要从场景理解生成对话策略包、检测互动模式切换（同频/欢喜冤家/投诉抑制）或推进关系阶段时触发。不直接生成回复文本、不识别用户意图、不记录互动、不发送消息。
---

# Dialogue Skill

关系破冰与自然升温的策略 Skill。只接收上游已完成的场景理解，返回一份紧凑的对话方法策略包。全部确定性逻辑，无 LLM 调用。

## 触发

- response/orchestrate_turn 需要对话策略时（user_initiated 和 proactive_initiated 两种模式）
- 需要检测互动模式是否应切换（连续 3 次同意/不同意/投诉）
- 需要判定关系阶段是否应推进（互动计数达标）

## 不触发

- 生成回复文本（response/persona_render 负责）
- 识别用户意图或情绪（response/orchestrate_turn 场景理解步骤负责）
- 识别投诉信号（response/orchestrate_turn 上游负责，本 Skill 只接收结果）
- 记录互动（response/record_interaction 负责）
- 发送消息（response 或 proactive_message 负责）

## 脚本

### analyze_scene

将上游场景理解映射为对话策略方向。

| 项 | 内容 |
|----|------|
| 输入 | {scene_understanding, relationship_stage, persona_mbti, interaction_count} |
| 输出 | {strategy_direction, topic_preference, intimacy_boundary, pace} |
| 性质 | 确定性（规则映射） |

scene_understanding 缺失 → 返回 default 策略（stranger + 破冰 + 分享）。relationship_stage 缺失 → 返回 error: stage_missing。persona_mbti 不在 4 张卡内 → 返回 error: persona_not_found。

### build_strategy

组装策略方向和模式调整，返回紧凑策略包。

| 项 | 内容 |
|----|------|
| 输入 | {strategy_direction, topic_preference, intimacy_boundary, pace, current_mode} |
| 输出 | {strategy_package: {tone_direction, topic_suggestion, intimacy_boundary, pacing, mode_adjustment}} |
| 性质 | 确定性（组装映射） |

mode_adjustment 值："同频：减少碰撞多认同" / "冤家：适度碰撞不越界" / "投诉：即时收敛切温和"。

### detect_mode

检测互动模式是否应切换。

| 项 | 内容 |
|----|------|
| 输入 | {agree_count, disagree_count, user_complaint, current_mode, complaint_signal} |
| 输出 | {mode: collision/same_frequency/rival/complaint_suppressed, changed: bool, permanently_blocked: []} |
| 性质 | 确定性（计数比较 + 规则映射） |

| 模式 | 触发条件 | AI 行为变化 |
|------|---------|------------|
| same_frequency | 连续 3 次同意 | 更贴近用户立场，多表达认同 |
| rival | 连续 3 次不同意 | 适当碰撞、反驳，不越阶段边界 |
| complaint_suppressed | 用户投诉或明确拒绝 | 即时停止该行为类型，标记不受欢迎，后续不再触发 |

proactive_initiated 模式不调本脚本（无用户消息无法检测模式切换）。

### advance_stage

判定关系阶段是否应推进。

| 项 | 内容 |
|----|------|
| 输入 | {interaction_count, complaint_flag, current_stage, is_minor} |
| 输出 | {should_advance, new_stage, threshold_met} |
| 性质 | 确定性（数值比较 + 规则映射） |

| 阶段 | 进入条件 | AI 语气边界 |
|------|---------|------------|
| stranger | 默认（抽取后） | 温和克制，不挑衅/不霸总/不亲密 |
| familiar | 累计互动 ≥ 10 轮 | 可展现人格典型特质 |
| intimate | 累计互动 ≥ 30 轮 + 用户未投诉 | 可使用人格极致风格 |

阈值来自 knowledge/personas/{mbti}/stage-boundaries.json（familiar=10, intimate=30, intimate_requires_no_complaint=true）。is_minor=true 时不推进到 intimate（停在 familiar）。proactive_initiated 模式不调本脚本（阶段推进靠用户互动计数）。stage-boundaries 文件缺失 → 返回 error: boundaries_missing，不推进。

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| analyze_scene | state.md（relationship_stage, persona_mbti, interaction_count） | 无 |
| build_strategy | state.md（current_mode） | 无 |
| detect_mode | state.md（agree_count, disagree_count, current_mode） | state.md（mode 切换标记） |
| advance_stage | state.md（interaction_count, complaint_flag, current_stage, is_minor） | state.md（new_stage） |

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| scene_understanding 缺失 | 返回 default 策略（stranger + 破冰 + 分享） |
| relationship_stage 缺失 | 返回 error: stage_missing |
| persona_mbti 不在 4 张卡内 | 返回 error: persona_not_found |
| stage-boundaries 文件缺失 | 返回 error: boundaries_missing，advance_stage 不推进 |

## 验证 Case

### 正向

1. stranger 阶段 3 次同意 → mode=same_frequency, changed=true
2. familiar 阶段 3 次不同意 → mode=rival, changed=true
3. 投诉 → mode=complaint_suppressed, permanently_blocked 标记
4. 互动 10 轮 → should_advance=true, new_stage=familiar
5. 互动 30 轮无投诉 → should_advance=true, new_stage=intimate

### 反向

1. 互动 10 轮但有投诉 → 不推进到 intimate
2. 未成年用户互动 30 轮 → 不推进到 intimate（停在 familiar）
3. proactive 模式 → 不调 detect_mode 和 advance_stage

### 安全

1. 投诉标记永久不降频再试
2. complaint_suppressed 模式后续不再触发被投诉行为
