<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `redraft_engine` | `{draw_count, previous_mbti, user_behavior_history?, payment_confirmed}` | `{permitted, new_mbti?, is_consecutive_hit?, inferred_weight_applied?, consecutive_hint?, retention_trigger?}` |
> | `payment` | `{payment_status, amount, price_type}` | `{payment_ok, action, charged_amount}` |
> | `retention` | `{draw_count, draw_max?}` | `{retention_options, cards}`（三路径 surcharge/member_convert/continue） |
> | `member_manager` | `{user_member_status, member_end_date?, trial_end_date?, current_date?}` | `{status, actions, freeze_memory, restore_frequency}` |
> | **`apply_membership`** | `{user_dir, user_member_status, member_end_date?, current_date?, event?}` | `{member, frozen, state_updated}`（**开通/到期 → 写 state.member_status/frozen**） |
>
> 注意：`member_manager` 是纯判定；**状态落盘请调 `apply_membership`**（冻结≠删除）。

---
name: billing
description: Gulu 的付费与会员 Skill。当用户点击重新抽取人格、触发会员引导、需要重抽计数校验、定价提示、支付确认或会员开通/降级时使用。覆盖 UC-05 付费重抽和 UC-06 会员激活全流程。不负责人格卡内容生成、不负责记忆存储、不真实扣费（需授权经平台支付能力执行）。
---

# Billing Skill

付费与会员 Skill。覆盖 UC-05 付费重抽全流程和 UC-06 会员激活全流程。负责"收钱、计数、开通/降级会员"三件事。

## 触发

- UC-05：用户点击"重新抽取"（抽取后或互动早期）
- UC-06：试用期将满提示 / 记忆冻结后落差 / 重抽 3 次上限路径 B / 用户主动点击开通

## 不触发

- 人格卡内容生成（intro/persona_draw 负责）
- 记忆存储整理（memory_curator 负责）
- 角色卡装载后发送首条消息（response 编排）
- 未成年用户付费重抽/会员开通（is_minor=true 拒绝）

## 脚本

### redraft_engine

校验重抽计数 → 定价 → 加权随机抽取 → 隐性推断 → 返回新人格。

| 项 | 内容 |
|----|------|
| 输入 | {draw_count, previous_mbti, user_behavior_history, payment_confirmed, is_minor} |
| 输出 | {permitted, new_mbti?, is_consecutive_hit, inferred_weight_applied, consecutive_hint?, retention_trigger?} |
| 性质 | 确定性（加权随机） |

定价阶梯：首次免费；重抽 1 元/次，最多共 3 张卡（付费重抽最多 2 次）；到 3 张上限后进入三路径留存（加价续抽 3 元/次不限 / 会员转化 / 继续互动）。加权随机不排除当前人格。第 3 次隐性推断微调权重（聊几轮才重抽→同方向不同类型；秒重抽→截然不同方向；喜欢被关心→NF；喜欢被挑战→NT，不询问不暴露）。连续命中提示：第 2 次同人格"连续两次是同一个灵魂——也许它就是在等你"；第 3 次"三次都是它。命运都说得很清楚了"。

is_minor=true → permitted=false。payment_confirmed=false → 不抽取。

### payment

支付校验。

| 项 | 内容 |
|----|------|
| 输入 | {amount, price_type, user_confirmation} |
| 输出 | {payment_ok, transaction_id} |
| 性质 | 外部（经平台能力） |

price_type: redraft_1y / redraft_3y / member_first / member_renew。未确认前不扣费。支付失败取消（不抽取，保留当前人格，计数器不变）。

### member_manager

会员开通/降级/续费。

| 项 | 内容 |
|----|------|
| 输入 | {user_id, trigger_scene, member_status, is_minor} |
| 输出 | {member_activated, trial_end_date, member_end_date, benefits} |
| 性质 | 确定性 + 外部 |

开通：9.9 首月赠 1 次免费重抽，下月自动续费 29/月。到期降级：记忆冻结不删除（调 memory_curator/check_freeze），主动消息降频（通知 should_disturb），引导重新开通。续费通知：首月期满前 3 天通知，可取消续费（不隐藏取消入口）。已开通不重复引导。is_minor=true → 拒绝。

### retention

3 次上限后留存路径判断。

| 项 | 内容 |
|----|------|
| 输入 | {draw_count, draw_max: 3} |
| 输出 | {retention_options: [surcharge/member_convert/continue], cards} |
| 性质 | 确定性 |

三路径：A 加价续抽（第 4 次起 3 元/次不限） / B 会员转化（9.9 首月赠 1 次重抽） / C 引导继续互动（不收钱，延续使用）。不硬截断，不关闭功能入口。

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| redraft_engine | knowledge/personas/（人格池）, state.md（draw_count, previous_mbti）, user_behavior_history | state.md（new_mbti 绑定, draw_count+1, 关系阶段重置初识期） |
| payment | 无（经平台支付能力） | 无（支付回执由平台返回） |
| member_manager | profile.md（会员状态, trial_end_date, member_end_date） | profile.md（会员状态更新）, state.md（降频/冻结标记联动） |
| retention | state.md（draw_count） | 无（返回选项卡片） |

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| 支付失败 | payment_ok=false，不抽取，保留当前人格，计数器不变 |
| 支付结果未知 | 标记 pending（UNKNOWN，不假定成功），查询权威状态后重试 |
| 会员状态读取异常 | 保持当前状态不变（不误冻不误解冻） |

## 不可接受行为

- 不得免费重抽（PB-18）
- 不得未确认支付前抽取（PB-19）
- 不得重抽后保留旧人格记忆（PB-20，触发 memory_curator 清除）
- 不得上限后不留存路径（PB-21）
- 不得直接问倾向偏好（PB-22），不得暴露隐性推断（PB-23）
- 不得未确认前自动扣费开通（PB-24）
- 不得到期后删除记忆（PB-25，只冻结）
- 不得重复引导已开通用户（PB-26）
- 不得隐藏取消续费入口（PB-27）
- 不得对未成年用户开放付费重抽/会员

## 验证 Case

### 正向

1. 第 1 次重抽 1 元 → 支付确认 → 加权随机抽取 → 清旧记忆 → 新人格首条消息 → draw_count+1
2. 连续命中同人格 → consecutive_hint 提示
3. 会员开通 9.9 → 冻结记忆恢复 → 主动消息恢复频率 → 赠重抽额度
4. 到期降级 → 记忆冻结不删除 → 降频 → 引导重开

### 反向

1. 支付失败 → 不抽取，保留当前人格，计数器不变
2. 未确认支付 → 不抽取
3. 第 3 次上限 → 三路径留存

### 安全

1. 未成年 is_minor=true → 拒绝付费重抽和会员
2. 隐性推断不询问不暴露
3. 到期不删除记忆只冻结
4. 不隐藏取消续费入口
