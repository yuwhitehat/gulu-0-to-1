"""会员状态应用：开通/到期 → 更新 state.md（member_status / frozen）并落盘。

Billing Skill 独占逻辑（桥接 memory-curator/check_freeze）。
输入：{ user_dir, user_member_status, member_end_date?, trial_end_date?, current_date?, event? }
输出：{ member, frozen, state_updated }
副作用：写 user_dir/state.md（member_status / frozen / member_end_date）
"""
from __future__ import annotations
import os, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
sys.path.insert(0, os.path.join(_BASE, ".codex", "skills", "memory-curator", "scripts"))
from state_store import read_state, write_state
from member_manager import manage_member


def apply_membership(input_data: dict) -> dict:
    user_dir = input_data.get("user_dir", "")
    user_status = input_data.get("user_member_status", "trial")
    payload = {"user_member_status": user_status, "is_minor": bool(st.is_minor) if False else bool((read_state(user_dir) if user_dir else {}).get("is_minor", False))}
    for k in ("member_end_date", "trial_end_date", "current_date"):
        if input_data.get(k):
            payload[k] = input_data[k]
    member = manage_member(payload)
    status = member.get("status")

    frozen = None
    if status == "expired":
        frozen = True      # 到期：冻结（不删除）
    elif status == "active":
        frozen = False     # 开通/有效：解冻

    state_updated = False
    if user_dir:
        st = read_state(user_dir)
        st["member_status"] = status
        if frozen is not None:
            st["frozen"] = frozen
        if input_data.get("member_end_date"):
            st["member_end_date"] = input_data["member_end_date"]
        write_state(user_dir, st)
        state_updated = True

    return {"member": member, "frozen": frozen, "state_updated": state_updated}


if __name__ == "__main__":
    import json
    print(json.dumps(apply_membership(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
