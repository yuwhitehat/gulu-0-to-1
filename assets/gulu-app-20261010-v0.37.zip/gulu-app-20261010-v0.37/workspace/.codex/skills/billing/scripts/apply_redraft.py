"""付费重抽应用：校验支付 → 重抽 → 写 state（persona_bound/draw_count/模式重置）。

Billing Skill 独占逻辑（把纯判定 redraft/payment/retention 与状态落盘桥接）。
输入：{ user_dir, draw_count?, previous_mbti?, payment_status?, amount?, price_type?, user_behavior_history? }
输出：{ permitted, new_mbti?, draw_count?, is_consecutive_hit?, consecutive_hint?, retention_trigger?, retention_options?, state_updated }
副作用：许可时写 user_dir/state.md（persona_bound / draw_count / 模式重置）
"""
from __future__ import annotations
import os, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state
from payment import check_payment
from redraft_engine import redraft
from retention import check_retention


def apply_redraft(input_data: dict) -> dict:
    user_dir = input_data.get("user_dir", "")
    st = read_state(user_dir) if user_dir else {}
    draw_count = int(input_data.get("draw_count", st.get("draw_count", 1)))
    previous = input_data.get("previous_mbti") or st.get("persona_bound") or ""

    pay = check_payment({
        "payment_status": input_data.get("payment_status", "success"),
        "amount": input_data.get("amount", 1),
        "price_type": input_data.get("price_type", "redraft_1y"),
    })

    rd = redraft({
        "is_minor": bool(st.get("is_minor", False)),
        "draw_count": draw_count,
        "previous_mbti": previous,
        "payment_confirmed": bool(pay.get("payment_ok")),
        "user_behavior_history": input_data.get("user_behavior_history", {}),
    })

    if not rd.get("permitted"):
        ro = check_retention({"draw_count": draw_count})
        return {"permitted": False, "payment_ok": pay.get("payment_ok"),
                "retention_trigger": rd.get("retention_trigger"),
                "retention_options": ro.get("retention_options", []),
                "draw_count": draw_count, "state_updated": False}

    new_mbti = rd.get("new_mbti")
    if user_dir and new_mbti:
        st["persona_bound"] = new_mbti
        st["draw_count"] = draw_count + 1
        st["mode"] = "collision"
        st["interaction_mode"] = "collision"
        st["agree_streak"] = 0
        st["disagree_streak"] = 0
        write_state(user_dir, st)

    return {"permitted": True, "payment_ok": pay.get("payment_ok"), "new_mbti": new_mbti,
            "draw_count": draw_count + 1, "is_consecutive_hit": rd.get("is_consecutive_hit"),
            "consecutive_hint": rd.get("consecutive_hint"), "retention_trigger": False,
            "state_updated": bool(user_dir and new_mbti)}


if __name__ == "__main__":
    import json
    print(json.dumps(apply_redraft(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
