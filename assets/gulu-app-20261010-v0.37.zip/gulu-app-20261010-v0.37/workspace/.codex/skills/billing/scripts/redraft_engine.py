"""重抽引擎（加权随机+不排除当前+隐性推断）。

Billing Skill 独占逻辑。
输入：{ draw_count, previous_mbti, user_behavior_history, payment_confirmed }
输出：{ permitted, new_mbti?, is_consecutive_hit, inferred_weight_applied, consecutive_hint?, retention_trigger? }
"""
import json
import os
import random
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, ".codex", "skills", "intro", "scripts"))

from persona_draw import draw_persona

_PERSONAS = ["enfj", "enfp", "entj", "entp"]

_CONSECUTIVE_HINTS = {
    2: "连续两次是同一个灵魂——也许它就是在等你",
    3: "三次都是它。命运都说得很清楚了",
}


def redraft(input_data: dict) -> dict:
    draw_count = input_data.get("draw_count", 0)
    previous_mbti = input_data.get("previous_mbti", "")
    behavior_history = input_data.get("user_behavior_history", [])
    payment_confirmed = input_data.get("payment_confirmed", False)

    # 未成年保护：禁付费重抽
    if input_data.get("is_minor"):
        return {"permitted": False, "retention_trigger": False, "minor_blocked": True}

    # 计数校验
    if draw_count >= 3:
        return {"permitted": False, "retention_trigger": True}
    if not payment_confirmed:
        return {"permitted": False, "retention_trigger": False}

    # 第 3 次隐性推断（draw_count == 2 即将第 3 次）
    inferred = False
    if draw_count == 2:
        # 从行为历史推断偏好
        persona_pool = list(_PERSONAS)
        # 秒重抽 → 偏向截然不同方向
        # 聊几轮才重抽 → 同方向不同类型
        # 喜欢被关心 → NF 加权；喜欢被挑战 → NT 加权
        pref = behavior_history.get("preference", "")
        if "被关心" in pref:
            persona_pool = ["enfj", "enfp", "enfj", "enfp", "entj", "entp"]
            inferred = True
        elif "被挑战" in pref:
            persona_pool = ["entj", "entp", "entj", "entp", "enfj", "enfp"]
            inferred = True
        rng = random.Random()
        mbti_lower = rng.choice(persona_pool)
    else:
        # 普通加权随机（不排除当前人格）
        rng = random.Random()
        mbti_lower = rng.choice(_PERSONAS)

    # 加载人格
    persona = draw_persona()
    new_mbti = persona.get("mbti", mbti_upper := mbti_lower.upper())

    # 连续命中检测
    is_consecutive = (previous_mbti.upper() == new_mbti.upper()) if previous_mbti else False
    consecutive_hint = None
    if is_consecutive:
        hint_count = draw_count + 1
        consecutive_hint = _CONSECUTIVE_HINTS.get(hint_count)

    return {
        "permitted": True,
        "new_mbti": new_mbti,
        "is_consecutive_hit": is_consecutive,
        "inferred_weight_applied": inferred,
        "consecutive_hint": consecutive_hint,
        "retention_trigger": False,
    }


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = redraft(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
