"""会员管理（开通/到期降级/续费通知/不重复引导）。

Billing Skill 独占逻辑。
输入：{ user_member_status, trial_end_date?, member_end_date?, current_date }
输出：{ status, actions, freeze_memory?, restore_frequency? }
"""
import json
from datetime import datetime


def manage_member(input_data: dict) -> dict:
    member_status = input_data.get("user_member_status", "trial")
    trial_end = input_data.get("trial_end_date")
    member_end = input_data.get("member_end_date")
    current_date = input_data.get("current_date", datetime.now().strftime("%Y-%m-%d"))

    # 未成年保护：禁开通会员
    if input_data.get("is_minor"):
        return {"status": "trial", "actions": ["block_minor"], "freeze_memory": False, "restore_frequency": False}

    # 已开通也要检查是否到期
    if member_status == "active":
        if member_end:
            member_end_dt = datetime.fromisoformat(member_end)
            current_dt = datetime.fromisoformat(current_date)
            if current_dt >= member_end_dt:
                return {"status": "expired", "actions": ["restrict"],
                        "freeze_memory": True, "restore_frequency": False}
        return {"status": "active", "actions": [], "freeze_memory": False, "restore_frequency": False}

    # 开通会员
    if member_status == "opening":
        return {"status": "active", "actions": ["restore"],
                "freeze_memory": False, "restore_frequency": True}

    # 试用期将满（提前3天）
    if trial_end:
        trial_end_dt = datetime.fromisoformat(trial_end)
        current_dt = datetime.fromisoformat(current_date)
        days_left = (trial_end_dt - current_dt).days
        if days_left <= 3 and days_left > 0:
            return {"status": "trial", "actions": ["notify"],
                    "freeze_memory": False, "restore_frequency": False}

    # 会员到期降级
    if member_end:
        member_end_dt = datetime.fromisoformat(member_end)
        current_dt = datetime.fromisoformat(current_date)
        if current_dt >= member_end_dt:
            return {"status": "expired", "actions": ["restrict"],
                    "freeze_memory": True, "restore_frequency": False}

    # 免费试用期内
    return {"status": "trial", "actions": [], "freeze_memory": False, "restore_frequency": False}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = manage_member(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
