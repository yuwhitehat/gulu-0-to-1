"""支付校验（成功/失败取消）。

Billing Skill 独占逻辑。
输入：{ payment_status, amount, price_type }
输出：{ payment_ok, action, charged_amount }

price_type: redraft_1y(1元) / redraft_3y(3元) / member_first(9.9元) / member_renew(29元)
"""
import json

_PRICES = {
    "redraft_1y": 1,
    "redraft_3y": 3,
    "member_first": 9.9,
    "member_renew": 29,
}

_ACTION_MAP = {
    "redraft_1y": "redraft",
    "redraft_3y": "redraft",
    "member_first": "member_open",
    "member_renew": "member_renew",
}


def check_payment(input_data: dict) -> dict:
    status = input_data.get("payment_status", "")
    amount = input_data.get("amount", 0)
    price_type = input_data.get("price_type", "redraft_1y")

    expected_price = _PRICES.get(price_type, 1)
    action = _ACTION_MAP.get(price_type, "redraft")

    if status == "success" and abs(amount - expected_price) < 0.01:
        return {"payment_ok": True, "action": action, "charged_amount": amount}
    else:
        return {"payment_ok": False, "action": "cancel", "charged_amount": 0}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = check_payment(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
