"""三次上限后留存三路径。

Billing Skill 独占逻辑。
输入：{ draw_count, draw_max }
输出：{ retention_options, cards }
"""
import json


def check_retention(input_data: dict) -> dict:
    draw_count = input_data.get("draw_count", 0)
    draw_max = input_data.get("draw_max", 3)

    if draw_count < draw_max:
        return {"retention_options": [], "cards": []}

    options = [
        {"id": "surcharge", "label": "加价续抽", "price": "3元/次不限", "card": "RT-05-A"},
        {"id": "member_convert", "label": "会员转化", "price": "9.9元首月赠1次", "card": "RT-05-B"},
        {"id": "continue", "label": "引导继续互动", "price": "免费", "card": "RT-05-C"},
    ]

    return {"retention_options": options, "cards": ["RT-05"]}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = check_retention(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
