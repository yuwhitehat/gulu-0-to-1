"""确保定时任务默认开启（产出任务请求；创建由 Agent 用 schedule.create 动态工具完成）。"""
from __future__ import annotations
import os, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state
from setup_schedule import setup_schedule


def ensure_schedules(input_data: dict) -> dict:
    user_dir = input_data.get("user_dir", "")
    req = setup_schedule(input_data)  # 记录 schedule_last_attempt_at
    pending = True
    if user_dir:
        st = read_state(user_dir)
        if "schedule_pending" not in st:
            st["schedule_pending"] = True     # 未知 → 待确认
            write_state(user_dir, st)
        pending = bool(st.get("schedule_pending", True))
    return {"tasks": req["tasks"], "schedule_pending": pending, "note": req["note"]}


if __name__ == "__main__":
    import json
    print(json.dumps(ensure_schedules(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
