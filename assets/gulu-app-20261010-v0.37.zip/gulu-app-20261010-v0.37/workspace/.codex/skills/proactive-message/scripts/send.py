"""触发 response 编排并**组装**主动消息文本（**本函数不发送**）。

Proactive Message Skill 独占逻辑（v2 重构版）。
不自组装消息，改为调 response/orchestrate_turn(proactive_initiated)。
输入：{ character_instance_id, persona_mbti, current_stage, content_hint, user_dir }
输出：{ reply_text, safety_status, should_send, delivery }（发送由 Agent 用平台能力完成）
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, ".codex", "skills", "response", "scripts"))
sys.path.insert(0, os.path.join(_BASE, "scripts"))

from orchestrate_turn import orchestrate_turn
from safety_filter import is_safe


def _select_hotsearch(persona_mbti: str) -> dict:
    """选热搜：读 mock-topics → safety_filter 过滤 → suitable_personas 匹配。"""
    hotsearch_path = os.path.join(_BASE, "knowledge", "hotsearch", "mock-topics.json")
    data = json.load(open(hotsearch_path, encoding="utf-8"))
    topics = data.get("topics", [])

    matched = []
    for t in topics:
        if persona_mbti in t.get("suitable_personas", []) and is_safe(t.get("content", "")):
            matched.append(t)

    if matched:
        return matched[0]
    # 降级：无匹配则返回空（send 会降级为性格闲聊）
    return {}


def send(input_data: dict) -> dict:
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    current_stage = input_data.get("current_stage", "stranger")
    content_hint = input_data.get("content_hint", "A")
    user_dir = input_data.get("user_dir", "")

    # 1. 选热搜
    hotsearch = {}
    if content_hint == "A":
        hotsearch = _select_hotsearch(persona_mbti)
    # 无匹配热搜 → 降级 B（性格闲聊），仍生成发送

    # 2. 调 response/orchestrate_turn(proactive_initiated)
    result = orchestrate_turn({
        "trigger_mode": "proactive_initiated",
        "persona_mbti": persona_mbti,
        "current_stage": current_stage,
        "hotsearch": hotsearch,
        "user_dir": user_dir,
    })

    reply_text = result.get("reply_text", "")
    safety_status = result.get("safety_status", "pass")

    if safety_status == "blocked":
        return {"reply_text": reply_text, "safety_status": safety_status,
                "should_send": False, "delivery": "none", "sent": None, "message_id": None}

    # 3. 组装完成：**本函数不发送**。把文本交给运行态 Agent，
    #    由 Agent 用平台注入的「发消息到当前群」能力发送（与普通对话一致：都走平台能力）。
    return {"reply_text": reply_text, "safety_status": safety_status,
            "should_send": (safety_status != "blocked"),
            "delivery": "bot_result_delivery",  # 由 Bot 的 ResultDelivery 投递最终回复
            "sent": None, "message_id": None}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = send(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
