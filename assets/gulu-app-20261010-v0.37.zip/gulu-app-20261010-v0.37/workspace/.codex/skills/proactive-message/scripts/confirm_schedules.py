"""任务创建成功后回写 state：schedule_tasks + schedule_pending=false。"""
from __future__ import annotations
import os, sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state


def confirm_schedules(input_data: dict) -> dict:
    user_dir = input_data.get("user_dir", "")
    tasks = input_data.get("tasks") or []
    ok = bool(tasks) and all(t.get("task_id") for t in tasks)
    if user_dir:
        st = read_state(user_dir)
        st["schedule_tasks"] = [{"task_type": t.get("task_type"), "task_id": t.get("task_id")} for t in tasks]
        st["schedule_pending"] = not ok
        st["schedule_confirmed_at"] = (__import__("datetime").datetime.now(
            __import__("datetime").timezone(__import__("datetime").timedelta(hours=8))).isoformat())
        write_state(user_dir, st)
    return {"schedule_pending": (not ok), "schedule_tasks": tasks}


if __name__ == "__main__":
    import json
    print(json.dumps(confirm_schedules(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
