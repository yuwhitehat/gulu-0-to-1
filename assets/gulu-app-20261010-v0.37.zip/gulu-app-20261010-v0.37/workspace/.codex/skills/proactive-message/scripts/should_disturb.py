"""门禁检查（安静时段/间隔/降频/投诉即停）。

Proactive Message Skill 独占逻辑。
输入：{ persona_mbti, now, last_interaction_at, unanswered_count, complaint_flag, current_stage }
输出：{ should_send, reason, content_hint?, deferred_to_morning? }

间隔基准：距上次互动时间（last_interaction_at），非上次主动时间。
J=20min，P=10min（临时验证）；连续3次未回复降频翻倍。
"""
import json
from datetime import datetime, timezone, timedelta


def should_disturb(input_data: dict) -> dict:
    persona_mbti = input_data.get("persona_mbti", "")
    now_str = input_data.get("now")
    last_interaction = input_data.get("last_interaction_at")
    unanswered = input_data.get("unanswered_count", 0)
    complaint = input_data.get("complaint_flag", False)
    current_stage = input_data.get("current_stage", "stranger")

    if now_str:
        try:
            now = datetime.fromisoformat(now_str)
            if now.tzinfo is None:
                now = now.replace(tzinfo=timezone(timedelta(hours=8)))
        except ValueError:
            now = datetime.now(timezone(timedelta(hours=8)))
    else:
        now = datetime.now(timezone(timedelta(hours=8)))

    # 0. 用户未允许主动消息（引导时询问；未明确回答默认允许）
    if input_data.get("proactive_allowed") is False:
        return {"should_send": False, "reason": "proactive_opt_out: 用户未允许主动消息"}

    # 1. 投诉即停（永久不主动）
    if complaint:
        return {"should_send": False, "reason": "complaint_flag: 投诉已停"}

    # 2. 安静时段 23:00-08:00
    hour = now.hour
    if hour >= 23 or hour < 8:
        return {"should_send": False, "reason": f"quiet_hours: {hour}点在安静时段",
                "deferred_to_morning": True}

    # 3. 间隔检查（距上次互动时间）
    mbti_letter = persona_mbti[-1] if persona_mbti else ""
    base_interval_min = 20 if mbti_letter == "J" else 10  # 分钟：J=20min，P=10min（临时验证）

    # 4. 降频：unanswered >= 3 时间隔翻倍
    if unanswered >= 3:
        base_interval_min *= 2  # J=40min，P=20min

    # 未成年保护：最低间隔 2 小时（降频）
    if input_data.get("is_minor"):
        base_interval_min = max(base_interval_min, 120)

    if not last_interaction:
        return {"should_send": True, "reason": "first_trigger: 无上次互动记录",
                "content_hint": "A"}

    try:
        last_dt = datetime.fromisoformat(last_interaction)
        if last_dt.tzinfo is None:
            last_dt = last_dt.replace(tzinfo=timezone(timedelta(hours=8)))
    except (ValueError, TypeError):
        return {"should_send": True, "reason": "last_parse_fail: 无法解析上次时间",
                "content_hint": "A"}

    elapsed_min = (now - last_dt).total_seconds() / 60

    if elapsed_min < base_interval_min:
        reason = f"{'frequency_downgrade: ' if unanswered >= 3 else 'interval: '}"
        reason += f"仅过{elapsed_min:.0f}min，需{base_interval_min}min"
        return {"should_send": False, "reason": reason}

    content_hint = "A"  # 默认热搜碰撞
    return {"should_send": True,
            "reason": f"interval_ok: 已过{elapsed_min:.0f}min，满足{base_interval_min}min",
            "content_hint": content_hint}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = should_disturb(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
