"""状态存取：user_dir/state.md 的读写（写 JSON；读容忍 JSON / Markdown 两种格式）。"""
from __future__ import annotations
import json, os

def read_state(user_dir: str) -> dict:
    p = os.path.join(user_dir, "state.md")
    if not os.path.exists(p):
        return {}
    txt = open(p, encoding="utf-8").read()
    try:
        return json.loads(txt)
    except Exception:
        pass
    out = {}
    for line in txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        k, _, v = line.partition(":")
        k = k.strip(); v = v.strip()
        if not k: continue
        low = v.lower()
        if low in ("true", "false"): out[k] = (low == "true")
        elif v == "": out[k] = None
        else:
            try: out[k] = int(v)
            except ValueError:
                try: out[k] = float(v)
                except ValueError: out[k] = v
    return out

def write_state(user_dir: str, state: dict) -> str:
    os.makedirs(user_dir, exist_ok=True)
    p = os.path.join(user_dir, "state.md")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)
    return p
