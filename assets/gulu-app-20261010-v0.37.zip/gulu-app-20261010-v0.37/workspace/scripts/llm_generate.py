"""LLM 性格一致性生成（CAP-05 POC）。

公共脚本，被 response/persona_render 调用。
用 codex exec 单次生成，构造包含人格卡全部规格的 system prompt。
默认模型 glm-5.2，可通过环境变量 GULU_LLM_MODEL 覆盖。

v0.6 变更（2026-09-13，Owner 决定 u-05）：--sandbox 由 workspace-write 收窄为 read-only，
被测脚本不持有工作区写权限。原件归档于 demo/archive/pre-v0.6-20260913/。
输入：{ persona_mbti, stage, strategy, context, user_message, hotsearch, trigger_mode }
输出：{ reply_text, generation_ok, fallback_used }

CAP-05 失败处理：
- 生成失败第 1 次 → 自动重试 1 次（用户无感）
- 重试仍失败 → AI 性格化承认故障（"我脑子突然卡住了……等会儿再找你聊"）
- 不假装正常兜底回复糊弄用户
"""
import json
import os
import subprocess
import sys
import tempfile

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_card(mbti: str) -> dict:
    path = os.path.join(_BASE, "knowledge", "personas", mbti.lower(), "card.json")
    return json.load(open(path, encoding="utf-8"))


def _load_boundaries(mbti: str) -> dict:
    path = os.path.join(_BASE, "knowledge", "personas", mbti.lower(), "stage-boundaries.json")
    return json.load(open(path, encoding="utf-8"))


def _build_system_prompt(persona_mbti: str, stage: str, strategy: dict) -> str:
    card = _load_card(persona_mbti)
    boundaries = _load_boundaries(persona_mbti)
    voice = card.get("voice", {})
    # CAP-05 加固：汇总别的人格标记词作为禁止项
    _others = set()
    _pdir = os.path.join(_BASE, "knowledge", "personas")
    for _n in os.listdir(_pdir):
        if _n.lower() == persona_mbti.lower():
            continue
        try:
            _c = json.load(open(os.path.join(_pdir, _n, "card.json"), encoding="utf-8"))
            _others.update(_c.get("voice", {}).get("markers", []))
        except Exception:
            pass
    other_markers = "、".join(sorted(_others - set(voice.get("markers", []))))
    stage_def = boundaries.get("stages", {}).get(stage, {})

    prompt = f"""你是「{card.get("nickname", "")}」，一个 MBTI 类型为 {card.get("mbti", "")} 的 AI 灵魂角色。

## 你的人格设定
- 昵称：{card.get("nickname", "")}
- 一句话简介：{card.get("intro", "")}
- 风格：{card.get("style", "")}

## 你的说话方式（必须严格遵守）
- 句式：{voice.get("sentence_pattern", "")}
- 语气标记词（经常使用）：{", ".join(voice.get("markers", []))}
- 不完美特征（故意保留的人味儿）：{voice.get("imperfection", "")}
- 禁止语气（绝对不能用）：{", ".join(voice.get("forbidden", []))}
- 禁止其他人格语气词（绝对不能用）：{other_markers}

## 当前关系阶段：{stage}
- 阶段描述：{stage_def.get("desc", "")}
- 允许的行为：{", ".join(stage_def.get("allowed", []))}
- 禁止的行为：{", ".join(stage_def.get("forbidden", []))}

## 当前互动模式
- 语气风格：{strategy.get("tone_style", "碰撞活泼")}
- 阶段约束：{strategy.get("stage_constraint", "")}

## 生成规则
1. 用你的人格口吻回复，必须至少出现 1 个你的语气标记词（保持自然，不堆砌）
2. 严格遵守当前关系阶段的语气边界，不越界
3. 回复要短（1-3 句），像聊天不是写文章
4. 保留不完美特征（语序跳跃/发到一半又补等）
5. 绝对不用客服、百科、打卡教练、权威裁决者语气
6. 只生成回复内容本身，不加引号、不加角色名前缀
7. 不得使用其他人格的语气标记词
"""
    return prompt


def _build_user_prompt(input_data: dict) -> str:
    trigger_mode = input_data.get("trigger_mode", "user_initiated")
    user_message = input_data.get("user_message", "")
    hotsearch = input_data.get("hotsearch", {})
    context = input_data.get("context", {})
    memories = context.get("memories", {})

    parts = []
    if trigger_mode == "proactive_initiated":
        content = hotsearch.get("content", "")
        parts.append(f"你现在要主动给用户发一条消息。你看到的热搜内容是：{content}")
        parts.append("用你的人格口吻聊这个话题，不要像在转述新闻，要有你自己的态度。")
    else:
        parts.append(f'用户刚给你发了这条消息："{user_message}"')
        parts.append("用你的人格口吻回复。")

    life_events = memories.get("life_events", [])
    if life_events:
        recent = life_events[-1]
        parts.append(f'（你最近的生活：{recent.get("voice_text", "")}，可以自然引用）')

    timeline = memories.get("timeline", [])
    if timeline:
        last = timeline[-1]
        if last.get("user_message"):
            parts.append(f'（上次用户说过：{last["user_message"][:30]}）')

    return "\n".join(parts)


_DEFAULT_MODEL = "glm-5.2"


def _get_model() -> str:
    return os.environ.get("GULU_LLM_MODEL", _DEFAULT_MODEL)


def _call_codex(system_prompt: str, user_prompt: str) -> str:
    """用 codex exec 单次生成。"""
    model = _get_model()
    full_prompt = f"{system_prompt}\n\n---\n{user_prompt}\n\n回复："
    try:
        result = subprocess.run(
            ["codex", "exec", "-c", f'model="{model}"',
             "--sandbox", "read-only", "--skip-git-repo-check", "-"],
            input=full_prompt,
            capture_output=True,
            text=True,
            timeout=45,
        )
        if result.returncode == 0 and result.stdout.strip():
            # codex 输出格式：...user\n<prompt>\n...codex\n<reply>\ntokens used...
            lines = result.stdout.strip().split("\n")
            # 找 "codex" 行后的内容，到 "tokens used" 之前
            in_reply = False
            reply_lines = []
            for line in lines:
                stripped = line.strip()
                if stripped == "codex":
                    in_reply = True
                    continue
                if "tokens used" in stripped:
                    break
                if in_reply and stripped:
                    reply_lines.append(stripped)
            if reply_lines:
                return "\n".join(reply_lines)
            # fallback: 取最后非空行
            for line in reversed(lines):
                stripped = line.strip()
                if stripped and not stripped.startswith("codex") and not stripped.startswith("$$") and not stripped.startswith("WARNING") and not stripped.startswith("warning") and "tokens used" not in stripped:
                    return stripped
            return ""
        return ""
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        return ""


_FALLBACK_MSGS = {
    "ENFP": "啊啊啊我脑子突然卡住了……等会儿再找你聊，我先缓缓",
    "ENFJ": "啊……我脑子一下没转过来，等会儿再聊，我先缓一下",
    "ENTJ": "……我状态不太对。等会儿再找你。",
    "ENTP": "呗，我脑子卡了。等会儿再说。",
}


def _own_markers(mbti):
    try:
        return _load_card(mbti).get("voice", {}).get("markers", [])
    except Exception:
        return []


def _other_markers(mbti):
    out = set()
    pdir = os.path.join(_BASE, "knowledge", "personas")
    try:
        for n in os.listdir(pdir):
            if n.lower() == str(mbti).lower():
                continue
            try:
                c = json.load(open(os.path.join(pdir, n, "card.json"), encoding="utf-8"))
                out.update(c.get("voice", {}).get("markers", []))
            except Exception:
                pass
    except Exception:
        pass
    return out - set(_own_markers(mbti))


def _persona_ok(text, own, others):
    if own and not any(mk in text for mk in own):
        return False
    if others and any(mk in text for mk in others):
        return False
    return True


_STAGE_PATTERNS = {
    "撒娇": ["撒娇"],
    "强烈情绪表达": ["强烈情绪表达"],
    "追问式": ["你呢", "你怎么看", "你觉得呢", "你怎么想", "你觉得怎么样"],
}


def _stage_forbidden(mbti, stage):
    try:
        p = os.path.join(_BASE, "knowledge", "personas", str(mbti).lower(), "stage-boundaries.json")
        d = json.load(open(p, encoding="utf-8"))
        return d.get("stages", {}).get(stage, {}).get("forbidden", [])
    except Exception:
        return []


def _stage_ok(text, mbti, stage):
    """阶段边界：命中该阶段 forbidden 类别对应的措辞则不合规。"""
    for cat in _stage_forbidden(mbti, stage):
        for pat in _STAGE_PATTERNS.get(cat, [cat]):
            if pat in text:
                return False
    return True

def generate(input_data: dict) -> dict:
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    stage = input_data.get("stage", "stranger")
    strategy = input_data.get("strategy", {})

    system_prompt = _build_system_prompt(persona_mbti, stage, strategy)
    user_prompt = _build_user_prompt(input_data)

    # 生成 + 人格一致性校验（最多 3 次：兼含"失败重试"与"不合规再试"）
    own = _own_markers(persona_mbti)
    others = _other_markers(persona_mbti)
    last = ""
    for _ in range(3):
        reply = _call_codex(system_prompt, user_prompt)
        if not reply:
            continue
        last = reply
        if _persona_ok(reply, own, others) and _stage_ok(reply, persona_mbti, stage):
            return {"reply_text": reply, "generation_ok": True, "fallback_used": False}

    if last:
        return {"reply_text": last, "generation_ok": True, "fallback_used": False}

    # 仍失败 → 性格化承认故障
    fallback = _FALLBACK_MSGS.get(persona_mbti, _FALLBACK_MSGS["ENFP"])
    return {"reply_text": fallback, "generation_ok": False, "fallback_used": True}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = generate(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
