"""加载对话上下文（记忆+知识+状态）。

公共脚本，被 response/recall_memory 调用。
输入：{ user_message?, persona_mbti, frozen, user_dir }
输出：{ context: { memories, knowledge, relationship_state }, degraded: bool }

降级规则：
- 记忆检索有结果 → 正常返回上下文
- 记忆检索无结果 → degraded=true，返回空记忆+人格卡，AI 性格化过渡
- 记忆冻结(frozen) → 不调记忆，只返回人格卡+当前状态
- 记忆纠正后 → 返回 corrected 标记的最新条目
"""
import json
import os
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _load_card(mbti: str) -> dict:
    path = os.path.join(_BASE, "knowledge", "personas", mbti.lower(), "card.json")
    return json.load(open(path, encoding="utf-8"))


def _load_life_events(user_dir: str) -> list:
    """加载近 7 天的 AI 生活事件。"""
    path = os.path.join(user_dir, "life_events.jsonl")
    if not os.path.exists(path):
        return []
    events = []
    cutoff = datetime.now(timezone(timedelta(hours=8))) - timedelta(days=7)
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                evt = json.loads(line)
                evt_date = datetime.fromisoformat(evt.get("date", ""))
                if evt_date >= cutoff:
                    events.append(evt)
            except (ValueError, KeyError):
                continue
    return events[-10:]


def _load_timeline(user_dir: str) -> list:
    """加载用户互动记录（timeline）。"""
    path = os.path.join(user_dir, "timeline.jsonl")
    if not os.path.exists(path):
        return []
    entries = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return entries[-20:]


def _load_profile(user_dir: str) -> dict:
    """加载用户偏好画像。"""
    path = os.path.join(user_dir, "profile.md")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, ValueError):
        return {}


def _load_summary(user_dir: str) -> dict:
    """加载关键事件摘要。"""
    path = os.path.join(user_dir, "summary.md")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, ValueError):
        return {}


def load_context(user_message: str = "", persona_mbti: str = "",
                 frozen: bool = False, user_dir: str = "") -> dict:
    """加载当前对话所需的上下文（记忆+知识+状态），处理记忆检索失败降级。"""
    knowledge = _load_card(persona_mbti) if persona_mbti else {}

    if frozen:
        return {
            "context": {
                "memories": {},
                "knowledge": knowledge,
                "relationship_state": {},
            },
            "degraded": True,
        }

    if not user_dir:
        return {
            "context": {
                "memories": {},
                "knowledge": knowledge,
                "relationship_state": {},
            },
            "degraded": True,
        }

    try:
        life_events = _load_life_events(user_dir)
        timeline = _load_timeline(user_dir)
        profile = _load_profile(user_dir)
        summary = _load_summary(user_dir)

        memories = {
            "life_events": life_events,
            "timeline": timeline,
            "profile": profile,
            "summary": summary,
        }

        has_memories = bool(life_events or timeline or profile or summary)

        return {
            "context": {
                "memories": memories,
                "knowledge": knowledge,
                "relationship_state": profile.get("relationship_state", {}),
            },
            "degraded": not has_memories,
        }
    except Exception:
        return {
            "context": {
                "memories": {},
                "knowledge": knowledge,
                "relationship_state": {},
            },
            "degraded": True,
        }


if __name__ == "__main__":
    import sys
    mbti = sys.argv[1] if len(sys.argv) > 1 else "ENFP"
    user_dir = sys.argv[2] if len(sys.argv) > 2 else ""
    result = load_context(persona_mbti=mbti, user_dir=user_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2))
