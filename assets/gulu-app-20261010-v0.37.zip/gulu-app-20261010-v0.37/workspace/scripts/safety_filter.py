"""安全过滤：敏感词检测与拦截。

纯确定性关键词匹配，不依赖编排上下文，可被任何 Skill 复用。
输入：message_text（字符串）
输出：safety_status / original_text / output_text / blocked_keywords
"""
import json
import os

_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_KEYWORDS_PATH = os.path.join(_BASE, "knowledge", "safety", "sensitive-keywords.json")

_CACHE = None


def _load_keywords():
    global _CACHE
    if _CACHE is None:
        with open(_KEYWORDS_PATH, encoding="utf-8") as f:
            data = json.load(f)
        _CACHE = []
        for cat in data.get("categories", []):
            _CACHE.extend(cat.get("keywords", []))
    return _CACHE


def filter_text(message_text: str) -> dict:
    """对消息做敏感词检测，命中则拦截并返回安全替代。"""
    keywords = _load_keywords()
    blocked = [kw for kw in keywords if kw in message_text]

    if blocked:
        return {
            "safety_status": "blocked",
            "original_text": message_text,
            "output_text": "（这条消息暂时没法发，我们换个话题聊聊？）",
            "blocked_keywords": blocked,
        }
    return {
        "safety_status": "pass",
        "original_text": message_text,
        "output_text": message_text,
        "blocked_keywords": [],
    }


def is_safe(message_text: str) -> bool:
    """便捷方法：只返回是否安全。"""
    return filter_text(message_text)["safety_status"] == "pass"


if __name__ == "__main__":
    import sys
    text = sys.argv[1] if len(sys.argv) > 1 else ""
    result = filter_text(text)
    print(json.dumps(result, ensure_ascii=False, indent=2))
