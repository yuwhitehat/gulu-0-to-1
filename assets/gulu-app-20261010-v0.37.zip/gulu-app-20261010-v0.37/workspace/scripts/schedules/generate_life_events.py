"""Gulu schedules/generate_life_events — 每日 AI 生活事件（02:00）。"""
from __future__ import annotations
import json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / ".codex" / "skills" / "life-event-generator" / "scripts"))
from _sched_common import resolve_user_dir, load_state
from generate_life_events import generate_life_events

def run(user_dir: str) -> dict:
    state = load_state(user_dir)
    persona = state.get("persona_bound") or state.get("persona_mbti") or "ENFP"
    return generate_life_events({"persona_mbti": persona, "user_dir": user_dir})

if __name__ == "__main__":
    print(json.dumps(run(resolve_user_dir()), ensure_ascii=False, indent=2))
