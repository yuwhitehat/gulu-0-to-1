"""Schedules 公共：定位 user_dir 与解析 state.md（容忍 JSON / Markdown 两种格式）。"""
from __future__ import annotations
import json, os, sys
from pathlib import Path

def app_root() -> Path:
    return Path(__file__).resolve().parents[2]

def resolve_user_dir(argv=None) -> str:
    for k in ("USER_DIR", "AIPM_USER_DIR", "AIPM_MOUNT_USER_DIR"):
        v = os.environ.get(k)
        if v: return v
    argv = argv if argv is not None else sys.argv
    if len(argv) > 1 and argv[1]:
        return argv[1]
    # 本地运行兜底：优先应用根目录内的 user/（平铺包），其次同级 user/（workspace/ + user/ 包）
    root = app_root()
    for cand in (root / "user", root.parent / "user"):
        if cand.is_dir():
            return str(cand)
    return str(root.parent / "user")

def load_state(user_dir) -> dict:
    p = Path(user_dir) / "state.md"
    if not p.is_file():
        return {}
    txt = p.read_text(encoding="utf-8")
    try:
        return json.loads(txt)
    except Exception:
        pass
    out = {}
    for line in txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        k, _, v = line.partition(":")
        k = k.strip(); v = v.strip()
        if not k: continue
        low = v.lower()
        if low in ("true", "false"): out[k] = (low == "true")
        elif v == "": out[k] = None
        else:
            try: out[k] = int(v)
            except ValueError:
                try: out[k] = float(v)
                except ValueError: out[k] = v
    return out
