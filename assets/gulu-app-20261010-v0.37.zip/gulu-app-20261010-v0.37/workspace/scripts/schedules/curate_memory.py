"""Gulu schedules/curate_memory — 每日记忆整理（00:30）。"""
from __future__ import annotations
import json, sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / ".codex" / "skills" / "memory-curator" / "scripts"))
from _sched_common import resolve_user_dir, load_state
from curate_memory import curate

CST = timezone(timedelta(hours=8))

def _has_interaction_today(user_dir: str) -> bool:
    p = Path(user_dir) / "timeline.jsonl"
    if not p.is_file():
        return False
    today = datetime.now(CST).strftime("%Y-%m-%d")
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip() and today in line:
            return True
    return False

def run(user_dir: str) -> dict:
    state = load_state(user_dir)
    persona = state.get("persona_bound") or state.get("persona_mbti") or "ENFP"
    return curate({"current_date": datetime.now(CST).strftime("%Y-%m-%d"),
                   "persona_mbti": persona, "has_interaction": _has_interaction_today(user_dir),
                   "user_dir": user_dir})

if __name__ == "__main__":
    print(json.dumps(run(resolve_user_dir()), ensure_ascii=False, indent=2))
