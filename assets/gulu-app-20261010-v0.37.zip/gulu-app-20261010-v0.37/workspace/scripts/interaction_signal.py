"""互动信号判定（同意 / 不同意 / 投诉 / 中性）。

公共脚本，被 response/orchestrate_turn 与 memory_curator/curate_memory 共用。

新建理由（2026-09-22，修 gulu-badcase-004）：原实现用 `"嗯" in msg or "对" in msg`
判"同意"，把"不对""不同意""反对"全部误判为同意（"不对"含"对"字）。判定逻辑散落
两处且写法过粗。本模块收敛为单一实现。

判定顺序（关键）：投诉 → 不同意 → 同意 → 中性。
先判否定，避免 "嗯，这个我不太认同" 这类"含肯定词但整体否定"被误判。

输入：message_text（字符串）
输出：{ signal: "agree"|"disagree"|"complaint"|"neutral", matched: [命中的词] }
"""
import json

# 投诉：优先级最高
COMPLAINT_KEYWORDS = ["别这样", "别老", "烦死", "烦了", "有点烦", "投诉", "讨厌", "受不了", "别说了"]

# 不同意：必须在"同意"之前判，否则"不同意"会命中"同意"
DISAGREE_KEYWORDS = [
    "不同意", "不认同", "不太认同", "不赞成", "不喜欢",
    "不对", "不太对", "不是这样", "不是吧", "未必", "反对", "拉倒", "扯吧",
]

# 同意：使用较长词，避免"对"这种单字误伤（"不对"已在上一档拦掉）
AGREE_KEYWORDS = ["同意", "赞同", "认同", "有道理", "说得对", "没错", "确实", "嗯", "对呀", "对的"]


def classify(message_text: str) -> dict:
    """判定单条用户消息的互动信号。"""
    text = message_text or ""

    matched = [kw for kw in COMPLAINT_KEYWORDS if kw in text]
    if matched:
        return {"signal": "complaint", "matched": matched}

    matched = [kw for kw in DISAGREE_KEYWORDS if kw in text]
    if matched:
        return {"signal": "disagree", "matched": matched}

    matched = [kw for kw in AGREE_KEYWORDS if kw in text]
    if matched:
        return {"signal": "agree", "matched": matched}

    return {"signal": "neutral", "matched": []}


if __name__ == "__main__":
    import sys
    text = sys.argv[1] if len(sys.argv) > 1 else ""
    print(json.dumps(classify(text), ensure_ascii=False, indent=2))
