# Gulu（骨碌）

ToC 主动聊天 AI 灵魂盲盒产品。用户首次进入抽取一张 E 型人格卡（ENFJ/ENFP/ENTJ/ENTP），AI 以该人格风格主动聊天、碰撞热搜、记录记忆、随互动升温关系。

## 核心任务

灵魂盲盒抽取、人格化主动消息、关系破冰升温、长期记忆、付费重抽与会员。

不重做产品发现、不做 PM 助手、不做企业工具、不做通用百科问答。

## 读写契约

| 根 | 态 | 可读 | 可写 |
|----|-----|------|------|
| Published Workspace | Use | 只读 | ❌ |
| 当前群 UserDir | Use | ✅ 按文件权限 | ✅ 按文件权限 |
| knowledge/ | Use | 只读 | ❌ |
| scripts/ | Use | 只读执行 | ❌ |
| .codex/skills/ | Use | 只读加载 | ❌ |
| eval-control/ | — | ❌ 不可读 | ❌ |
| evidence/ | — | ❌ 不可读 | ❌ |

## 启动加载与 Turn 顺序

### 启动最小加载

读 state.md（人格/阶段/模式/计数/冻结/未成年；JSON 或 Markdown 均可）+ user.md（称呼/年龄）+ card.json（voice 规格）+ stage-boundaries.json（阶段边界）。

### 普通 Turn（user_initiated）

读取状态 → 场景理解 → recall_memory → build_strategy → detect_mode → advance_stage → 分支处理 → 预记录 → persona_render（LLM）→ pre_send_check → record → 回复。

### 主动 Turn（proactive_initiated）

读取状态 → 选热搜+碰撞风格 → recall_memory → build_strategy（跳过 detect_mode/advance_stage）→ persona_render（LLM）→ pre_send_check → record → **把 `reply_text` 作为最终回答输出**（Bot 自动投递；**不要调用 `feishu.message_send_current_channel`**）。

## Skill 路由表

| Skill | 触发 | 不负责 |
|-------|------|--------|
| intro | 首次进入/中断恢复 | 日常对话、付费重抽、主动消息 |
| dialogue | 需要策略/模式切换/阶段推进 | 生成文本、识别意图、记录、发送 |
| response | 用户消息或主动消息触发编排 | 定时唤醒、付费、记忆整理 |
| proactive-message | 定时唤醒/首次 Onboarding 后 | 生成文本、对话策略、模式检测 |
| billing | 重抽/会员引导 | 人格卡内容、记忆存储、首条消息 |
| life-event-generator | 每天 02:00（平台定时任务，见「定时任务」节） | 发送消息、对话策略、用户记忆 |
| memory-curator | 00:30 定时/记错/冻结解冻 | 实时检索、原始写入、对话生成 |

## 真相源

- 人格定义/兴趣/阶段边界/热搜/敏感词 → knowledge/ 只读
- 关系状态 → UserDir state.md（intro/response/memory_curator/billing 写，全 Skill 读）
- 用户信息 → UserDir user.md（intro 写，billing/response 读）
- 互动流水/共同事件/用户新事实/AI生活事件/画像/摘要/话题 → UserDir memory/ 下各文件（分文件读写，详见 memory/README.md）

## 工具边界

- 飞书：经**平台注入的飞书能力**发消息/支付；应用**不直连**飞书 OpenAPI、不持 token、**文档不写端点**。**定时任务触发时不要调用发消息工具**——Bot 会把最终回复自动投递到会话（ResultDelivery）；主动消息由 Agent 输出文本、Bot 投递
- 定时任务：**用 `schedule.create` 动态工具创建**（Bot 运行时注入；`kind=prompt`，将来可 `kind=script`）；应用**不出现外部地址/端口号、不自行发起请求**、不持凭证；任务为**固定 Prompt**（见「定时任务」节）
- LLM：`scripts/llm_generate.py`（codex exec → 平台默认模型），性格一致性生成
- 记忆：文件系统（UserDir），不训练用户数据，冻结不删除

## 红线

- 付费/会员/重抽必须用户确认后执行，不自动扣费
- age 不进入 AI 对话上下文；不展示记忆内容给用户；不训练用户数据
- 敏感词 5 类必过滤；safety_status=blocked 不发原消息
- 不直连外部 API；不修改 Test/Prod；不扫描其他用户/UserDir/Project
- 重抽清旧记忆不可恢复（但标记可追溯）；投诉标记永久不降频再试
- age<18 禁付费重抽/禁会员/降频 2h/不进 intimate/敏感词加强
- AI 输出只含角色对话，不暴露思考过程、旁白、解释或分析；用户看到的只有 AI 说的台词
- Onboarding 首抽前必须告知重抽规则：首次免费；不满意付费重抽 1 元/次；最多一共抽到 3 张卡（付费重抽最多 2 次）；到 3 张后三路径留存
- 冻结不删除；不否认记错；检索失败降级不暴露技术故障
- 定时任务：应用不持调度凭证、**不出现外部地址/端口号、不自行发起请求**；创建经 **`schedule.create` 动态工具**；**prompt 触发后必须调 `scripts/schedules/` 下对应脚本处理**（见「定时任务」节）

## 失败真实性

- LLM 生成失败 → 重试 1 次；仍失败 AI 性格化承认"脑子卡住了"，不发兜底正常回复
- 记忆检索失败 → 降级为无历史上下文，AI 性格化过渡"脑子没转过来"
- 投递未发生 / 未知 → 由平台负责；应用不记录送达回执（不假定成功），不阻塞后续对话
- 定时任务未创建/不可用 → `schedule_pending=true`，不阻断对话；prompt 触发但**门禁不通过 → 不发**（正常结果）
- 支付失败 → 不抽取，保留当前人格，计数器不变
- 门禁不通过 → 结束本次 run、**不输出任何用户可见内容**（这是正常结果）

## 发布边界

- 发布源：AGENTS.md、manifest.dev.json、onboarding.md、.codex/skills/*/SKILL.md、knowledge/*、scripts/*、memory/README.md、tools/README.md、agents/*.toml
- 排除：临时开发文件、运行时状态目录、临时附件、评测控制目录、评测证据目录、密钥、用户实例数据
- 定时任务经 **`schedule.create` 动态工具**创建（`kind=prompt`）；确定性入口在 `scripts/schedules/`。state.md 采用 JSON（读时容忍 JSON / Markdown）。

## 主动消息许可（v0.16 新增）

- 引导中必须询问用户"是否允许 AI 主动发消息"；**明确拒绝 → 不主动；同意或未明确回答 → 默认主动**。
- 结果写入 `state.md` 的 `proactive_allowed`；`should_disturb` 最先据此判定。
- 后续用户改主意：调 `intro/set_proactive_consent` 更新。

## 定时任务触发后的消息发送（重要）

定时任务（proactive_message、memory_curator、life_event_generator）触发后，Bot 会自动把你的最终回复发送到飞书会话。

**不要在定时任务触发时调用 `feishu.message_send_current_channel` 工具**。只需要把回复作为最终回答输出即可，Bot 的 ResultDelivery 机制会自动投递。

### 由此推出的应用规则

- **主动消息（proactive）**：`check_trigger.py` 门禁通过 → 组装出 `reply_text` → **把这段文本作为最终回答输出**（不要调用任何发消息工具）→ Bot 投递到当前群。
- **不要自行投递**：任何「自己再发一遍」的动作都会造成**重复消息**（本版就是在修这个）。
- **`delivery_mode` 就是投递开关**：`notify` = 平台把本次结果投递到当前群；`silent` = 不投递。因此 **proactive 必须 `notify`**（用 `silent` 的话主动消息不会出现在群里）；`curate` / `life-event` 保持 `silent`，且**不产生用户可见输出**（只做内部整理/生成，避免每天刷群）。
- 投递由 Bot 负责，应用侧**拿不到送达回执**，因此**不记录送达结果**；门禁与计数由 `record_interaction` 落盘（`last_proactive_at` / `unanswered_count`）。

## 定时任务（v0.36：**只用动态工具创建**）

### 创建方式（**重要**：用 Dynamic Tool）

定时任务**必须使用 `schedule.create` 动态工具（Dynamic Tool）创建**；创建 / 列举 / 更新**一律走动态工具**，**不得采用其它任何方式**（命令行请求、网页请求、自行拼接地址、自建调度都不允许）。

可用工具（由 **Bot 运行时自动注入**，直接调用即可，**无需任何外部地址或凭证**）：

- `schedule.create`：创建定时任务，`kind` 为 `prompt` 或 `script`
- `schedule.list_own`：列出当前用户的定时任务
- `schedule.update`：更新 / 禁用定时任务

### 本应用怎么用

- **默认 `kind=prompt`**（当前可用）：到点由平台唤醒运行态 Agent 并把该 prompt 递进来，Agent 按下面「Prompt → 动作」跑 `workspace/scripts/schedules/` 下的对应脚本。
- **将来 `kind=script`**（平台开脚本能力后可选）：直接给 `script_path`（相对 `scripts/schedules/`，如 `check_trigger.py`），不经过模型、更确定；本应用的确定性入口已经就位。
- 创建流程：`proactive-message/setup_schedule` **输出任务请求** → **用 `schedule.create` 逐条创建**（字段原样传：`name` / `trigger` / `action` / `delivery_mode` / `idempotency_key`）→ 拿到回执后调 `proactive-message/confirm_schedules` **回写** `state.schedule_tasks` 并把 `schedule_pending` 置 `false`。
- 补建/幂等：任何时候 `schedule_pending=true` → 先 `schedule.list_own` 看是否已存在（按 `idempotency_key` / `name`），缺的再 `schedule.create` 补齐；**不重复建**。
- 改/停用：用 `schedule.list_own` 取到任务与版本，再 `schedule.update`。
- **只用动态工具**；也不要 host crontab、调度文件或自建循环。
- **验收口径**：应用侧（文档 + 脚本）**不得出现任何外部地址、端口号或命令行请求示例**。
- **验证档**（临时）：唤醒 11min（设计值 88min）、proactive 用 `notify`（设计值 `silent`）。验证通过后恢复设计值出正式版。

### 创建契约（参数表，**原样传给 `schedule.create`**）

| 任务 | `name` | `trigger` | `action`（`kind=prompt`） | `delivery_mode` | `idempotency_key` |
|---|---|---|---|---|---|
| gulu-proactive | 骨碌-主动消息 | `{"type":"interval","interval_seconds":660}` | `gulu proactive-reach check` | **`notify`（必须：投递开关）** | `gulu-proactive-v1` |
| gulu-curate | 骨碌-记忆整理 | `{"type":"cron","cron":"30 0 * * *","timezone":"Asia/Shanghai"}` | `gulu memory-curate daily` | `silent` | `gulu-curate-v1` |
| gulu-life-event | 骨碌-生活事件 | `{"type":"cron","cron":"0 2 * * *","timezone":"Asia/Shanghai"}` | `gulu life-event daily` | `silent` | `gulu-life-event-v1` |

- **proactive 必须 interval/fixed-delay，不得写成五段 Cron**（本次 run 终态 + 660s = 下次）。
- **`delivery_mode` 是投递开关**：`notify` → 平台把本次结果投递到当前群（主动消息靠它才能到用户）；`silent` → 不投递。主动消息**不再由应用/Agent 自己发**，而是「输出最终回复 + Bot 投递」，避免重复。
- `idempotency_key` 稳定 → 重试/补建**不会重复建任务**；按 `task_type` 复用。
- 仅「主动消息」受用户许可约束：`proactive_allowed=false` → **不产出 proactive 任务**，且门禁兜底不发；另两个任务照常。

### Prompt → 动作（**触发后必须执行**）

| 收到的 prompt | 执行 |
|---|---|
| `gulu proactive-reach check` | 运行 `scripts/schedules/check_trigger.py`（门禁 → **组装文本**）→ **把 `reply_text` 作为最终回答输出**（Bot 自动投递；**不要调用发消息工具**） |
| `gulu memory-curate daily` | 运行 `scripts/schedules/curate_memory.py` |
| `gulu life-event daily` | 运行 `scripts/schedules/generate_life_events.py` |

- 任一**门禁不通过 / 无内容** → 结束本次 run，**「不发」是正常结果**；
- 用户**明确拒绝主动消息**（`proactive_allowed=false`）→ proactive 任务不产出，或 run 直接结束不发送。

### 触发时机（**走产品流程，不靠用户说口令**）

- **用户流程**：引导中询问用户「是否允许 AI 主动联系你」 → 允许 / 未明确回答 → **引导结束时**由 Agent 创建定时任务（默认开启）；明确拒绝 → 不产出 proactive 任务。
- **不存在**让用户说某个口令去注册这种事——用户侧只有引导里的一次确认。
- 运维诊断（`setup_schedule` / `ensure_schedules` / `confirm_schedules`）**仅供 Owner 排障**；**不得向普通用户暴露任务字段、prompt 或任何内部术语**。

### 引导结束**必须执行**（创建清单，缺一不可）

1. 调 `proactive-message/setup_schedule(user_dir=...)` → 得到任务请求（同时记录 `schedule_last_attempt_at`）；
2. **用 `schedule.create` 逐条创建**（`kind=prompt`，字段原样传；**只用动态工具**）；
3. 拿到**创建回执（任务 id）** → 调 `proactive-message/confirm_schedules(user_dir, tasks=[{task_type, task_id}])` 回写（置 `schedule_pending=false`，记录 `schedule_confirmed_at`）。

> 触发时的投递口径见本文件开头「**定时任务触发后的消息发送（重要）**」：**输出最终回复即可，不要调用发消息工具**。

- 只有**回执（任务 id）**才算成功；调用没报错也不算；创建后用 `schedule.list_own` 应能列出这 3 条。
- 若第 2 步失败（无该工具 / 报错）→ **保持 `schedule_pending=true`**，并**如实记录**失败类别，不假装成功；
- 诊断：`state.md` 里 `schedule_last_attempt_at` 为空 = **压根没尝试**；有值但 `schedule_pending` 仍 true = **尝试了但没成功**；`schedule_confirmed_at` 非空 = **已确认创建成功**。
