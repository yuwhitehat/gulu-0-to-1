#!/usr/bin/env bash
# 骨碌 App 本地启动：显式把「应用工作区（只读）」与「用户态（可写）」喂给运行时。
#   workspace/ = 应用本体（AGENTS.md 在这层）    user/ = 该用户的状态与产物
set -euo pipefail
APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export WORKSPACE_DIR="$APP_ROOT/workspace"   # 应用本体：$WORKSPACE_DIR/AGENTS.md = 骨碌应用指令
export USER_DIR="$APP_ROOT/user"             # 用户态：state.md / user.md / memory/
export AIPM_STATE=use                        # 运行态 = use

echo "WORKSPACE_DIR=$WORKSPACE_DIR"
echo "USER_DIR=$USER_DIR"
# CODEX_HOME 沿用你本地/平台已设置的（本包不覆盖）
codex "$@"
