# 骨碌（Gulu）本地运行包 —— 启动引导

本包把「应用本体」和「用户态」分开存放，不要混：

- `workspace/`：**应用本体（只读）**。应用入口是 `workspace/AGENTS.md` —— 骨碌的身份、Skill 路由、红线、定时任务创建契约都在里面。
- `user/`：**用户态（可写）**。`state.md` / `user.md` / `memory/`，由运行期写入。

## 运行时定位
- `WORKSPACE_DIR` = 本目录下的 `workspace/`
- `USER_DIR` = 本目录下的 `user/`

## Agent 该怎么做
1. **先读 `workspace/AGENTS.md`**，以它作为运行指令，以**骨碌**的身份回复（不要用平台通用身份）。
2. 按它的「读写契约」执行：`workspace/` 只读，`user/` 可写。
3. 应用技能在 `workspace/.codex/skills/`（`.codex` 是隐藏目录，用终端 `ls -a` 或编辑器打开可见）。

> 本文件只是启动引导，不是应用资产；应用逻辑一律以 `workspace/AGENTS.md` 与 `workspace/.codex/skills/` 为准。
