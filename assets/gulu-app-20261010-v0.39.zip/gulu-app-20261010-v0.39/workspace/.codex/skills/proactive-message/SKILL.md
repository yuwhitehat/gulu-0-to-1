<!-- AUTO-INTERFACE -->
> **接口以本节为准**
>
> | 脚本 | 输入 | 输出 |
> |---|---|---|
> | `should_disturb` | `{persona_mbti, now?, last_interaction_at?, unanswered_count, complaint_flag, current_stage, is_minor?, proactive_allowed?}`（`proactive_allowed=false` → 直接不发） | `{should_send, reason, content_hint?, deferred_to_morning?}` |
> | `send` | `send({persona_mbti, current_stage, content_hint, user_dir})` | `{reply_text, safety_status, should_send, delivery}`（**只门禁 + 组装文本**；发送由 Agent 显式完成） |
> | `setup_schedule` | `setup_schedule(input_data?)` | `{tasks:[{task_type, name, trigger, action, delivery_mode, idempotency_key}], schedule_pending}`（**只出请求**；tasks 内字段**原样传给 `schedule.create` 动态工具**） |
> | `confirm_schedules` | `confirm_schedules({user_dir, tasks:[{task_type, task_id}]})` | `{schedule_pending, schedule_tasks}`（**唯一**"确认已创建"入口） |
>
> 门禁间隔：**J=20min，P=10min**（临时验证；连续 3 次未回复降频翻倍）；任务唤醒 cadence = 11 min（验证档，设计值 88min）。
> **创建方式**：用 **Bot 运行时注入的 `schedule.create` 动态工具**（`kind=prompt`）创建；**只用动态工具**；失败才保留 `schedule_pending=true`。
> **发送**：proactive 任务为 `delivery_mode=silent`（平台**不自动投递**）→ **门禁通过时由 Agent 调 `feishu.message_send_current_channel` 发一条角色消息**；**门禁不通过 → 零动静**；严禁输出门禁原因 / 内部状态 / 步骤 / 工具名。
> 任务创建后调 `confirm_schedules` 回写；定时确定性入口仍在 `scripts/schedules/`。

---
name: proactive-message
description: Gulu 的定时静默主动消息 Skill。负责什么时候该主动找用户和找到用户后触发谁。当需要创建定时任务、执行安静时段与频率门禁检查或触发主动消息发送时使用。不直接生成消息文本、不做对话策略、不直接面对用户可见的生成过程。
---

# Proactive Message Skill

定时静默任务 Skill。负责"什么时候该主动找用户"和"找到用户后触发谁"。不直接生成消息文本（response/persona_render 负责）、不做对话策略（dialogue 负责）、不做模式切换检测和关系阶段推进（proactive 模式跳过）。

## 触发

- scheduler/check_trigger 每 11 分钟唤醒（验证档；设计值 88min；只门禁 + 组装，**不发送**） → should_disturb 门禁 → **通过**：Agent 调 `feishu.message_send_current_channel` 发**一条角色消息**；**不通过**：**零动作、零输出**
- 用户首次完成 Onboarding 后由 intro 调 setup_schedule 创建定时任务

## 不触发

- 生成回复文本（response 负责）
- 对话策略（dialogue 负责）
- 模式切换检测（dialogue/detect_mode，proactive 模式跳过）
- 关系阶段推进（dialogue/advance_stage，proactive 模式跳过）

## 脚本

### setup_schedule

创建并维护定时任务。

| 项 | 内容 |
|----|------|
| 输入 | {proactive_allowed?, user_dir?} |
| 输出 | {tasks:[{task_type, name, trigger, action, delivery_mode, idempotency_key}], schedule_pending, schedule_last_attempt_at} |
| 性质 | 确定性（**只输出任务请求**；创建由运行态 Agent 用 **`schedule.create` 动态工具**执行） |

逻辑：按 `idempotency_key` 幂等复用（已存在则复用，不重复创建）；否则输出 3 条任务请求（见 AGENTS.md「创建契约」）；由运行态 Agent 用 **`schedule.create`** 按 `idempotency_key` 创建（重复提交不重复建）；创建回执由 `confirm_schedules` 回写 `state.schedule_tasks`。

平台定时能力**已接入**（2026-10-13）：创建应成功并读回确认；创建失败才保留 `schedule_pending=true`，不阻断用户对话。

幂等 key：`gulu-proactive-v1` / `gulu-curate-v1` / `gulu-life-event-v1`（稳定，重试不重复建）。

### should_disturb

唤醒后判断本次是否应发送。

| 项 | 内容 |
|----|------|
| 输入 | {persona_mbti, last_interaction_at, unanswered_count, complaint_flag, current_stage, is_minor} |
| 输出 | {should_send, reason, content_hint} |
| 性质 | 确定性 |

| 检查 | 规则 | 不通过 reason |
|------|------|--------------|
| 投诉即停 | complaint_flag=true | complaint_flag |
| 安静时段 | 23:00-08:00 | quiet_hours, deferred_to_morning=true |
| 频率间隔 | J 型（ENFJ/ENTJ）2h，P 型（ENFP/ENTP）100min；未成年 2h（**验证档实际 J=20min / P=10min**，见顶部接口表） | interval |
| 降频 | unanswered_count >= 3，间隔翻倍 | frequency_downgrade |

全通过 → should_send=true, content_hint=A（热搜碰撞）/B（性格闲聊，随机选）。

### send

选热搜并触发 response 编排**组装文本**（**不发送**）。

| 项 | 内容 |
|----|------|
| 输入 | {should_send, content_hint, persona_mbti, current_stage, hotsearch?} |
| 输出 | {reply_text, safety_status, should_send, delivery}（**本脚本不发送**；门禁通过时由 Agent 显式发一条） |
| 性质 | 编排（调 response **组装文本**；**不发送**） |

逻辑：
1. 选热搜（content_hint=A）：读 knowledge/hotsearch/mock-topics.json → safety_filter 过滤敏感热搜 → 按 suitable_personas 匹配当前人格 → **排除最近用过的（`state.hotsearch_recent`，最多 10 条）+ n-gram 语义去重**（近期主动消息里出现过的同类话题跳过）→ 池子用尽则取**最久没用过**的（轮换）→ 选一条（无匹配降级 B）
2. 组装输入包 {trigger_mode=proactive_initiated, persona_mbti, current_stage, hotsearch} 传给 response/orchestrate_turn
3. response 内部完成场景理解 → recall_memory → dialogue 策略（跳过 detect_mode/advance_stage）→ persona_render → pre_send_check
4. 拿到 reply_text + safety_status
5. 返回 reply_text（**不发送**）→ **门禁通过时**由 Agent 调 `feishu.message_send_current_channel` 发一条角色语言消息（**只发一条**）
6. **门禁不通过时：零动作、不输出任何内容**（任务为 `silent`，平台不自动投递）；**严禁**把门禁原因 / 内部状态 / 步骤 / 工具名写进任何用户可见内容

## 读写

| 脚本 | 读 | 写 |
|-------|-----|-----|
| setup_schedule | 无 | state.md（`schedule_pending` / `schedule_last_attempt_at`） |
| should_disturb | state.md（persona_mbti, last_interaction_at, unanswered_count, complaint_flag, current_stage, is_minor）, profile.md | 无 |
| send | knowledge/hotsearch/mock-topics.json、knowledge/safety/sensitive-keywords.json（经 safety_filter）、state.md（`hotsearch_recent`）、timeline.jsonl（近期主动消息） | state.md（`hotsearch_recent`，最近 10 条）；**不发送**（发送由 Agent 显式完成） |

send 不直接写记忆，主动消息的记录（unanswered_count+1）由 response/orchestrate_turn 内部的 record_interaction 完成。

## 失败与未知结果

| 失败场景 | 处理 |
|---------|------|
| 平台定时能力不可用（创建失败） | `schedule_pending=true`，不阻断被动对话 |
| `schedule.create` 调用失败/超时 | 标记 schedule_pending=true（UNKNOWN，不假定成功） |
| 热搜全被安全过滤或无 suitable 匹配 | 降级 content_hint=B（性格闲聊），不放弃本次触发 |
| response 生成失败 | 重试 1 次；仍失败 AI 性格化承认"脑子卡住了"，不发兜底正常回复 |
| 发送失败 / 结果未知 | **不假装成功**，不影响用户后续主动发起对话；门禁不通过 → 不输出任何用户可见内容 |
| safety_status=blocked | 不发原消息，不暴露拦截给用户 |

## 不可接受行为

- 不得跳过 pre_send_check 直接发送
- 不得在 safety_status=blocked 时发原消息
- 不得自组装消息绕过 response
- 不得发与绑定人格不一致的消息
- 不得在初识期用过分亲密/挑衅语气
- 不得在安静时段发主动消息
- 不得在投诉后继续主动打扰

## 验证 Case

### 正向

1. should_disturb 全通过（ENFP，白天，间隔满 100min，无投诉）→ should_send=true
2. send 选到热搜 → response 组装出文本（不发送）→ **门禁通过** → Agent 发一条角色消息（群里恰好一条）

### 反向

1. 投诉即停 → should_send=false, reason=complaint_flag
2. 安静时段 23:30 → should_send=false, reason=quiet_hours, deferred_to_morning=true
3. 间隔不足（ENFP，距上次 10min）→ should_send=false, reason=interval
4. 降频（unanswered_count=3，间隔未翻倍）→ should_send=false, reason=frequency_downgrade
5. 热搜全被过滤 → 降级 B，仍组装出文本（不放弃本次触发；发送由 Agent 做）
6. 发送失败 / 未知 → 不假装成功，不阻塞用户后续对话；门禁不通过 → 群里零动静

### 安全

1. 主动消息和用户回复一样过 pre_send_check
2. 安静时段不发
3. 投诉即停永久不主动
