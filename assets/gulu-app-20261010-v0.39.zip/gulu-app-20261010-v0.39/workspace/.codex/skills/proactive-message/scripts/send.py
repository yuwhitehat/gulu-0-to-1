"""触发 response 编排并**组装**主动消息文本（**本函数不发送**）。

Proactive Message Skill 独占逻辑（v2 重构版）。
不自组装消息，改为调 response/orchestrate_turn(proactive_initiated)。
输入：{ character_instance_id, persona_mbti, current_stage, content_hint, user_dir }
输出：{ reply_text, safety_status, should_send, delivery }（发送由 Agent 显式完成）
读写：读 state.md（hotsearch_recent）+ timeline.jsonl（近期主动消息）；写 state.md（hotsearch_recent）
"""
import json
import os
import sys

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # 同目录
sys.path.insert(0, os.path.join(_BASE, ".codex", "skills", "response", "scripts"))
sys.path.insert(0, os.path.join(_BASE, "scripts"))

from orchestrate_turn import orchestrate_turn
from safety_filter import is_safe
from state_store import read_state, write_state


RECENT_HOTSEARCH_LIMIT = 10  # 记住最近用过的热搜 id（避免重复）


def _recent_proactive_texts(user_dir: str, limit: int = 10) -> list:
    """读 timeline.jsonl 里最近的主动消息文本，用于"语义重复"兜底判重。"""
    if not user_dir:
        return []
    path = os.path.join(user_dir, "timeline.jsonl")
    if not os.path.isfile(path):
        return []
    texts = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if e.get("type") == "proactive" and e.get("ai_message"):
                    texts.append(e["ai_message"])
    except Exception:
        return []
    return texts[-limit:]


def _overlaps_recent(candidate: dict, recent_texts: list, n: int = 4) -> bool:
    """字符 n-gram 兜底判重：候选话题里任一 n 连字出现在近期主动消息中 → 视为重复。"""
    if not recent_texts:
        return False
    blob = (candidate.get("topic", "") or "") + (candidate.get("content", "") or "")
    grams = {blob[k:k + n] for k in range(max(0, len(blob) - n + 1))}
    return any(g in txt for txt in recent_texts for g in grams)


def _select_hotsearch(persona_mbti: str, used_ids=None, recent_texts=None) -> dict:
    """选热搜：人格匹配 + 安全过滤 → 排除最近用过的（按 id）→ n-gram 语义去重 →
    池子用尽则取"最久没用过"的（轮换，保证仍能发）；无匹配则返回空（降级性格闲聊）。"""
    used_ids = list(used_ids or [])
    recent_texts = list(recent_texts or [])
    hotsearch_path = os.path.join(_BASE, "knowledge", "hotsearch", "mock-topics.json")
    data = json.load(open(hotsearch_path, encoding="utf-8"))
    topics = data.get("topics", [])

    matched = []
    for t in topics:
        if persona_mbti in t.get("suitable_personas", []) and is_safe(t.get("content", "")):
            matched.append(t)
    if not matched:
        return {}

    pool = [t for t in matched if t.get("id") not in used_ids]
    fresh = [t for t in pool if not _overlaps_recent(t, recent_texts)]
    if fresh:
        return fresh[0]
    if pool:
        return pool[0]
    order = {tid: k for k, tid in enumerate(used_ids)}
    return sorted(matched, key=lambda t: order.get(t.get("id"), -1))[0]


def send(input_data: dict) -> dict:
    persona_mbti = input_data.get("persona_mbti", "ENFP")
    current_stage = input_data.get("current_stage", "stranger")
    content_hint = input_data.get("content_hint", "A")
    user_dir = input_data.get("user_dir", "")

    # 1. 选热搜（去重 + 轮换：连续两次主动消息不用同一条热搜）
    hotsearch = {}
    _st = read_state(user_dir) if user_dir else {}
    _used = _st.get("hotsearch_recent")
    _used = list(_used) if isinstance(_used, list) else []
    if content_hint == "A":
        hotsearch = _select_hotsearch(persona_mbti, _used, _recent_proactive_texts(user_dir))
        if hotsearch.get("id") and user_dir:
            _st["hotsearch_recent"] = ([x for x in _used if x != hotsearch["id"]]
                                       + [hotsearch["id"]])[-RECENT_HOTSEARCH_LIMIT:]
            try:
                write_state(user_dir, _st)
            except Exception:
                pass
    # 无匹配热搜 → 降级 B（性格闲聊），仍生成发送

    # 2. 调 response/orchestrate_turn(proactive_initiated)
    result = orchestrate_turn({
        "trigger_mode": "proactive_initiated",
        "persona_mbti": persona_mbti,
        "current_stage": current_stage,
        "hotsearch": hotsearch,
        "user_dir": user_dir,
    })

    reply_text = result.get("reply_text", "")
    safety_status = result.get("safety_status", "pass")

    if safety_status == "blocked":
        return {"reply_text": reply_text, "safety_status": safety_status,
                "should_send": False, "delivery": "none", "sent": None, "message_id": None}

    # 3. 组装完成：**本函数不发送**。把文本交给运行态 Agent，
    #    由 Agent 用平台注入的「发消息到当前群」能力发送（与普通对话一致：都走平台能力）。
    return {"reply_text": reply_text, "safety_status": safety_status,
            "should_send": (safety_status != "blocked"),
            "delivery": "agent_explicit_send",  # 门禁通过时由 Agent 显式发一条
            "sent": None, "message_id": None}


if __name__ == "__main__":
    import sys
    data = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    result = send(data)
    print(json.dumps(result, ensure_ascii=False, indent=2))
