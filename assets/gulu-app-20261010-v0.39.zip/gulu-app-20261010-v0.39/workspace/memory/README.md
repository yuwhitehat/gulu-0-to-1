# Gulu Memory Policy

## Overview

Gulu uses a layered memory system in each user's UserDir. Memory is split across multiple files with distinct write/read/decay responsibilities.

## Memory Files (UserDir)

| File | Writer | Reader | Decay |
|------|--------|--------|-------|
| `state.md` | `intro/init_state`、`intro/collect_user_info`、`response/record_interaction`、`billing/apply_membership`、`billing/apply_redraft`、`proactive-message/send`（`hotsearch_recent`） | all skills | 只推进，不衰减 |
| `timeline.jsonl` | `response/record_interaction` | memory_curator, load_context | 从不删除；correct_memory 标记 corrected |
| `shared_events.jsonl` | `response/record_interaction` | memory_curator, load_context | 无衰减 |
| `user-events.jsonl` | `response/record_interaction` | memory_curator, load_context | 永久 |
| `life_events.jsonl` | `life-event-generator` | memory_curator（清理）, load_context | >7 天物理删除 |
| `profile.md` | memory_curator | billing, load_context, proactive_message | 投诉永久；偏好长期 |
| `summary.md` | memory_curator | load_context | 永久 |
| `common_topics.md` | memory_curator | load_context | 长期；低活跃话题降权 |
| `topics-index.md` | memory_curator | load_context | 长期 |

> `state.md` 采用 **JSON**（读取时容忍 Markdown/YAML）。`memory/` 目录由 `intro/init_state` 初始化（8 个占位文件）。

## 冻结 / 会员

- 免费试用期满未付费 → **冻结**（`frozen=true`）：只停止调用，**不删除**；
- 会员开通 → **解冻**（`frozen=false`）；
- 落盘者为 `billing/apply_membership`；`memory-curator/check_freeze` 为纯判定。
- `orchestrate_turn` 的记忆召回 **自读 `state.frozen`**。

## Isolation

- Memory files live in UserDir, physically separated from `knowledge/` (read-only data).
- `eval-control/` and `evidence/` are not accessible to the application.
- User conversation data is never used for model training.
- Frozen memory is never deleted — only access is restricted.

## State Fields (`state.md`)

persona_bound / stage / mode（=interaction_mode）/ draw_count / interaction_count / agree_count / disagree_count / agree_streak / disagree_streak / complaint_flag / permanently_blocked / unanswered_count / is_minor / protection_mode / frozen / member_status / member_end_date / onboarding_status / proactive_allowed / first_interaction_at / last_interaction_at / last_proactive_at / schedule_pending / schedule_tasks（[{task_type, task_id}]）/ **hotsearch_recent**（最近用过的热搜 id，最多 10 条；由 `proactive-message/send` 写，用于避免连续主动消息重复同一热搜）

## Workspace 侧模板（`memory/templates/`）

- 记忆文件**初始以模板形式放在 Workspace 侧**（`state.example.json` / `user.example.md` / 各 `*.example.jsonl|md`）；
- 用户**完成引导、绑定人格后**，由 `intro/init_state` 从模板**实例化到 `UserDir/`**（每用户私有）：`X.example.EXT → X.EXT`。
