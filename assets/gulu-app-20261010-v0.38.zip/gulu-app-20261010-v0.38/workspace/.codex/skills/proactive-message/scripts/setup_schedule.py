"""产出定时任务请求（**不直连、不持凭证、不写端点**）。

照 XiaoPaw 约定：Gulu 的定时任务由「运行态 Agent 用 Bot 运行时注入的 schedule.create 动态工具」创建
（只用动态工具；不得采用其它方式）；
本脚本只**输出任务请求**，由 Agent 执行创建，创建后调 confirm_schedules 回写。

输入：{ proactive_allowed?: bool, user_dir?: str }（默认 True；用户明确拒绝则不产出 proactive 任务）
输出：{ tasks, schedule_pending, note }

任务请求字段（**原样传给 `schedule.create` 动态工具**）：
- `name`          任务名（群内可读）
- `trigger`       `{type: interval, interval_seconds}` 或 `{type: cron, cron, timezone}`
- `action`        `{type: prompt, prompt}`（固定 Prompt；模型侧动作由被唤醒的 Agent 执行）
- `delivery_mode` `silent`（**平台不投递**；要发由 Agent 显式发一条角色消息）/ `notify`（平台每次都投递结果——**会导致"不发也刷群"，本应用不用**）
- `idempotency_key` 稳定幂等键（同一用户意图重复提交不重复建）
- 兼容别名：`task_type` / `schedule`（=trigger）/ `silent`（=delivery_mode==silent）/ `prompt`（=action.prompt）

契约要点：
- proactive **必须 interval/fixed-delay（不得写成五段 Cron）**；本次 run 终态 + interval = 下次
- 每日任务用 cron（Asia/Shanghai）
"""
from __future__ import annotations
import json, os, sys
from datetime import datetime, timezone, timedelta

_BASE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_BASE, "scripts"))
from state_store import read_state, write_state


def _now():
    return datetime.now(timezone(timedelta(hours=8))).isoformat()

# 本版为**验证档**：唤醒 11min（设计值 88min）。投递口径 = silent + 门禁通过时显式发一条（方案 A）。
INTERVAL_SECONDS = 11 * 60  # fixed-delay（11min，临时验证）
PROACTIVE_DELIVERY = "silent"  # v0.38：silent=平台**不**投递结果卡（避免"门禁不通过也刷群"）；要发由 Agent 显式发一条角色消息
TZ = "Asia/Shanghai"


def _task(task_type, name, trigger, prompt, delivery_mode, idempotency_key):
    """组装一条任务请求：平台契约字段 + App 侧兼容别名。"""
    return {
        "task_type": task_type,
        "name": name,
        "trigger": trigger,
        "action": {"type": "prompt", "prompt": prompt},
        "delivery_mode": delivery_mode,
        "idempotency_key": idempotency_key,
        # ---- 兼容别名（旧消费方 / 文档）----
        "schedule": dict(trigger),
        "prompt": prompt,
        "silent": delivery_mode == "silent",
    }


def schedule_requests(input_data: dict | None = None) -> list:
    input_data = input_data or {}
    allow_proactive = input_data.get("proactive_allowed", True) is not False
    reqs = []
    if allow_proactive:
        reqs.append(_task(
            "gulu-proactive", "骨碌-主动消息",
            {"type": "interval", "interval_seconds": INTERVAL_SECONDS, "delay_type": "fixed-delay"},
            "gulu proactive-reach check", PROACTIVE_DELIVERY, "gulu-proactive-v1"))
    reqs.append(_task(
        "gulu-curate", "骨碌-记忆整理",
        {"type": "cron", "cron": "30 0 * * *", "timezone": TZ},
        "gulu memory-curate daily", "silent", "gulu-curate-v1"))
    reqs.append(_task(
        "gulu-life-event", "骨碌-生活事件",
        {"type": "cron", "cron": "0 2 * * *", "timezone": TZ},
        "gulu life-event daily", "silent", "gulu-life-event-v1"))
    return reqs


def setup_schedule(input_data: dict | None = None) -> dict:
    input_data = input_data or {}
    reqs = schedule_requests(input_data)
    out = {"tasks": reqs,
           "note": "由运行态 Agent 用 Bot 注入的 schedule.create 动态工具创建（tasks 内字段原样传）；创建/管理只用动态工具；创建后调 confirm_schedules 回写"}
    # 诊断：记录"是否尝试过创建"（用于区分"没执行"vs"执行了没成功"）
    user_dir = input_data.get("user_dir", "")
    if user_dir:
        st = read_state(user_dir)
        st.setdefault("schedule_pending", True)
        st["schedule_last_attempt_at"] = _now()
        write_state(user_dir, st)
        out["schedule_pending"] = st.get("schedule_pending", True)
        out["schedule_last_attempt_at"] = st["schedule_last_attempt_at"]
    return out


if __name__ == "__main__":
    import sys
    print(json.dumps(setup_schedule(json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}), ensure_ascii=False, indent=2))
