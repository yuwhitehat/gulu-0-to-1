# Gulu External Tools & Adapters

Gulu uses **platform-injected capabilities** only（动态工具 / 平台能力）。应用**不直连外部 API、不写端点**。

> **定时任务**：**必须用 Bot 运行时自动注入的动态工具 `schedule.create` 创建**；创建 / 管理**只用动态工具**，**不得采用其它任何方式**。应用只**输出任务请求**，由运行态 Agent 用该工具创建；应用**不出现外部地址/端口号、不持凭证**（对齐参考应用「独一无二的TA」）。
> **能力状态（2026-10-13 Owner 确认）**：底层平台定时能力**已接入** → 引导结束创建 3 个任务**现在应成功**；仍保留降级语义（能力不可用 → `schedule_pending=true`，不阻断）。

## 能力（**平台注入，应用不写端点**）

> 平台能力以**动态工具**形式由 Bot 运行时注入（`schedule.*` / 飞书消息等），**直接调用即可**；应用与文档**均不出现任何外部地址、端口号或命令行请求示例**。

| 能力 | 提供方 | 使用方 | 用途 |
|------|--------|--------|------|
| 飞书消息 | 平台注入的飞书能力（动态工具） | **主动消息发送**（门禁通过时）＋ 文档 / 图片等 | 定时任务为 `silent`：由 Agent **显式发一条角色消息** |
| 定时任务 | **Bot 运行时注入的动态工具**：`schedule.create` / `schedule.list_own` / `schedule.update` | 运行态 Agent（按本文件「创建契约」原样传参） | 创建 / 列举 / 更新 3 条任务 |
| 图片生成 | 平台能力（保留） | — | 当前范围未使用 |

## 定时任务（**用 `schedule.create` 动态工具**）

Gulu **不直连、不持凭证、文档里不写端点**：应用只输出**任务请求**，由**运行态 Agent 用 Bot 注入的 `schedule.create` 动态工具**创建**固定 Prompt** 任务（`kind=prompt`）；将来平台开 script 能力可切 `kind=script`（脚本已在 `scripts/schedules/`）。

| 任务 | `name` | 触发 | `action.prompt` | `delivery_mode` | `idempotency_key` |
|------|--------|------|-----------------|-----------------|-------------------|
| gulu-proactive | 骨碌-主动消息 | interval **fixed-delay 660s（11min，验证档）** | `gulu proactive-reach check` | `notify`（验证档） | `gulu-proactive-v1` |
| gulu-curate | 骨碌-记忆整理 | cron `30 0 * * *`（Asia/Shanghai） | `gulu memory-curate daily` | `silent` | `gulu-curate-v1` |
| gulu-life-event | 骨碌-生活事件 | cron `0 2 * * *`（Asia/Shanghai） | `gulu life-event daily` | `silent` | `gulu-life-event-v1` |

> `setup_schedule` 输出的 `tasks[]` 字段（`name`/`trigger`/`action`/`delivery_mode`/`idempotency_key`）**原样传给 `schedule.create`**；创建回执经 `confirm_schedules` 回写 `state.schedule_tasks`。未创建时 `schedule_pending=true`，**不阻断**对话。
> **`delivery_mode` 用 `silent`**：平台**不**投递任何结果（避免「门禁不通过也刷群」）；**要发时由 Agent 显式发一条角色消息**。不要用 `notify`（每次唤醒都会投递结果 → 出戏消息）。

## LLM

| Tool | Used by | Purpose |
|------|---------|---------|
| `scripts/llm_generate.py`（codex exec → 平台默认模型） | `response/persona_render`、`life-event-generator`、`memory-curator` | 性格一致性文本生成；失败重试 1 次，仍失败性格化承认故障（不假装正常）。模型可用 `GULU_LLM_MODEL` 覆盖 |

## 支付

支付经**平台支付能力**交互，无直连支付 API；**未经用户确认不扣费**。`billing/payment` 仅做支付结果校验（纯判定）。

## 发送（`silent` + 门禁通过时**显式发一条**）

- **普通 Turn**：Agent 的回复就是群消息。
- **主动消息（定时任务触发）**：proactive 任务为 **`delivery_mode = silent`**（平台**不自动投递**）→ 由 Agent 在**门禁通过时显式调用一次** `feishu.message_send_current_channel`，发**一条角色语言消息**；**门禁不通过 → 零动作、零输出**。
- **严禁**把门禁原因 / 内部状态 / 步骤 / 工具名写进用户可见内容（用户只能看到骨碌说的话）。
- 为什么不用 `notify`：`notify` 会在**每次唤醒**（含「不发送」）都投递结果 → 群里出现「门禁未通过…」这种**出戏消息**。
- 切换口径（若平台改为自动投递最终回复）：改 `silent → notify`，同时把发送方式改成「输出最终回复、不要调工具」，**两者不能同时做**。

## 数据格式

- `user/state.md` 采用 **JSON**（读取时容忍 Markdown/YAML 两种格式）。
