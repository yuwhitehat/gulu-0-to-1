"""Gulu schedules/check_trigger — 主动消息触发（每 11 分钟，验证档）。

**只做门禁 + 组装文本，不发送**：发送由运行态 Agent 在门禁通过时显式完成（任务为 `silent`，
平台不自动投递）；应用脚本不发送、不写外部地址、不持凭证。

流程：读 state → should_disturb 门禁 → 通过 → send（组装 reply_text）
输出：{ triggered, gate, should_send, reply_text, safety_status, delivery, note }
"""
from __future__ import annotations
import json, sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE.parents[1] / ".codex" / "skills" / "proactive-message" / "scripts"))
sys.path.insert(0, str(HERE.parents[1] / ".codex" / "skills" / "response" / "scripts"))
from _sched_common import resolve_user_dir, load_state
from should_disturb import should_disturb
from send import send

def run(user_dir: str) -> dict:
    state = load_state(user_dir)
    if not state:
        return {"triggered": False, "reason": "no_state"}
    persona = state.get("persona_bound") or state.get("persona_mbti") or "ENFP"
    gate = should_disturb({
        "persona_mbti": persona,
        "last_interaction_at": state.get("last_interaction_at"),
        "unanswered_count": state.get("unanswered_count", 0),
        "complaint_flag": state.get("complaint_flag", False),
        "current_stage": state.get("stage", "stranger"),
        "is_minor": state.get("is_minor", False),
        "proactive_allowed": state.get("proactive_allowed", True),
    })
    if not gate.get("should_send"):
        return {"triggered": False, "reason": gate.get("reason")}
    result = send({"persona_mbti": persona, "current_stage": state.get("stage", "stranger"),
                   "content_hint": gate.get("content_hint", "A"), "user_dir": user_dir})
    return {
        "triggered": True,
        "gate": gate,
        "should_send": bool(result.get("should_send")),
        "reply_text": result.get("reply_text", ""),
        "safety_status": result.get("safety_status", "pass"),
        "delivery": "agent_explicit_send",  # 门禁通过：由 Agent 调发消息工具发一条（任务为 silent，平台不自动投递）
        "note": ("门禁通过 → 请**调用一次 `feishu.message_send_current_channel`**，把 reply_text 作为**一条角色语言消息**"
                 "发到当前群（本任务为 silent，平台不会自动投递，**只发这一条**）。"
                 "用户可见内容**只能**是这条角色消息；**严禁**出现门禁原因 / 内部状态 / 步骤 / 工具名。"),
    }

if __name__ == "__main__":
    print(json.dumps(run(resolve_user_dir()), ensure_ascii=False, indent=2))
