# 骨碌（Gulu）App 自测指南

> 本包 = 应用本体 `workspace/`（只读，目录树与设计文档一致）+ 用户态 `user/`（可写）。下面命令均假设在**解压根目录**执行。

## 0. 前置
- Python 3.12+（本机 3.14.5）
- 有 adapter 才能"真发/真注册"；本地无 adapter 时返回 `ok:false`/`adapter_ok:false`，属预期

## 1. 离线自检（不耗 LLM、不需要 adapter）
```bash
# 结构/入口可导入
python3 -B -c "import importlib.util,sys,pathlib;\
app=pathlib.Path('workspace');\
[importlib.util.spec_from_file_location(p.stem,p) for p in app.rglob('*.py')]" && echo OK-import
```

## 2. 手验主动消息定时脚本（会调 LLM 生成）
```bash
export USER_DIR="$PWD/user"
# 先在 state.md 里绑一个人格并把 last_interaction_at 设老一点，例如：
python3 - <<'PY'
import json,pathlib
p=pathlib.Path("user/state.md"); s=json.loads(p.read_text(encoding="utf-8"))
s.update({"persona_bound":"ENFP","stage":"stranger","unanswered_count":0,
          "complaint_flag":False,"last_interaction_at":"2026-10-10T06:00:00+08:00"})
p.write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding="utf-8")
PY
python3 -B workspace/scripts/schedules/check_trigger.py
```
期望：`triggered=true`，且 `reply_text` 是**该人格口吻**的文本。
**注意：脚本不发送**。proactive 任务为 `silent`（平台不自动投递）→ 接下来由 Agent 在门禁通过时
**显式调用 `feishu.message_send_current_channel` 发一条**；门禁不通过则**零动作、零输出**。

## 3. 注册定时任务（**需平台定时能力**；2026-10-13 已接入）

```bash
# 1) 出任务请求（3 条；记录 schedule_last_attempt_at）
USER_DIR="$PWD/user" python3 -B workspace/.codex/skills/proactive-message/scripts/setup_schedule.py '{"user_dir":"'$PWD'/user"}'
```

2) **把 tasks 内字段原样提交给 Global schedule 能力**（运行态 `schedule` Skill；应用不直连）：

| name | trigger | action.prompt | delivery_mode | idempotency_key |
|---|---|---|---|---|
| 骨碌-主动消息 | `{"type":"interval","interval_seconds":660}` | `gulu proactive-reach check` | `notify` | `gulu-proactive-v1` |
| 骨碌-记忆整理 | `{"type":"cron","cron":"30 0 * * *","timezone":"Asia/Shanghai"}` | `gulu memory-curate daily` | `silent` | `gulu-curate-v1` |
| 骨碌-生活事件 | `{"type":"cron","cron":"0 2 * * *","timezone":"Asia/Shanghai"}` | `gulu life-event daily` | `silent` | `gulu-life-event-v1` |

3) 拿到 **task_id 回执**后回写：

```bash
USER_DIR="$PWD/user" python3 -B workspace/.codex/skills/proactive-message/scripts/confirm_schedules.py \
  '{"user_dir":"'$PWD'/user","tasks":[{"task_type":"gulu-proactive","task_id":"<id>"},{"task_type":"gulu-curate","task_id":"<id>"},{"task_type":"gulu-life-event","task_id":"<id>"}]}'
```

### 验证清单（本版重点）

- [ ] **创建成功**：3 条任务出现在**当前群**任务列表（name 与上表一致，各 1 条，无重复）
- [ ] **回写成功**：`user/state.md` → `schedule_tasks` 非空、`schedule_pending=false`、`schedule_confirmed_at` 非空
- [ ] **真触发**：`notify` 下 ≤11min 内群里出现一次唤醒结果卡（内容为 `check_trigger` 的门禁结论）
- [ ] **门禁生效**：间隔未到 / 安静时段 / 投诉后 → 结论为"不发"（**不发是正常结果**）
- [ ] **主动消息**：门禁通过时，群里出现**该人格口吻**的主动消息（经 Feishu adapter）
- [ ] 失败时**如实记录**：保留 `schedule_pending=true`，不假装成功

> 验证通过后恢复设计值（唤醒 88min、proactive `silent`）出正式版。

## 4. 建议你跑的旅程（Journey 1~4）
1. UC-01→UC-02：抽人格 → 以该人格发一条主动消息（人格一致）
2. UC-01→UC-02→UC-03：抽人格 → 主动消息 → 连续 3 次同意 → 模式切 `same_frequency`
3. UC-05→UC-06：重抽达 3 次上限 → 选会员路径 → 支付成功 → 记忆解冻 → 到期降级冻结
4. UC-04：免费期满冻结 → 用户指出记错 → 纠正成功 → 开通解冻

## 5. 观察点
- 主动消息：门禁通过时群里**恰好一条**角色消息（由 Agent 显式发送）；门禁不通过时**群里零动静**；间隔 / 安静时段 / 投诉即停是否生效
- 人格：抽到谁，就用谁的口吻；ENTJ 不应出现"啊啊啊/诶/嘛"
- 状态：`user/state.md` 是否随互动更新（interaction_count / interaction_mode / stage / frozen / draw_count）
- 安全：含敏感词的热搜**不应进入生成**（`safety_status=blocked`）

## 6. 已知限制
- 安全词库为 demo 最小集，政治类须上架前替换为合规权威源
- 关键词匹配不覆盖变形/谐音/拼音缩写/图片/反讽
- 主动消息"真发"依赖平台 adapter
